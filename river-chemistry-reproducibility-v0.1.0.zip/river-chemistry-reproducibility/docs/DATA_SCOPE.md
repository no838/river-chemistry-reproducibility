# Public data scope

## Included

- aggregate figure-ready tables for Figures 1–4;
- selected aggregate robustness tables;
- selected analysis scripts and configuration files;
- environment and provenance notes needed to interpret the release boundary.

## Excluded

- the original Chinese four-hour station-time concentration records;
- raw or near-raw concentration tables;
- detailed annual section matrices and restricted event-level chemistry;
- exact station names and exact station coordinates for the Chinese panel;
- manuscript, title-page, cover-letter, reviewer and internal QA files;
- local paths, temporary files, caches, credentials and execution traces.

## Interpretation limit

The included data are sufficient for inspecting published estimands and
figure-ready evidence tables. They are not a substitute for the governed raw
panel and do not establish unrestricted independent re-estimation.
