# Release blockers

This folder is a release candidate for the independent public repository and
archive.

The following items must be resolved before upload:

1. The independent GitHub repository must be created and the release branch
   uploaded.
2. A Zenodo account must be available in the browser and the draft record must
   be saved before publication.
3. The final GitHub URL and Zenodo DOI must be recorded after verification.

No raw panel, manuscript, submission file, private audit record or credential
has been included in this candidate.
