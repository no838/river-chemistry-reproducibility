#!/usr/bin/env python3
"""Compare recomputed outputs with the publication-reference outputs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


def compare_csv(recomputed: Path, reference: Path, keys: list[str], tolerance: float):
    a = pd.read_csv(recomputed)
    b = pd.read_csv(reference)
    if keys:
        a = a.sort_values(keys).reset_index(drop=True)
        b = b.sort_values(keys).reset_index(drop=True)
    result = {"recomputed": str(recomputed), "reference": str(reference), "rows_recomputed": len(a), "rows_reference": len(b)}
    if len(a) != len(b):
        result.update(status="FAIL", reason="row count mismatch")
        return result
    common = [column for column in a.columns if column in b.columns]
    numeric = [column for column in common if pd.api.types.is_numeric_dtype(a[column]) and pd.api.types.is_numeric_dtype(b[column])]
    text = [column for column in common if column not in numeric]
    max_difference = 0.0
    for column in numeric:
        x = pd.to_numeric(a[column], errors="coerce").to_numpy(float)
        y = pd.to_numeric(b[column], errors="coerce").to_numpy(float)
        difference = np.abs(x - y)
        finite = difference[np.isfinite(difference)]
        if len(finite):
            max_difference = max(max_difference, float(finite.max()))
        if not np.array_equal(np.isnan(x), np.isnan(y)):
            result.update(status="FAIL", reason=f"missingness mismatch in {column}")
            return result
    for column in text:
        x = a[column].fillna("").astype(str).to_numpy()
        y = b[column].fillna("").astype(str).to_numpy()
        if not np.array_equal(x, y):
            result.update(status="FAIL", reason=f"text mismatch in {column}")
            return result
    result["max_numeric_difference"] = max_difference
    result["tolerance"] = tolerance
    result["status"] = "PASS" if max_difference <= tolerance else "FAIL"
    if result["status"] == "FAIL":
        result["reason"] = "numeric tolerance exceeded"
    return result


def sha256(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    recomputed = root / "outputs" / "recomputed"
    reference = root / "outputs" / "reference"
    qa = root / "QA"
    checks = [
        ("annual retention", "annual_state/retention.csv", ["year_pair", "metric"], 1e-12),
        ("annual distances", "annual_state/full_space_distances.csv", ["year_pair", "distance_metric"], 1e-12),
        ("annual centroids", "annual_state/state_centroids.csv", ["state_class", "variable"], 1e-12),
        ("annual contrasts", "annual_state/state_contrasts.csv", ["variable"], 1e-12),
        ("source-year ordinal", "annual_state/source_year_ordinal.csv", ["source_year", "target_year", "metric"], 1e-12),
        ("annual support sensitivity", "annual_state/observation_support_sensitivity.csv", ["support_rule", "year_pair"], 1e-12),
        ("basin persistence", "annual_state/basin_specific_persistence.csv", ["year_pair", "basin"], 1e-12),
        ("China matching", "china_matching/matched_pulse_control_days.csv", ["year", "basin", "pulse_date"], 1e-12),
        ("China phase family", "china_event/primary_phase_tests.csv", ["year", "test"], 1e-12),
        ("China cross-fitted trajectory", "china_event/event_trajectory.csv", ["year", "basin", "rel_h"], 1e-12),
        ("China cross-fitted phase response", "china_event/phase_response.csv", ["year", "basin", "phase"], 1e-12),
        ("China construction-year descriptive phases", "china_event/construction_year_phase_descriptive.csv", ["year", "test"], 1e-12),
        ("China constituent directions", "china_event/constituent_direction_2023.csv", ["variable"], 1e-12),
        ("China constituent direction 2024", "china_event/constituent_direction_2024.csv", ["variable"], 1e-12),
        ("China five-variable external template", "china_event/china_five_variable_template.csv", ["rel_h"], 1e-12),
        ("China five-variable external direction", "china_event/china_five_variable_node_direction.csv", ["variable"], 1e-12),
        ("China basin constituent vectors", "china_event/basin_constituent_response_vectors.csv", ["year", "basin"], 1e-12),
        ("China basin-held-out event trajectory", "china_event/leave_one_basin_out_event_trajectory.csv", ["target_year", "held_out_basin", "rel_h"], 1e-12),
        ("China basin-held-out phase response", "china_event/leave_one_basin_out_phase_response.csv", ["target_year", "held_out_basin", "phase"], 1e-12),
        ("China basin-held-out phase tests", "china_event/leave_one_basin_out_phase_tests.csv", ["target_year", "test"], 1e-12),
        ("China basin-held-out trajectory", "china_event/leave_one_basin_out_trajectory_projection.csv", ["source_year", "target_year", "held_out_basin"], 1e-12),
        ("China basin-held-out trajectory summary", "china_event/leave_one_basin_out_trajectory_summary.csv", ["source_year", "target_year"], 1e-12),
        ("China basin-held-out trajectory uncertainty", "china_event/leave_one_basin_out_trajectory_uncertainty.csv", ["source_year", "target_year"], 1e-12),
        ("China basin-held-out trajectory cosine", "china_event/leave_one_basin_out_trajectory_cosine.csv", ["source_year", "target_year", "held_out_basin"], 1e-12),
        ("China basin-held-out cosine summary", "china_event/leave_one_basin_out_trajectory_cosine_summary.csv", ["source_year", "target_year"], 1e-12),
        ("China trajectory-template uncertainty", "china_event/trajectory_template_uncertainty.csv", ["source_year", "target_year", "uncertainty_method"], 1e-12),
        ("China paired episodes", "china_event/paired_episode_sensitivity.csv", ["year", "support_rule", "test"], 1e-12),
        ("China forward projections", "china_event/basin_projections_2024_to_2023.csv", ["basin"], 1e-12),
        ("China reverse projections", "china_event/basin_projections_2023_to_2024.csv", ["basin"], 1e-12),
        ("China averaging", "china_averaging/averaging_summary.csv", ["year"], 1e-12),
        ("lagged PC1-PC2 prediction", "lagged_state_prediction/primary_pc12_results.csv", ["outcome"], 1e-12),
        ("lagged all-nine-PC sensitivity", "lagged_state_prediction/all_nine_pc_sensitivity.csv", ["outcome"], 1e-12),
        ("lagged forcing-adjusted sensitivity", "lagged_state_prediction/forcing_adjusted_sensitivity.csv", ["outcome"], 1e-12),
        ("lagged basin-equal sensitivity", "lagged_state_prediction/basin_equal_sensitivity.csv", ["outcome"], 1e-12),
        ("lagged held-out prediction", "lagged_state_prediction/heldout_q2.csv", ["outcome", "predictor_set", "source_event_year"], 1e-12),
        ("lagged section-cluster model", "lagged_state_prediction/section_cluster_robust_results.csv", ["outcome", "term"], 1e-12),
        ("lagged prediction domain flow", "lagged_state_prediction/analysis_domain_flow.csv", ["year", "stage"], 1e-12),
        ("lagged prediction basin domain", "lagged_state_prediction/basin_domain.csv", ["outcome", "basin"], 1e-12),
        ("state-forcing joint interaction", "state_forcing_interaction/interaction_joint_tests.csv", ["outcome"], 1e-12),
        ("state-forcing interaction coefficients", "state_forcing_interaction/interaction_coefficients.csv", ["outcome", "term"], 1e-12),
        ("state-forcing interaction held-out Q2", "state_forcing_interaction/interaction_heldout_q2.csv", ["outcome", "source_event_year"], 1e-12),
        ("minimum per-variable support", "scale_separation_sensitivities/minimum_per_variable_support.csv", ["minimum_observations_for_each_variable", "year_pair"], 1e-12),
        ("nearest-other-section null", "scale_separation_sensitivities/nearest_other_section_null.csv", ["year_pair"], 1e-12),
        ("leave-one-basin-out China", "scale_separation_sensitivities/leave_one_basin_out_china.csv", ["source_year", "target_year", "held_out_basin"], 1e-12),
        ("USGS site influence", "scale_separation_sensitivities/usgs_site_influence.csv", ["analysis", "omitted_site"], 1e-12),
        ("laboratory-analyte annual persistence", "scale_separation_sensitivities/laboratory_analyte_persistence.csv", ["year_pair"], 1e-12),
        ("China source-target uncertainty", "source_template_uncertainty/china_source_target_uncertainty.csv", ["source_year", "target_year", "uncertainty_method"], 1e-12),
        ("external leave-one-China-basin", "source_template_uncertainty/external_leave_one_china_basin.csv", ["source_year", "omitted_china_basin"], 1e-12),
        ("external source-template/site uncertainty", "source_template_uncertainty/external_template_site_uncertainty.csv", ["source_year", "method"], 1e-12),
        ("external small-sample sensitivity", "source_template_uncertainty/external_small_sample_sensitivity.csv", ["source_year", "estimand"], 1e-12),
        ("external cosine uncertainty", "source_template_uncertainty/external_cosine_uncertainty.csv", ["source_year", "method"], 1e-12),
        ("external source-year sensitivity", "source_template_uncertainty/external_source_year_sensitivity.csv", ["source_year", "site"], 1e-12),
        ("external cosine site values", "source_template_uncertainty/external_cosine_site_values.csv", ["source_year", "site"], 1e-12),
        ("USGS site projections", "usgs/site_projections.csv", ["site"], 1e-12),
        ("USGS primary family", "usgs/primary_three_test_family.csv", ["Test"], 1e-12),
        ("USGS spatial grouping", "usgs/spatial_grouping.csv", ["aggregation_level"], 1e-12),
        ("USGS period sensitivity", "usgs/period_sensitivity.csv", ["Period"], 1e-12),
        ("USGS relabelling", "usgs/constituent_relabelling.csv", ["permutation"], 1e-12),
        ("USGS decomposition", "usgs/projection_decomposition_QA.csv", ["site"], 1e-12),
        ("USGS series cache median family", "usgs_series_median/primary_three_test_family.csv", ["Test"], 1e-12),
        ("USGS series metadata-primary family", "usgs_series_metadata_primary/primary_three_test_family.csv", ["Test"], 1e-12),
        ("USGS series event overlap", "usgs_series_selection_sensitivity/event_overlap_summary.csv", ["comparison"], 1e-12),
        ("USGS series event identity", "usgs_series_selection_sensitivity/event_numeric_identity.csv", ["column"], 1e-12),
        ("USGS series inference comparison", "usgs_series_selection_sensitivity/inference_comparison_summary.csv", ["table"], 1e-12),
        ("USGS series inventory", "usgs_series_selection_sensitivity/series_selection_inventory.csv", ["series_mode", "site", "year", "variable"], 1e-12),
    ]
    results = []
    for label, relative, keys, tolerance in checks:
        a = recomputed / relative
        b = reference / relative
        if not a.exists() or not b.exists():
            results.append({"check": label, "status": "FAIL", "reason": f"missing {a if not a.exists() else b}"})
        else:
            result = compare_csv(a, b, keys, tolerance)
            result["check"] = label
            results.append(result)
    sufficient_inputs = [
        ("exploratory pH common-event result", root / "data" / "usgs" / "pH_common155_complete_family.csv", 4),
        ("identity-rank representation sensitivity", root / "data" / "usgs" / "identity_rank_across_modes_sufficient.csv", 5),
        ("nine-variable sampling-phase sensitivity", root / "data" / "china_event" / "nine_variable_sampling_phase_sensitivity_sufficient.csv", 4),
        ("metadata-only USGS candidate frame", root / "data" / "usgs" / "candidate_sites_30_metadata_lock.csv", 30),
        ("pseudonymised basin constituent vectors", root / "data" / "china_event" / "basin_node_response_vectors.csv", 16),
        ("cache-median public event sensitivity input", root / "data" / "usgs" / "event_response_rows_cache_median.csv.gz", 188),
        ("metadata-primary public event sensitivity input", root / "data" / "usgs" / "event_response_rows_metadata_primary.csv.gz", 188),
    ]
    for label, path, expected_rows in sufficient_inputs:
        rows = len(pd.read_csv(path)) if path.exists() else 0
        results.append({
            "check": label,
            "status": "PASS" if path.exists() and rows == expected_rows else "FAIL",
            "rows": rows,
            "role": "declared sufficient or metadata-only input",
        })
    status = "PASS" if all(result["status"] == "PASS" for result in results) else "FAIL"
    output = {
        "status": status,
        "checks": results,
        "reference_manifest_sha256": sha256(root / "input_manifest.csv") if (root / "input_manifest.csv").exists() else None,
    }
    qa.mkdir(parents=True, exist_ok=True)
    (qa / "analysis_reproduction_validation.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))
    if status != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
