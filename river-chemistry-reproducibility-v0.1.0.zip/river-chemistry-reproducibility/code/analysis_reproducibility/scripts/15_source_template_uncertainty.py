#!/usr/bin/env python3
"""Quantify China-source and USGS-target uncertainty for external projections.

The reported external statistic is a norm-sensitive projection onto a unit
China template. This stage evaluates both the 2024 reference template and a
2023 source-year sensitivity, propagates China source-basin uncertainty,
reports leave-one-China-basin influence, and provides cosine-similarity
sensitivities that isolate direction from target-trajectory norm.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t as student_t

CHINA_VARIABLES = [
    "d_water_temp", "d_pH", "d_DO", "d_EC", "d_turbidity",
    "d_CODMn", "d_NH3N", "d_TP", "d_TN",
]
SHARED_CHINA_VARIABLES = ["d_water_temp", "d_pH", "d_DO", "d_EC", "d_turbidity"]
USGS_VARIABLES = ["water_temp", "pH", "DO", "EC", "turbidity"]
RELATIVE_HOURS = list(range(-24, 49, 4))


def unit(values: np.ndarray) -> np.ndarray:
    array = np.asarray(values, float)
    norm = np.linalg.norm(array)
    if not np.isfinite(norm) or norm <= 0:
        raise ValueError("Cannot normalise template")
    return array / norm


def event_columns() -> list[str]:
    return [f"{variable}_{hour}" for hour in RELATIVE_HOURS for variable in USGS_VARIABLES]


def t_interval(values: np.ndarray) -> tuple[float, float]:
    array = np.asarray(values, float)
    array = array[np.isfinite(array)]
    mean = float(array.mean())
    se = float(array.std(ddof=1) / np.sqrt(len(array)))
    critical = float(student_t.ppf(0.975, len(array) - 1))
    return mean - critical * se, mean + critical * se


def exact_signflip(values: np.ndarray, alternative: str = "greater") -> float:
    array = np.asarray(values, float)
    array = array[np.isfinite(array)]
    observed = float(array.mean())
    null = []
    for bits in range(2 ** len(array)):
        signs = np.array([1 if (bits >> index) & 1 else -1 for index in range(len(array))])
        null.append(float(np.mean(array * signs)))
    null = np.asarray(null)
    if alternative == "greater":
        return float(np.mean(null >= observed - 1e-15))
    if alternative == "less":
        return float(np.mean(null <= observed + 1e-15))
    return float(np.mean(np.abs(null) >= abs(observed) - 1e-15))


def china_basin_matrices(
    basin_trajectory: pd.DataFrame, year: int, columns: list[str]
) -> tuple[list[str], np.ndarray]:
    basins = sorted(basin_trajectory.basin.unique())
    matrices = []
    for basin in basins:
        matrix = (
            basin_trajectory[
                basin_trajectory.year.eq(year) & basin_trajectory.basin.eq(basin)
            ]
            .set_index("rel_h").reindex(RELATIVE_HOURS)[columns].to_numpy(float)
        )
        if not np.isfinite(matrix).all():
            raise RuntimeError(f"Non-finite China trajectory for {year}, {basin}")
        matrices.append(matrix.ravel())
    return basins, np.stack(matrices)


def site_year_trajectories(
    events: pd.DataFrame, formal_sites: list[str]
) -> dict[str, np.ndarray]:
    selected = events[
        events.site.isin(formal_sites) & events.year.isin([2022, 2023, 2024])
    ].copy()
    columns = event_columns()
    output: dict[str, list[np.ndarray]] = {site: [] for site in formal_sites}
    for (site, year), group in selected.groupby(["site", "year"], sort=True):
        trajectory = np.nanmedian(
            group[columns].apply(pd.to_numeric, errors="coerce").to_numpy(float), axis=0
        )
        if np.isfinite(trajectory).all():
            output[site].append(trajectory)
    final = {site: np.stack(values) for site, values in output.items() if values}
    missing = sorted(set(formal_sites) - set(final))
    if missing:
        raise RuntimeError(f"Missing formal-site trajectories: {missing}")
    return final


def site_projection_values(
    direction: np.ndarray, formal_sites: list[str], site_year: dict[str, np.ndarray]
) -> np.ndarray:
    return np.asarray([
        float(np.median(site_year[site] @ direction)) for site in formal_sites
    ])


def site_cosine_values(
    direction: np.ndarray, formal_sites: list[str], site_year: dict[str, np.ndarray]
) -> np.ndarray:
    values = []
    for site in formal_sites:
        trajectories = site_year[site]
        norms = np.linalg.norm(trajectories, axis=1)
        cosines = np.divide(
            trajectories @ direction,
            norms,
            out=np.full(len(trajectories), np.nan),
            where=norms > 0,
        )
        values.append(float(np.nanmedian(cosines)))
    return np.asarray(values)


def bootstrap_sites(
    values: np.ndarray, replicates: int, rng: np.random.Generator
) -> np.ndarray:
    indices = rng.integers(0, len(values), size=(replicates, len(values)))
    return values[indices].mean(axis=1)


def external_uncertainty_for_year(
    source_year: int,
    source: np.ndarray,
    basins: list[str],
    formal_sites: list[str],
    site_year: dict[str, np.ndarray],
    replicates: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    full_direction = unit(source.mean(axis=0))
    fixed_values = site_projection_values(full_direction, formal_sites, site_year)
    fixed_cosines = site_cosine_values(full_direction, formal_sites, site_year)
    point = float(fixed_values.mean())
    cosine_point = float(fixed_cosines.mean())

    leave_rows = []
    for index, basin in enumerate(basins):
        direction = unit(np.delete(source, index, axis=0).mean(axis=0))
        values = site_projection_values(direction, formal_sites, site_year)
        cosines = site_cosine_values(direction, formal_sites, site_year)
        leave_rows.append({
            "source_year": source_year,
            "omitted_china_basin": basin,
            "site_equal_mean_projection": float(values.mean()),
            "mean_cosine_similarity": float(cosines.mean()),
            "positive_sites": int((values > 0).sum()),
            "positive_cosine_sites": int((cosines > 0).sum()),
            "minimum_site_projection": float(values.min()),
            "maximum_site_projection": float(values.max()),
        })

    rng = np.random.default_rng(seed)
    n_source = len(source)
    n_sites = len(formal_sites)
    joint = np.empty(replicates)
    source_only = np.empty(replicates)
    site_only = np.empty(replicates)
    joint_cosine = np.empty(replicates)
    source_only_cosine = np.empty(replicates)
    site_only_cosine = np.empty(replicates)
    for start in range(0, replicates, 2500):
        count = min(2500, replicates - start)
        source_index = rng.integers(0, n_source, size=(count, n_source))
        directions = source[source_index].mean(axis=1)
        directions /= np.linalg.norm(directions, axis=1)[:, None]

        projections = np.empty((count, n_sites))
        cosines = np.empty((count, n_sites))
        for site_index, site in enumerate(formal_sites):
            trajectories = site_year[site]
            year_projection = trajectories @ directions.T
            projections[:, site_index] = np.median(year_projection, axis=0)
            norms = np.linalg.norm(trajectories, axis=1)[:, None]
            year_cosine = np.divide(
                year_projection,
                norms,
                out=np.full_like(year_projection, np.nan),
                where=norms > 0,
            )
            cosines[:, site_index] = np.nanmedian(year_cosine, axis=0)

        site_index = rng.integers(0, n_sites, size=(count, n_sites))
        joint[start:start+count] = np.take_along_axis(projections, site_index, axis=1).mean(axis=1)
        source_only[start:start+count] = projections.mean(axis=1)
        site_only[start:start+count] = fixed_values[site_index].mean(axis=1)
        joint_cosine[start:start+count] = np.take_along_axis(cosines, site_index, axis=1).mean(axis=1)
        source_only_cosine[start:start+count] = cosines.mean(axis=1)
        site_only_cosine[start:start+count] = fixed_cosines[site_index].mean(axis=1)

    projection_rows = []
    for method, draws in [
        ("USGS site bootstrap conditional on fixed China template", site_only),
        ("China source-basin bootstrap conditional on fixed USGS sites", source_only),
        ("joint China source-basin and USGS site bootstrap", joint),
    ]:
        projection_rows.append({
            "source_year": source_year,
            "method": method,
            "point_estimate": point,
            "ci_low": float(np.quantile(draws, 0.025)),
            "median": float(np.quantile(draws, 0.5)),
            "ci_high": float(np.quantile(draws, 0.975)),
            "fraction_nonpositive": float(np.mean(draws <= 0)),
            "replicates": replicates,
        })

    cosine_rows = []
    for method, draws in [
        ("USGS site bootstrap conditional on fixed China template", site_only_cosine),
        ("China source-basin bootstrap conditional on fixed USGS sites", source_only_cosine),
        ("joint China source-basin and USGS site bootstrap", joint_cosine),
    ]:
        cosine_rows.append({
            "source_year": source_year,
            "method": method,
            "point_estimate": cosine_point,
            "ci_low": float(np.quantile(draws, 0.025)),
            "median": float(np.quantile(draws, 0.5)),
            "ci_high": float(np.quantile(draws, 0.975)),
            "fraction_nonpositive": float(np.mean(draws <= 0)),
            "positive_sites": int((fixed_cosines > 0).sum()),
            "conditional_exact_p": exact_signflip(fixed_cosines, "greater"),
            "replicates": replicates,
        })

    t_low, t_high = t_interval(fixed_values)
    small_sample = pd.DataFrame([{
        "source_year": source_year,
        "estimand": "whole-trajectory projection",
        "sites": len(fixed_values),
        "estimate": point,
        "t_ci_low": t_low,
        "t_ci_high": t_high,
        "positive_sites": int((fixed_values > 0).sum()),
    }])
    site_values = pd.DataFrame({
        "source_year": source_year,
        "site": formal_sites,
        "projection": fixed_values,
        "cosine_similarity": fixed_cosines,
    })
    summary = pd.DataFrame([{
        "source_year": source_year,
        "sites": len(fixed_values),
        "site_equal_mean_projection": point,
        "site_bootstrap_ci_low": float(np.quantile(site_only, 0.025)),
        "site_bootstrap_ci_high": float(np.quantile(site_only, 0.975)),
        "positive_sites": int((fixed_values > 0).sum()),
        "mean_cosine_similarity": cosine_point,
        "cosine_site_bootstrap_ci_low": float(np.quantile(site_only_cosine, 0.025)),
        "cosine_site_bootstrap_ci_high": float(np.quantile(site_only_cosine, 0.975)),
        "positive_cosine_sites": int((fixed_cosines > 0).sum()),
    }])
    return (
        pd.DataFrame(leave_rows), pd.DataFrame(projection_rows),
        pd.DataFrame(cosine_rows), small_sample,
        pd.concat([site_values, summary.assign(site="__SUMMARY__")], ignore_index=True, sort=False),
    )


def full_source_target_bootstrap(
    source: np.ndarray, target: np.ndarray, replicates: int, seed: int
) -> list[dict]:
    rng = np.random.default_rng(seed)
    fixed_direction = unit(source.mean(axis=0))
    point = float((target @ fixed_direction).mean())
    joint = np.empty(replicates)
    source_only = np.empty(replicates)
    target_only = np.empty(replicates)
    for start in range(0, replicates, 5000):
        count = min(5000, replicates - start)
        source_index = rng.integers(0, len(source), size=(count, len(source)))
        target_index = rng.integers(0, len(target), size=(count, len(target)))
        directions = source[source_index].mean(axis=1)
        directions /= np.linalg.norm(directions, axis=1)[:, None]
        target_sample = target[target_index]
        joint[start:start+count] = np.einsum("nkd,nd->nk", target_sample, directions).mean(axis=1)
        source_only[start:start+count] = (target @ directions.T).mean(axis=0)
        target_only[start:start+count] = (target_sample @ fixed_direction).mean(axis=1)
    rows = []
    for method, draws in [
        ("joint source-basin and target-basin bootstrap", joint),
        ("source-basin bootstrap only", source_only),
        ("target-basin bootstrap only", target_only),
    ]:
        rows.append({
            "point_estimate": point,
            "uncertainty_method": method,
            "ci_low": float(np.quantile(draws, 0.025)),
            "median": float(np.quantile(draws, 0.5)),
            "ci_high": float(np.quantile(draws, 0.975)),
            "fraction_nonpositive": float(np.mean(draws <= 0)),
            "replicates": replicates,
        })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--basin-trajectory", type=Path, required=True)
    parser.add_argument("--usgs-events", type=Path, required=True)
    parser.add_argument("--formal-sites", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--replicates", type=int, default=50000)
    parser.add_argument("--seed", type=int, default=20269330)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    basin_trajectory = pd.read_csv(args.basin_trajectory)
    formal_sites = pd.read_csv(args.formal_sites).site.astype(str).tolist()
    events = pd.read_csv(args.usgs_events)
    site_year = site_year_trajectories(events, formal_sites)

    basins, shared_2024 = china_basin_matrices(basin_trajectory, 2024, SHARED_CHINA_VARIABLES)
    _, shared_2023 = china_basin_matrices(basin_trajectory, 2023, SHARED_CHINA_VARIABLES)
    _, full_2024 = china_basin_matrices(basin_trajectory, 2024, CHINA_VARIABLES)
    _, full_2023 = china_basin_matrices(basin_trajectory, 2023, CHINA_VARIABLES)

    china_rows = []
    for source_year, target_year, source, target, offset in [
        (2024, 2023, full_2024, full_2023, 0),
        (2023, 2024, full_2023, full_2024, 1),
    ]:
        rows = full_source_target_bootstrap(source, target, args.replicates, args.seed + 100 + offset)
        for row in rows:
            row["source_year"] = source_year
            row["target_year"] = target_year
            china_rows.append(row)
    pd.DataFrame(china_rows).to_csv(
        args.output_dir / "china_source_target_uncertainty.csv", index=False
    )

    leave_tables = []
    projection_tables = []
    cosine_tables = []
    small_tables = []
    source_year_tables = []
    for source_year, source, offset in [(2024, shared_2024, 0), (2023, shared_2023, 1000)]:
        leave, projection, cosine, small, source_year_table = external_uncertainty_for_year(
            source_year, source, basins, formal_sites, site_year,
            args.replicates, args.seed + offset
        )
        leave_tables.append(leave)
        projection_tables.append(projection)
        cosine_tables.append(cosine)
        small_tables.append(small)
        source_year_tables.append(source_year_table)

    pd.concat(leave_tables, ignore_index=True).to_csv(
        args.output_dir / "external_leave_one_china_basin.csv", index=False
    )
    pd.concat(projection_tables, ignore_index=True).to_csv(
        args.output_dir / "external_template_site_uncertainty.csv", index=False
    )
    pd.concat(cosine_tables, ignore_index=True).to_csv(
        args.output_dir / "external_cosine_uncertainty.csv", index=False
    )
    pd.concat(small_tables, ignore_index=True).to_csv(
        args.output_dir / "external_small_sample_sensitivity.csv", index=False
    )
    combined_source = pd.concat(source_year_tables, ignore_index=True, sort=False)
    combined_source.to_csv(
        args.output_dir / "external_source_year_sensitivity.csv", index=False
    )
    combined_source[~combined_source.site.eq("__SUMMARY__")].to_csv(
        args.output_dir / "external_cosine_site_values.csv", index=False
    )

    metadata = {
        "source_years": [2024, 2023],
        "reference_source_year": 2024,
        "source_basins": len(basins),
        "usgs_sites": len(formal_sites),
        "replicates": args.replicates,
        "seed": args.seed,
        "projection_definition": "target trajectory dot unit source template; target norm retained",
        "cosine_definition": "target trajectory and source template both norm-normalised",
        "inference_note": (
            "China-source and joint intervals are structured sensitivity analyses because the basin and site sets are not probability samples."
        ),
        "status": "PASS",
    }
    (args.output_dir / "analysis_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
