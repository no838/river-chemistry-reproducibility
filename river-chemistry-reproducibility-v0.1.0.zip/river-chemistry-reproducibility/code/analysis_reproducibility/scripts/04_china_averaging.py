#!/usr/bin/env python3
"""Estimate attenuation from eight-hour block averaging.

The distributed event-block intermediate contains a precomputed shared-five
phase score. The score uses the fixed 2024 five-variable constituent direction
and the same transformed, first-differenced, month-hour-centred,
section-year-IQR-scaled and clipped event changes used by the China event
analysis. The 2023 averaging estimate is the primary cross-year evaluation;
2024 is a reference-year descriptive sensitivity. The sampling contrast is
conditional on retaining the final four-hour observation in each eight-hour
block.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def exact_signflip(values: np.ndarray) -> float:
    array = np.asarray(values, float)
    observed = float(array.mean())
    n = len(array)
    count = 0
    for bits in range(2 ** n):
        signs = np.array([1 if (bits >> index) & 1 else -1 for index in range(n)])
        if np.mean(array * signs) >= observed - 1e-15:
            count += 1
    return float(count / (2 ** n))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--event-block-metrics", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260717)
    parser.add_argument("--bootstraps", type=int, default=50000)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    data = pd.read_csv(args.event_block_metrics)
    required = {
        "year", "basin", "unit_id", "episode_id",
        "native_peakmax_minus_pre", "sample8_peakmax_minus_pre",
        "average8_peakmax_minus_pre", "contrast8_peakmax",
    }
    missing = required - set(data.columns)
    if missing:
        raise ValueError(f"Event-block input is missing columns: {sorted(missing)}")

    basin = (
        data.groupby(["year", "basin"], as_index=False)
        .agg(
            basin_median_native_4h_peak=("native_peakmax_minus_pre", "median"),
            basin_median_block_end_sampled_8h_peak=("sample8_peakmax_minus_pre", "median"),
            basin_median_averaged_8h_peak=("average8_peakmax_minus_pre", "median"),
            basin_median_paired_sampled_minus_averaged=("contrast8_peakmax", "median"),
            n_sections=("unit_id", "nunique"),
            n_episodes=("episode_id", "nunique"),
        )
    )
    basin["difference_of_basin_medians"] = (
        basin.basin_median_block_end_sampled_8h_peak
        - basin.basin_median_averaged_8h_peak
    )
    basin["sampled_endpoint_rule"] = "final 4-h observation in each 8-h block"
    basin["score_direction_year"] = 2024
    basin["score_direction_held_out"] = False
    basin["evidence_role"] = np.where(
        basin.year.eq(2023),
        "primary cross-year averaging evaluation",
        "reference-year descriptive sensitivity",
    )
    basin.to_csv(args.output_dir / "averaging_basin.csv", index=False)

    rows = []
    for year in [2023, 2024]:
        subset = basin[basin.year.eq(year)].copy()
        contrast = subset.basin_median_paired_sampled_minus_averaged.to_numpy(float)
        sampled = subset.basin_median_block_end_sampled_8h_peak.to_numpy(float)
        rng = np.random.default_rng(args.seed + year)
        sample_indices = rng.integers(0, len(subset), size=(args.bootstraps, len(subset)))
        contrast_draws = contrast[sample_indices].mean(axis=1)
        denominator_draws = sampled[sample_indices].mean(axis=1)
        ratio_draws = np.divide(
            contrast_draws,
            denominator_draws,
            out=np.full_like(contrast_draws, np.nan),
            where=denominator_draws > 0,
        )
        ratio_draws = ratio_draws[np.isfinite(ratio_draws)]
        rows.append({
            "year": year,
            "evidence_role": (
                "primary cross-year averaging evaluation"
                if year == 2023 else "reference-year descriptive sensitivity"
            ),
            "score_direction_year": 2024,
            "score_direction_held_out": False,
            "n_basins": len(subset),
            "mean_of_basin_median_paired_contrasts": float(contrast.mean()),
            "mean_of_basin_sampled_medians": float(subset.basin_median_block_end_sampled_8h_peak.mean()),
            "mean_of_basin_averaged_medians": float(subset.basin_median_averaged_8h_peak.mean()),
            "difference_of_the_two_mean_medians": float(
                subset.basin_median_block_end_sampled_8h_peak.mean()
                - subset.basin_median_averaged_8h_peak.mean()
            ),
            "paired_contrast_is_not_difference_of_medians": True,
            "attenuation_percent_relative_to_mean_sampled_median": float(
                100 * contrast.mean() / subset.basin_median_block_end_sampled_8h_peak.mean()
            ),
            "paired_contrast_ci_low": float(np.quantile(contrast_draws, 0.025)),
            "paired_contrast_ci_high": float(np.quantile(contrast_draws, 0.975)),
            "attenuation_ci_low_percent": float(100 * np.quantile(ratio_draws, 0.025)),
            "attenuation_ci_high_percent": float(100 * np.quantile(ratio_draws, 0.975)),
            "positive_basins": int((contrast > 0).sum()),
            "exact_signflip_p": exact_signflip(contrast),
            "bootstrap_replicates": args.bootstraps,
            "sampled_endpoint_rule": "final 4-h observation in each 8-h block",
        })
    summary = pd.DataFrame(rows)
    summary.to_csv(args.output_dir / "averaging_summary.csv", index=False)

    metadata = {
        "input": Path(*args.event_block_metrics.parts[-3:]).as_posix(),
        "seed": args.seed,
        "bootstrap_replicates": args.bootstraps,
        "score": {
            "variables": ["water temperature", "pH", "dissolved oxygen", "conductance", "turbidity"],
            "direction_year": 2024,
            "direction_definition": "2024 five-variable constituent direction",
            "held_out": False,
            "upstream_transform": "ln(1 + x) where specified; first difference; section-month-clock-bin centring; section-year IQR scaling; clipping to [-8, 8]",
            "phase_window": "peak-window maximum relative to the pre-event baseline",
            "provenance_boundary": "score values are supplied as a pseudonymised sufficient intermediate",
        },
        "estimand": "basin-equal mean of within-basin medians of paired block-end-sampled minus block-averaged peak differences",
        "primary_year": 2023,
        "reference_year_sensitivity": 2024,
        "sampling_rule": "final four-hour observation retained in each eight-hour block",
        "status": "PASS",
    }
    (args.output_dir / "analysis_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
