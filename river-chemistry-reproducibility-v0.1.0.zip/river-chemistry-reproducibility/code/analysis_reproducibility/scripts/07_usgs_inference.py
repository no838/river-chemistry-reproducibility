#!/usr/bin/env python3
"""Recalculate USGS event-trajectory inference from the supplied event intermediate."""
from __future__ import annotations

import argparse
import itertools
import warnings
import json
from pathlib import Path

import numpy as np
import pandas as pd
from numba import njit, prange
from scipy.stats import t as student_t

VARIABLES = ["water_temp", "pH", "DO", "EC", "turbidity"]
RELATIVE_HOURS = np.arange(-24, 49, 4)
PRE = [-24, -20, -16]
PEAK = [0, 4, 8]
LATE = [28, 32, 36, 40, 44, 48]


def event_columns():
    return [f"{variable}_{hour}" for hour in RELATIVE_HOURS for variable in VARIABLES]


def exact_signflip(values, alternative="greater"):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    observed = float(x.mean())
    null = []
    for bits in range(2 ** len(x)):
        signs = np.array([1 if (bits >> j) & 1 else -1 for j in range(len(x))])
        null.append(float(np.mean(x * signs)))
    null = np.asarray(null)
    if alternative == "greater":
        return float(np.mean(null >= observed - 1e-15))
    if alternative == "less":
        return float(np.mean(null <= observed + 1e-15))
    return float(np.mean(np.abs(null) >= abs(observed) - 1e-15))


def holm(raw_p):
    p = np.asarray(raw_p, float)
    order = np.argsort(p)
    adjusted = np.empty(len(p))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, (len(p) - rank) * p[index])
        adjusted[index] = min(1.0, running)
    return adjusted


def bootstrap_mean(values, replicates, seed):
    x = np.asarray(values, float)
    rng = np.random.default_rng(seed)
    draws = rng.choice(x, (replicates, len(x)), replace=True).mean(axis=1)
    return tuple(np.quantile(draws, [0.025, 0.975]))


def template_matrix(path):
    table = pd.read_csv(path).set_index("rel_h").reindex(RELATIVE_HOURS)
    matrix = table[[f"d_{variable}" for variable in VARIABLES]].to_numpy(float)
    direction = matrix.ravel() / np.linalg.norm(matrix.ravel())
    return matrix, direction


def t_interval(values):
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    if len(x) < 2:
        return np.nan, np.nan
    mean = float(x.mean())
    se = float(x.std(ddof=1) / np.sqrt(len(x)))
    critical = float(student_t.ppf(0.975, len(x) - 1))
    return mean - critical * se, mean + critical * se


def event_phase_metrics(row):
    projection = {hour: float(row[f"proj_{hour}"]) for hour in RELATIVE_HOURS}
    pre = float(np.mean([projection[h] for h in PRE]))
    peak = float(np.mean([projection[h] for h in PEAK]))
    late = float(np.mean([projection[h] for h in LATE]))
    return pre, peak, late, peak - pre, late - peak


def site_year_objects(events, template, template_direction):
    columns = event_columns()
    phase_rows = []
    for _, row in events.iterrows():
        pre, peak, late, peak_minus_pre, late_minus_peak = event_phase_metrics(row)
        phase_rows.append({
            "site": row.site,
            "year": int(row.year),
            "event_id": row.event_id,
            "pre": pre,
            "peak": peak,
            "late": late,
            "peak_minus_pre": peak_minus_pre,
            "late_minus_peak": late_minus_peak,
        })
    event_phase = pd.DataFrame(phase_rows)
    phase_summary = event_phase.groupby(["site", "year"], as_index=False)[
        ["pre", "peak", "late", "peak_minus_pre", "late_minus_peak"]
    ].median()
    counts = event_phase.groupby(["site", "year"]).size().rename("n_events").reset_index()
    phase_summary = phase_summary.merge(counts, on=["site", "year"])
    phase_summary = phase_summary[phase_summary.n_events.ge(3)]

    site_year_rows, contribution_rows = [], []
    for (site, year), group in events.groupby(["site", "year"], sort=True):
        event_matrix = group[columns].apply(pd.to_numeric, errors="coerce").to_numpy(float)
        median_trajectory = np.nanmedian(event_matrix, axis=0).reshape(len(RELATIVE_HOURS), len(VARIABLES))
        contributions = np.sum(median_trajectory * template, axis=1) / np.linalg.norm(template.ravel())
        whole_projection = float(contributions.sum())
        q = phase_summary[(phase_summary.site.eq(site)) & (phase_summary.year.eq(year))]
        values = {name: np.nan for name in ["pre", "peak", "late", "peak_minus_pre", "late_minus_peak"]}
        if not q.empty:
            values.update({name: float(q.iloc[0][name]) for name in values})
        site_year_rows.append({
            "site": site,
            "year": int(year),
            "n_events": len(group),
            "whole_trajectory_projection": whole_projection,
            **values,
        })
        for hour, contribution in zip(RELATIVE_HOURS, contributions):
            contribution_rows.append({
                "site": site,
                "year": int(year),
                "rel_h": int(hour),
                "time_contribution": float(contribution),
            })
    return pd.DataFrame(site_year_rows), pd.DataFrame(contribution_rows), event_phase


def site_point_estimates(site_year, contributions, events, formal_sites, years):
    selected = site_year[site_year.site.isin(formal_sites) & site_year.year.isin(years)].copy()
    selected_events = events[events.site.isin(formal_sites) & events.year.isin(years)].copy()
    rows, time_rows, qa_rows = [], [], []
    for site, group in selected.groupby("site", sort=True):
        group = group.sort_values("whole_trajectory_projection")
        values = group.whole_trajectory_projection.to_numpy(float)
        years_available = group.year.to_numpy(int)
        if len(values) % 2:
            defining_years, weights = [int(years_available[len(values) // 2])], [1.0]
        else:
            defining_years = [int(years_available[len(values) // 2 - 1]), int(years_available[len(values) // 2])]
            weights = [0.5, 0.5]
        projection = float(np.median(values))
        contribution = np.zeros(len(RELATIVE_HOURS))
        for year, weight in zip(defining_years, weights):
            contribution += weight * contributions[
                contributions.site.eq(site) & contributions.year.eq(year)
            ].sort_values("rel_h").time_contribution.to_numpy(float)
        phase_values = group[["pre", "peak", "late", "peak_minus_pre", "late_minus_peak"]].median(numeric_only=True)
        rows.append({
            "site": site,
            "projection": projection,
            "pre": phase_values["pre"],
            "peak": phase_values["peak"],
            "late": phase_values["late"],
            "peak_minus_pre": phase_values["peak_minus_pre"],
            "late_minus_peak": phase_values["late_minus_peak"],
            "n_events": len(selected_events[selected_events.site.eq(site)]),
            "n_site_years": len(group),
            "median_defining_years": "|".join(map(str, defining_years)),
        })
        for hour, value in zip(RELATIVE_HOURS, contribution):
            time_rows.append({
                "site": site,
                "rel_h": int(hour),
                "time_contribution": float(value),
                "site_projection": projection,
            })
        qa_rows.append({
            "site": site,
            "projection": projection,
            "sum_time_contributions": float(contribution.sum()),
            "absolute_residual": abs(projection - float(contribution.sum())),
        })
    return pd.DataFrame(rows), pd.DataFrame(time_rows), pd.DataFrame(qa_rows)


def nested_site_ci(site_events, template_direction, replicates, seed):
    columns = event_columns()
    years = sorted(site_events.year.unique())
    arrays = {
        int(year): site_events[site_events.year.eq(year)][columns].apply(pd.to_numeric, errors="coerce").to_numpy(float)
        for year in years
    }
    rng = np.random.default_rng(seed)
    values = np.empty(replicates)
    for replicate in range(replicates):
        sampled_years = rng.choice(years, len(years), replace=True)
        year_values = []
        for year in sampled_years:
            array = arrays[int(year)]
            sampled_events = array[rng.integers(0, len(array), len(array))]
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=RuntimeWarning)
                median = np.nanmedian(sampled_events, axis=0)
            if np.isfinite(median).all():
                year_values.append(float(median @ template_direction))
        values[replicate] = float(np.median(year_values)) if year_values else np.nan
    values = values[np.isfinite(values)]
    return tuple(np.quantile(values, [0.025, 0.975])), len(values)


@njit(parallel=True, cache=True)
def _bootstrap_site_year_metrics(trajectory, phase, indices, direction):
    """Elementwise event-median trajectory and event-median phase metrics."""
    replicates, n_events = indices.shape
    n_dimensions = trajectory.shape[1]
    output = np.empty((replicates, 3), dtype=np.float64)
    for replicate in prange(replicates):
        whole = 0.0
        for dimension in range(n_dimensions):
            values = np.empty(n_events, dtype=np.float64)
            n_valid = 0
            for event_position in range(n_events):
                value = trajectory[indices[replicate, event_position], dimension]
                if not np.isnan(value):
                    values[n_valid] = value
                    n_valid += 1
            if n_valid == 0:
                median_value = np.nan
            else:
                ordered = np.sort(values[:n_valid])
                if n_valid % 2:
                    median_value = ordered[n_valid // 2]
                else:
                    median_value = 0.5 * (ordered[n_valid // 2 - 1] + ordered[n_valid // 2])
            whole += median_value * direction[dimension]
        output[replicate, 0] = whole
        for phase_index in range(2):
            values = np.empty(n_events, dtype=np.float64)
            n_valid = 0
            for event_position in range(n_events):
                value = phase[indices[replicate, event_position], phase_index]
                if not np.isnan(value):
                    values[n_valid] = value
                    n_valid += 1
            if n_valid == 0:
                output[replicate, phase_index + 1] = np.nan
            else:
                ordered = np.sort(values[:n_valid])
                if n_valid % 2:
                    output[replicate, phase_index + 1] = ordered[n_valid // 2]
                else:
                    output[replicate, phase_index + 1] = 0.5 * (
                        ordered[n_valid // 2 - 1] + ordered[n_valid // 2]
                    )
    return output


def hierarchical_pooled_bootstrap(events, formal_sites, template, replicates, seed):
    """Resample sites, years within sites, and events within years.

    Event-resampling distributions are generated independently for every site-year.
    Pooled replicates then resample sites and years and draw independently from the
    corresponding site-year event-bootstrap distributions.
    """
    columns = event_columns()
    direction = template.ravel() / np.linalg.norm(template.ravel())
    selected = events[
        events.site.isin(formal_sites) & events.year.isin([2022, 2023, 2024])
    ].copy()
    rng = np.random.default_rng(seed)
    site_year_draws = {}
    years_by_site = {}
    for group_index, ((site, year), group) in enumerate(
        selected.groupby(["site", "year"], sort=True)
    ):
        trajectory = group[columns].apply(pd.to_numeric, errors="coerce").to_numpy(float)
        phase = np.asarray([event_phase_metrics(row) for _, row in group.iterrows()], float)[:, [3, 4]]
        indices = rng.integers(
            0, len(trajectory), size=(replicates, len(trajectory)), dtype=np.int16
        )
        site_year_draws[(site, int(year))] = _bootstrap_site_year_metrics(
            trajectory, phase, indices, direction
        )
        years_by_site.setdefault(site, []).append(int(year))
    for site in years_by_site:
        years_by_site[site] = sorted(years_by_site[site])

    sampled_sites = rng.integers(
        0, len(formal_sites), size=(replicates, len(formal_sites)), dtype=np.int16
    )
    occurrence_values = np.full((replicates, len(formal_sites), 3), np.nan, float)
    for position in range(len(formal_sites)):
        for site_index, site in enumerate(formal_sites):
            rows = np.flatnonzero(sampled_sites[:, position] == site_index)
            if not len(rows):
                continue
            for metric_index in range(3):
                valid_years = [
                    year for year in years_by_site[site]
                    if np.isfinite(site_year_draws[(site, year)][:, metric_index]).any()
                ]
                if not valid_years:
                    continue
                sampled_year_positions = rng.integers(
                    0, len(valid_years), size=(len(rows), len(valid_years)), dtype=np.int16
                )
                year_values = np.full((len(rows), len(valid_years)), np.nan, float)
                for year_position in range(len(valid_years)):
                    for source_year_position, year in enumerate(valid_years):
                        target_rows = np.flatnonzero(
                            sampled_year_positions[:, year_position] == source_year_position
                        )
                        if not len(target_rows):
                            continue
                        draws = site_year_draws[(site, year)][:, metric_index]
                        valid_draws = np.flatnonzero(np.isfinite(draws))
                        bootstrap_indices = rng.choice(
                            valid_draws, size=len(target_rows), replace=True
                        )
                        year_values[target_rows, year_position] = draws[bootstrap_indices]
                occurrence_values[rows, position, metric_index] = np.median(
                    year_values, axis=1
                )
    if not np.isfinite(occurrence_values).all():
        raise RuntimeError("Hierarchical bootstrap produced non-finite site occurrences")
    return occurrence_values.mean(axis=1)


def relabelling(events, template, formal_sites, years):
    selected = events[events.site.isin(formal_sites) & events.year.isin(years)].copy()
    columns = event_columns()
    medians = {}
    for (site, year), group in selected.groupby(["site", "year"]):
        medians[(site, int(year))] = np.nanmedian(group[columns].to_numpy(float), axis=0).reshape(len(RELATIVE_HOURS), len(VARIABLES))
    rows = []
    for permutation in itertools.permutations(range(len(VARIABLES))):
        permuted = template[:, permutation]
        direction = permuted.ravel() / np.linalg.norm(permuted.ravel())
        site_values = []
        for site in sorted(selected.site.unique()):
            year_values = [
                float(medians[(site, int(year))].ravel() @ direction)
                for year in sorted(selected[selected.site.eq(site)].year.unique())
            ]
            site_values.append(float(np.median(year_values)))
        rows.append({
            "mode": "Raw projection",
            "permutation": ";".join(map(str, permutation)),
            "site_equal_mean": np.mean(site_values),
            "positive_sites": int(np.sum(np.asarray(site_values) > 0)),
            "identity": permutation == tuple(range(len(VARIABLES))),
        })
    return pd.DataFrame(rows)


def leave_one_variable_out(events, template, formal_sites, years, replicates, seed):
    selected = events[events.site.isin(formal_sites) & events.year.isin(years)].copy()
    medians = {}
    for (site, year), group in selected.groupby(["site", "year"]):
        medians[(site, int(year))] = np.nanmedian(group[event_columns()].to_numpy(float), axis=0).reshape(len(RELATIVE_HOURS), len(VARIABLES))
    options = [("none", list(range(5)))] + [
        (VARIABLES[j], [k for k in range(5) if k != j]) for j in range(5)
    ]
    rows = []
    for index, (name, selected_variables) in enumerate(options):
        selected_template = template[:, selected_variables]
        direction = selected_template.ravel() / np.linalg.norm(selected_template.ravel())
        site_values = []
        for site in sorted(selected.site.unique()):
            year_values = [
                float(medians[(site, int(year))][:, selected_variables].ravel() @ direction)
                for year in sorted(selected[selected.site.eq(site)].year.unique())
            ]
            site_values.append(float(np.median(year_values)))
        site_values = np.asarray(site_values)
        ci = bootstrap_mean(site_values, replicates, seed + index)
        rows.append({
            "omitted_variable": name,
            "n_sites": len(site_values),
            "mean_projection": site_values.mean(),
            "median_projection": np.median(site_values),
            "ci_low": ci[0],
            "ci_high": ci[1],
            "positive_sites": int((site_values > 0).sum()),
            "exact_p_greater": exact_signflip(site_values, "greater"),
        })
    output = pd.DataFrame(rows)
    output["holm_p"] = holm(output.exact_p_greater.to_numpy(float))
    return output


def spatial_grouping(site_table, metadata):
    metadata = pd.read_csv(metadata, dtype={"hydrologic_unit_code": "string"}).set_index("id")
    values = site_table.set_index("site").projection
    rows = []
    for level, characters in [("site", None), ("huc8", 8), ("huc2", 2)]:
        if level == "site":
            grouped = values.copy()
        else:
            groups = {}
            for site, value in values.items():
                huc = str(metadata.loc[site, "hydrologic_unit_code"]).split(".")[0].zfill(12)[:characters]
                groups.setdefault(huc, []).append(value)
            grouped = pd.Series({key: np.mean(group) for key, group in groups.items()})
        rows.append({
            "aggregation_level": level,
            "n_units": len(grouped),
            "mean_projection": grouped.mean(),
            "positive_units": int((grouped > 0).sum()),
            "exact_signflip_p_greater": exact_signflip(grouped.to_numpy(), "greater"),
            "unit_values": json.dumps(grouped.to_dict(), sort_keys=True),
        })
    return pd.DataFrame(rows)


def period_sensitivity(site_year, periods, replicates, seed):
    rows, site_rows = [], []
    for index, (label, start, end, formal_only, formal_sites) in enumerate(periods):
        selected = site_year[site_year.year.between(start, end)].copy()
        if formal_only:
            selected = selected[selected.site.isin(formal_sites)]
        site_values = selected.groupby("site").whole_trajectory_projection.median()
        ci = bootstrap_mean(site_values.to_numpy(), replicates, seed + index)
        rows.append({
            "Period": label,
            "Start": start,
            "End": end,
            "Sites": len(site_values),
            "Site-years": len(selected),
            "Events": int(selected.n_events.sum()),
            "Mean projection": site_values.mean(),
            "Lower 95% CI": ci[0],
            "Upper 95% CI": ci[1],
            "Positive sites": int((site_values > 0).sum()),
            "Exact sign-flip P": exact_signflip(site_values.to_numpy(), "greater"),
            "CI method": f"site bootstrap ({replicates:,} replicates)",
            "Bootstrap seed": seed + index,
        })
        for site, value in site_values.items():
            site_rows.append({"Period": label, "site": site, "projection": value})
    return pd.DataFrame(rows), pd.DataFrame(site_rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--template", type=Path, required=True)
    parser.add_argument("--metadata", type=Path, required=True)
    parser.add_argument("--formal-sites", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260722)
    parser.add_argument("--site-bootstraps", type=int, default=4000)
    parser.add_argument("--pooled-bootstraps", type=int, default=50000)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    events = pd.read_csv(args.events)
    formal_sites = pd.read_csv(args.formal_sites).site.astype(str).tolist()
    template, template_direction = template_matrix(args.template)
    site_year, site_year_contributions, event_phase = site_year_objects(events, template, template_direction)
    site, time_contributions, decomposition_qa = site_point_estimates(
        site_year, site_year_contributions, events, formal_sites, [2022, 2023, 2024]
    )

    site_ci_rows = []
    selected_events = events[events.site.isin(formal_sites) & events.year.isin([2022, 2023, 2024])]
    for _, row in site.iterrows():
        ci, n = nested_site_ci(
            selected_events[selected_events.site.eq(row.site)],
            template_direction,
            args.site_bootstraps,
            args.seed + sum(map(ord, row.site)),
        )
        site_ci_rows.append({**row.to_dict(), "ci_low": ci[0], "ci_high": ci[1], "bootstrap_replicates": n})
    site = pd.DataFrame(site_ci_rows)

    hierarchical_bootstrap = hierarchical_pooled_bootstrap(
        events, formal_sites, template, args.pooled_bootstraps, args.seed + 1000
    )
    definitions = [
        ("Whole-trajectory projection", "projection", "greater", 0),
        ("Peak minus pre-event", "peak_minus_pre", "greater", 1),
        ("Late minus peak", "late_minus_peak", "less", 2),
    ]
    family_rows = []
    hierarchical_rows = []
    for index, (name, column, alternative, bootstrap_column) in enumerate(definitions):
        values = site[column].to_numpy(float)
        primary_ci = bootstrap_mean(
            values, args.pooled_bootstraps, args.seed + index
        )
        hierarchical_ci = np.quantile(
            hierarchical_bootstrap[:, bootstrap_column], [0.025, 0.975]
        )
        t_ci = t_interval(values)
        family_rows.append({
            "Test": name,
            "Alternative": alternative,
            "Sites": len(values),
            "Estimate": values.mean(),
            "Lower 95% CI": primary_ci[0],
            "Upper 95% CI": primary_ci[1],
            "t CI lower": t_ci[0],
            "t CI upper": t_ci[1],
            "Exact P": exact_signflip(values, alternative),
            "Direction consistency": float(np.mean(values > 0) if alternative == "greater" else np.mean(values < 0)),
            "Bootstrap method": "site bootstrap",
            "Bootstrap replicates": args.pooled_bootstraps,
            "Bootstrap seed": args.seed + index,
        })
        hierarchical_rows.append({
            "Test": name,
            "Estimate": values.mean(),
            "Lower 95% CI": hierarchical_ci[0],
            "Upper 95% CI": hierarchical_ci[1],
            "Bootstrap method": "site-year-event hierarchical sensitivity",
            "Bootstrap replicates": args.pooled_bootstraps,
            "Bootstrap seed": args.seed + 1000,
        })
    family = pd.DataFrame(family_rows)
    family["Holm-adjusted P"] = holm(family["Exact P"].to_numpy(float))
    hierarchical_sensitivity = pd.DataFrame(hierarchical_rows)

    relabelled = relabelling(events, template, formal_sites, [2022, 2023, 2024])
    leave_one = leave_one_variable_out(
        events, template, formal_sites, [2022, 2023, 2024], args.pooled_bootstraps, args.seed + 300
    )
    spatial = spatial_grouping(site, args.metadata)
    periods = [
        ("2019-2021 comparison", 2019, 2021, False, formal_sites),
        ("2022-2024 analysis", 2022, 2024, True, formal_sites),
        ("2019-2024 broader comparison", 2019, 2024, False, formal_sites),
    ]
    period_summary, period_sites = period_sensitivity(site_year, periods, args.pooled_bootstraps, args.seed + 500)
    # The 2022-2024 row is the same site-equal estimand as the formal whole-trajectory result.
    # Use the identical site-bootstrap interval and seed rather than a second Monte Carlo run.
    whole = family[family["Test"].eq("Whole-trajectory projection")].iloc[0]
    formal_mask = period_summary["Period"].eq("2022-2024 analysis")
    period_summary.loc[formal_mask, "Mean projection"] = whole["Estimate"]
    period_summary.loc[formal_mask, "Lower 95% CI"] = whole["Lower 95% CI"]
    period_summary.loc[formal_mask, "Upper 95% CI"] = whole["Upper 95% CI"]
    period_summary.loc[formal_mask, "Exact sign-flip P"] = whole["Exact P"]
    period_summary.loc[formal_mask, "CI method"] = whole["Bootstrap method"] + f" ({int(whole['Bootstrap replicates']):,} replicates)"
    period_summary.loc[formal_mask, "Bootstrap seed"] = int(whole["Bootstrap seed"])

    contribution_matrix = time_contributions.pivot(index="site", columns="rel_h", values="time_contribution").reindex(index=formal_sites, columns=RELATIVE_HOURS)
    rng = np.random.default_rng(args.seed + 900)
    sampled = rng.integers(0, len(contribution_matrix), size=(args.pooled_bootstraps, len(contribution_matrix)))
    contribution_draws = contribution_matrix.to_numpy(float)[sampled].mean(axis=1)
    contribution_summary = pd.DataFrame({
        "rel_h": RELATIVE_HOURS,
        "mean_time_contribution": contribution_matrix.mean(axis=0).to_numpy(float),
        "ci_low": np.quantile(contribution_draws, 0.025, axis=0),
        "ci_high": np.quantile(contribution_draws, 0.975, axis=0),
        "n_sites": len(contribution_matrix),
        "bootstrap_method": "site bootstrap",
        "bootstrap_replicates": args.pooled_bootstraps,
    })

    identity = relabelled[relabelled.identity].iloc[0]
    identity_rank = int((relabelled.site_equal_mean >= identity.site_equal_mean - 1e-15).sum())
    summary = {
        "formal_sites": len(site),
        "formal_events": int(len(selected_events)),
        "pooled_mean": float(site.projection.mean()),
        "positive_sites": int((site.projection > 0).sum()),
        "exact_p": exact_signflip(site.projection.to_numpy(), "greater"),
        "decomposition_max_abs_residual": float(decomposition_qa.absolute_residual.max()),
        "identity_rank_descending": identity_rank,
        "identity_permutation_p": float(identity_rank / len(relabelled)),
        "seed": args.seed,
        "site_bootstraps": args.site_bootstraps,
        "pooled_bootstraps": args.pooled_bootstraps,
        "status": "PASS" if decomposition_qa.absolute_residual.max() < 1e-10 else "FAIL",
    }

    site_year.to_csv(args.output_dir / "site_year_metrics.csv", index=False)
    site_year_contributions.to_csv(args.output_dir / "site_year_time_contributions.csv", index=False)
    event_phase.to_csv(args.output_dir / "event_phase_metrics.csv.gz", index=False, compression="gzip")
    site.to_csv(args.output_dir / "site_projections.csv", index=False)
    time_contributions.to_csv(args.output_dir / "site_time_contributions.csv", index=False)
    contribution_summary.to_csv(args.output_dir / "mean_time_contributions.csv", index=False)
    decomposition_qa.to_csv(args.output_dir / "projection_decomposition_QA.csv", index=False)
    family.to_csv(args.output_dir / "primary_three_test_family.csv", index=False)
    hierarchical_sensitivity.to_csv(
        args.output_dir / "hierarchical_uncertainty_sensitivity.csv", index=False
    )
    relabelled.to_csv(args.output_dir / "constituent_relabelling.csv", index=False)
    leave_one.to_csv(args.output_dir / "leave_one_variable_out.csv", index=False)
    spatial.to_csv(args.output_dir / "spatial_grouping.csv", index=False)
    period_summary.to_csv(args.output_dir / "period_sensitivity.csv", index=False)
    period_sites.to_csv(args.output_dir / "period_site_values.csv", index=False)
    np.save(
        args.output_dir / "hierarchical_pooled_bootstrap_draws.npy",
        hierarchical_bootstrap,
    )
    (args.output_dir / "analysis_metadata.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
