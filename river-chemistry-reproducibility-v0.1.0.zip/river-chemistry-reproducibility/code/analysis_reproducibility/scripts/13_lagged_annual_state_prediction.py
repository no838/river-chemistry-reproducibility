#!/usr/bin/env python3
"""Test whether lagged annual hydrochemical state predicts fast event response.

Primary estimand
-----------------
For sections observed in both event years,
    ΔR_i = β1 ΔPC1_i + β2 ΔPC2_i + basin fixed effects + ε_i,
where 2023 event responses are paired with 2022 annual-state coordinates and
2024 responses with 2023 annual-state coordinates. Differencing removes
time-invariant section attributes.

The distributed section-event response score is a fixed projection on the
2024-defined nine-variable China response direction. The mechanism analysis is
therefore an exploratory lagged-state prediction test, not a cross-fitted causal
effect estimate.

Sensitivity analyses add all nine PCs, event-forcing/support covariates,
basin-equal weighting, bidirectional held-out prediction and section-cluster
robust repeated-section models.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

OUTCOMES = ["peak_minus_pre", "late_minus_peak"]
PC_COLUMNS = [f"PC{i}" for i in range(1, 10)]
LAG_YEAR = {2023: 2022, 2024: 2023}
FORCING_COLUMNS = [
    "peak_forcing4h_score",
    "peak_precip4h_mm",
    "peak_runoff4h_mm",
    "match_cost",
    "n_episodes",
]


def plus_one(count: int, total: int) -> float:
    return float((count + 1) / (total + 1))


def holm(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, float)
    order = np.argsort(values)
    adjusted = np.empty(len(values), float)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, (len(values) - rank) * values[index])
        adjusted[index] = min(1.0, running)
    return adjusted


def standardize(values: pd.Series | np.ndarray) -> np.ndarray:
    array = np.asarray(values, float)
    sd = float(np.std(array, ddof=1))
    if not np.isfinite(sd) or sd <= 0:
        raise ValueError("Non-positive predictor standard deviation")
    return (array - np.mean(array)) / sd


def basin_matrix(values: pd.Series, levels: list[str] | None = None, drop_first: bool = True):
    series = values.astype(str)
    if levels is None:
        levels = sorted(series.unique())
    columns = levels[1:] if drop_first else levels
    matrix = (
        np.column_stack([(series == value).to_numpy(float) for value in columns])
        if columns
        else np.empty((len(series), 0), float)
    )
    return matrix, levels


def weighted_fit(X: np.ndarray, y: np.ndarray, weights: np.ndarray | None = None):
    if weights is None:
        weights = np.ones(len(y), float)
    sqrt_weights = np.sqrt(np.asarray(weights, float))
    beta = np.linalg.lstsq(X * sqrt_weights[:, None], y * sqrt_weights, rcond=None)[0]
    residual = y - X @ beta
    weighted_mean = np.average(y, weights=weights)
    sse = float(np.sum(weights * residual**2))
    sst = float(np.sum(weights * (y - weighted_mean) ** 2))
    r2 = 1 - sse / sst if sst > 0 else np.nan
    return beta, sse, r2


def partial_r2(X: np.ndarray, X0: np.ndarray, y: np.ndarray, weights=None):
    _, _, full_r2 = weighted_fit(X, y, weights)
    _, _, base_r2 = weighted_fit(X0, y, weights)
    return float((full_r2 - base_r2) / max(1 - base_r2, 1e-12))


def verify_eligibility(event_metrics: pd.DataFrame) -> pd.Series:
    inferred = (
        event_metrics["n_rel"].ge(12)
        & event_metrics["n_pre"].ge(2)
        & event_metrics["n_peak"].ge(2)
        & event_metrics["n_late"].ge(3)
    )
    supplied = event_metrics["eligible_primary"].astype(bool)
    if not inferred.equals(supplied):
        mismatches = int((inferred != supplied).sum())
        raise RuntimeError(f"eligible_primary disagrees with the declared rule in {mismatches} rows")
    return inferred


def build_section_year(event_metrics, crosswalk, coordinates, output_dir):
    event_metrics = event_metrics.copy()
    event_metrics["eligible_reconstructed"] = verify_eligibility(event_metrics)

    eligibility_rows = []
    for year, group in event_metrics.groupby("year", sort=True):
        eligibility_rows.append({
            "year": int(year),
            "all_section_event_units": int(group["unit_id"].nunique()),
            "all_section_episode_rows": int(len(group)),
            "eligible_section_event_units": int(group.loc[group["eligible_reconstructed"], "unit_id"].nunique()),
            "eligible_section_episode_rows": int(group["eligible_reconstructed"].sum()),
            "eligibility_rule": "n_rel >= 12; n_pre >= 2; n_peak >= 2; n_late >= 3",
        })
    pd.DataFrame(eligibility_rows).to_csv(output_dir / "eligibility_summary.csv", index=False)

    eligible = event_metrics[event_metrics["eligible_reconstructed"]].copy()
    section_year = (
        eligible.groupby(["year", "unit_id", "basin"], as_index=False)
        .agg(
            peak_minus_pre=("peak_minus_pre", "median"),
            late_minus_peak=("late_minus_peak", "median"),
            peak_forcing4h_score=("peak_forcing4h_score", "median"),
            peak_precip4h_mm=("peak_precip4h_mm", "median"),
            peak_runoff4h_mm=("peak_runoff4h_mm", "median"),
            match_cost=("match_cost", "median"),
            n_episodes=("episode_id", "nunique"),
        )
        .merge(crosswalk[["unit_id", "section_id"]], on="unit_id", how="left", validate="many_to_one")
    )
    if section_year["section_id"].isna().any():
        raise RuntimeError("Event-to-annual-state crosswalk is incomplete")

    state_rows = []
    for event_year, state_year in LAG_YEAR.items():
        state = coordinates.loc[
            coordinates["year"].eq(state_year),
            ["section_id"] + PC_COLUMNS + ["state_index", "state_class"],
        ].copy()
        state["state_year"] = state_year
        state_rows.append(
            section_year.loc[section_year["year"].eq(event_year)]
            .merge(state, on="section_id", how="inner", validate="many_to_one")
        )
    result = (
        pd.concat(state_rows, ignore_index=True)
        .sort_values(["year", "basin", "section_id"])
        .reset_index(drop=True)
    )
    result.to_csv(output_dir / "section_year_state_event.csv", index=False)

    flow_rows = []
    for year in [2023, 2024]:
        raw = event_metrics[event_metrics["year"].eq(year)]
        eligible_year = eligible[eligible["year"].eq(year)]
        linked = result[result["year"].eq(year)]
        flow_rows.extend([
            {
                "year": year,
                "stage": "all section-event units",
                "sections": int(raw["unit_id"].nunique()),
                "basins": int(raw["basin"].nunique()),
                "definition": "at least one matched episode row",
            },
            {
                "year": year,
                "stage": "eligible section-event units",
                "sections": int(eligible_year["unit_id"].nunique()),
                "basins": int(eligible_year["basin"].nunique()),
                "definition": "n_rel >= 12; n_pre >= 2; n_peak >= 2; n_late >= 3",
            },
            {
                "year": year,
                "stage": "linked lagged annual state",
                "sections": int(linked["section_id"].nunique()),
                "basins": int(linked["basin"].nunique()),
                "definition": f"annual state from {LAG_YEAR[year]} available",
            },
        ])
        for outcome in OUTCOMES:
            outcome_rows = linked[linked[outcome].notna()]
            flow_rows.append({
                "year": year,
                "stage": f"finite {outcome}",
                "sections": int(outcome_rows["section_id"].nunique()),
                "basins": int(outcome_rows["basin"].nunique()),
                "definition": "section-year median across eligible episodes",
            })
    pd.DataFrame(flow_rows).to_csv(output_dir / "analysis_domain_flow.csv", index=False)

    basin_rows = []
    for outcome in OUTCOMES:
        finite = result[result[outcome].notna()]
        for basin in sorted(finite["basin"].unique()):
            source = set(finite[(finite["year"].eq(2023)) & finite["basin"].eq(basin)]["section_id"])
            target = set(finite[(finite["year"].eq(2024)) & finite["basin"].eq(basin)]["section_id"])
            basin_rows.append({
                "outcome": outcome,
                "basin": basin,
                "sections_2023": len(source),
                "sections_2024": len(target),
                "repeated_sections": len(source & target),
            })
    pd.DataFrame(basin_rows).to_csv(output_dir / "basin_domain.csv", index=False)
    return result


def difference_frame(section_year, outcome):
    finite = section_year.dropna(subset=[outcome] + PC_COLUMNS).copy()
    source = finite[finite["year"].eq(2023)]
    target = finite[finite["year"].eq(2024)]
    merged = source.merge(
        target,
        on=["section_id", "unit_id"],
        suffixes=("_2023", "_2024"),
        validate="one_to_one",
    )
    merged["outcome"] = outcome
    merged["basin"] = merged["basin_2024"]
    merged["delta_response"] = merged[f"{outcome}_2024"] - merged[f"{outcome}_2023"]
    for pc in PC_COLUMNS:
        merged[f"delta_{pc}"] = merged[f"{pc}_2024"] - merged[f"{pc}_2023"]
    for column in FORCING_COLUMNS:
        merged[f"delta_{column}"] = merged[f"{column}_2024"] - merged[f"{column}_2023"]
    return merged


def design(frame, predictors, base_predictors=None, basin_equal=False):
    base_predictors = base_predictors or []
    basin, _ = basin_matrix(frame["basin"], drop_first=True)
    base_columns = [np.ones(len(frame)), basin]
    if base_predictors:
        base_columns.append(
            np.column_stack([standardize(frame[column]) for column in base_predictors])
        )
    X0 = np.column_stack(base_columns)
    state = np.column_stack([standardize(frame[column]) for column in predictors])
    X = np.column_stack([X0, state])
    if basin_equal:
        counts = frame.groupby("basin").size()
        weights = frame["basin"].map(lambda value: 1 / counts[value]).to_numpy(float)
    else:
        weights = np.ones(len(frame), float)
    return X, X0, weights


def within_basin_permutation(frame, predictors, base_predictors, replicates, seed, basin_equal=False, freedman_lane=False):
    X, X0, weights = design(frame, predictors, base_predictors, basin_equal)
    y = frame["delta_response"].to_numpy(float)
    observed = partial_r2(X, X0, y, weights)
    groups = [group.index.to_numpy() for _, group in frame.groupby("basin", sort=True)]
    rng = np.random.default_rng(seed)
    null = np.empty(replicates)

    if freedman_lane:
        beta0, _, _ = weighted_fit(X0, y, weights)
        fitted = X0 @ beta0
        residual = y - fitted
        for replicate in range(replicates):
            permuted = residual.copy()
            for group in groups:
                permuted[group] = rng.permutation(permuted[group])
            null[replicate] = partial_r2(X, X0, fitted + permuted, weights)
    else:
        for replicate in range(replicates):
            permuted = y.copy()
            for group in groups:
                permuted[group] = rng.permutation(permuted[group])
            null[replicate] = partial_r2(X, X0, permuted, weights)
    return observed, plus_one(int((null >= observed).sum()), replicates)


def primary_pc12(frame, bootstraps, permutations, seed):
    predictors = ["delta_PC1", "delta_PC2"]
    X, X0, _ = design(frame, predictors)
    y = frame["delta_response"].to_numpy(float)
    beta, _, _ = weighted_fit(X, y)
    partial, p_value = within_basin_permutation(
        frame, predictors, [], permutations, seed + 1000
    )
    groups = [group.index.to_numpy() for _, group in frame.groupby("basin", sort=True)]
    rng = np.random.default_rng(seed)
    draws = np.empty((bootstraps, 2))
    for replicate in range(bootstraps):
        positions = np.concatenate(
            [rng.choice(group, size=len(group), replace=True) for group in groups]
        )
        sample = frame.loc[positions].reset_index(drop=True)
        Xb, _, _ = design(sample, predictors)
        draws[replicate] = weighted_fit(Xb, sample["delta_response"].to_numpy(float))[0][-2:]
    return {
        "n_sections": len(frame),
        "n_basins": frame["basin"].nunique(),
        "beta_delta_PC1_per_sd": beta[-2],
        "beta_delta_PC1_ci_low": np.quantile(draws[:, 0], 0.025),
        "beta_delta_PC1_ci_high": np.quantile(draws[:, 0], 0.975),
        "beta_delta_PC2_per_sd": beta[-1],
        "beta_delta_PC2_ci_low": np.quantile(draws[:, 1], 0.025),
        "beta_delta_PC2_ci_high": np.quantile(draws[:, 1], 0.975),
        "partial_r2_state_increment": partial,
        "within_basin_permutation_p": p_value,
        "permutations": permutations,
        "bootstrap_replicates": bootstraps,
    }


def heldout_q2(section_year, outcome, pcs, source_year, target_year, bootstraps, seed):
    finite = section_year.dropna(subset=[outcome] + pcs)
    train = finite[finite["year"].eq(source_year)].copy()
    test = finite[finite["year"].eq(target_year)].copy()
    common_basins = sorted(set(train["basin"]) & set(test["basin"]))
    train = train[train["basin"].isin(common_basins)].reset_index(drop=True)
    test = test[test["basin"].isin(common_basins)].reset_index(drop=True)

    def predictions(source, target, include_state):
        basin_train, levels = basin_matrix(source["basin"], drop_first=False)
        basin_target, _ = basin_matrix(target["basin"], levels=levels, drop_first=False)
        if include_state:
            means = source[pcs].mean()
            sds = source[pcs].std(ddof=1)
            X = np.column_stack([basin_train, ((source[pcs] - means) / sds).to_numpy(float)])
            Xt = np.column_stack([basin_target, ((target[pcs] - means) / sds).to_numpy(float)])
        else:
            X, Xt = basin_train, basin_target
        beta = np.linalg.lstsq(X, source[outcome].to_numpy(float), rcond=None)[0]
        return Xt @ beta

    y = test[outcome].to_numpy(float)
    base = predictions(train, test, False)
    full = predictions(train, test, True)
    denominator = np.sum((y - base) ** 2)
    observed = float(1 - np.sum((y - full) ** 2) / denominator)

    train_groups = [group.index.to_numpy() for _, group in train.groupby("basin", sort=True)]
    test_groups = [group.index.to_numpy() for _, group in test.groupby("basin", sort=True)]
    rng = np.random.default_rng(seed)
    draws = np.empty(bootstraps)
    for replicate in range(bootstraps):
        source_positions = np.concatenate(
            [rng.choice(group, size=len(group), replace=True) for group in train_groups]
        )
        target_positions = np.concatenate(
            [rng.choice(group, size=len(group), replace=True) for group in test_groups]
        )
        source = train.loc[source_positions].reset_index(drop=True)
        target = test.loc[target_positions].reset_index(drop=True)
        target_y = target[outcome].to_numpy(float)
        p0 = predictions(source, target, False)
        p1 = predictions(source, target, True)
        den = np.sum((target_y - p0) ** 2)
        draws[replicate] = 1 - np.sum((target_y - p1) ** 2) / den if den > 0 else np.nan
    draws = draws[np.isfinite(draws)]
    return {
        "outcome": outcome,
        "predictor_set": "PC1-PC2" if len(pcs) == 2 else "all nine PCs",
        "source_event_year": source_year,
        "target_event_year": target_year,
        "source_state_year": LAG_YEAR[source_year],
        "target_state_year": LAG_YEAR[target_year],
        "n_source_sections": len(train),
        "n_target_sections": len(test),
        "q2_increment_over_basin_only": observed,
        "ci_low": np.quantile(draws, 0.025),
        "ci_high": np.quantile(draws, 0.975),
        "bootstrap_replicates": len(draws),
    }


def cluster_robust(section_year, outcome):
    frame = section_year.dropna(subset=[outcome, "PC1", "PC2"]).copy()
    frame["z_PC1"] = standardize(frame["PC1"])
    frame["z_PC2"] = standardize(frame["PC2"])
    model = smf.ols(
        f"{outcome} ~ z_PC1 + z_PC2 + C(basin) + C(year)", data=frame
    ).fit(cov_type="cluster", cov_kwds={"groups": frame["section_id"]})
    confidence = model.conf_int()
    rows = []
    for term in ["z_PC1", "z_PC2"]:
        rows.append({
            "outcome": outcome,
            "term": term,
            "estimate": model.params[term],
            "ci_low": confidence.loc[term, 0],
            "ci_high": confidence.loc[term, 1],
            "p_value": model.pvalues[term],
            "n_section_years": len(frame),
            "n_sections": frame["section_id"].nunique(),
            "uncertainty": "section-cluster robust covariance",
        })
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--annual-coordinates", type=Path, required=True)
    parser.add_argument("--event-metrics", type=Path, required=True)
    parser.add_argument("--crosswalk", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--permutations", type=int, default=10_000)
    parser.add_argument("--bootstraps", type=int, default=5_000)
    parser.add_argument("--seed", type=int, default=20260915)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    coordinates = pd.read_csv(args.annual_coordinates)
    event_metrics = pd.read_csv(args.event_metrics)
    crosswalk = pd.read_csv(args.crosswalk)

    section_year = build_section_year(
        event_metrics, crosswalk, coordinates, args.output_dir
    )
    response_axis_metadata = {
        "response_axis": "fixed 2024-defined nine-variable China node direction",
        "projection_fields": ["proj_pre", "proj_peak", "proj_late"],
        "derived_outcomes": {
            "peak_minus_pre": "proj_peak - proj_pre",
            "late_minus_peak": "proj_late - proj_peak",
        },
        "section_year_aggregation": "median across eligible episodes",
        "cross_fitted_outcome": False,
        "interpretive_role": "exploratory lagged-state prediction test",
        "eligibility_rule": "n_rel >= 12; n_pre >= 2; n_peak >= 2; n_late >= 3",
    }
    (args.output_dir / "response_axis_metadata.json").write_text(
        json.dumps(response_axis_metadata, indent=2), encoding="utf-8"
    )

    differences = []
    primary_rows = []
    all9_rows = []
    forcing_rows = []
    basin_equal_rows = []
    for index, outcome in enumerate(OUTCOMES):
        frame = difference_frame(section_year, outcome)
        differences.append(frame)

        primary = primary_pc12(
            frame, args.bootstraps, args.permutations, args.seed + index * 100
        )
        primary["outcome"] = outcome
        primary_rows.append(primary)

        all9_partial, all9_p = within_basin_permutation(
            frame,
            [f"delta_{pc}" for pc in PC_COLUMNS],
            [],
            args.permutations,
            args.seed + 2_000 + index,
        )
        all9_rows.append({
            "outcome": outcome,
            "n_sections": len(frame),
            "n_basins": frame["basin"].nunique(),
            "partial_r2_all_nine_PCs": all9_partial,
            "within_basin_permutation_p": all9_p,
            "permutations": args.permutations,
            "analysis_role": "post hoc full-state sensitivity",
        })

        forcing_partial, forcing_p = within_basin_permutation(
            frame,
            ["delta_PC1", "delta_PC2"],
            [f"delta_{column}" for column in FORCING_COLUMNS],
            args.permutations,
            args.seed + 3_000 + index,
            freedman_lane=True,
        )
        forcing_rows.append({
            "outcome": outcome,
            "n_sections": len(frame),
            "partial_r2_state_beyond_basin_forcing_support": forcing_partial,
            "Freedman_Lane_within_basin_p": forcing_p,
            "covariates": "; ".join(FORCING_COLUMNS),
            "permutations": args.permutations,
            "analysis_role": "post hoc forcing/support sensitivity",
        })

        equal_partial, equal_p = within_basin_permutation(
            frame,
            ["delta_PC1", "delta_PC2"],
            [],
            args.permutations,
            args.seed + 4_000 + index,
            basin_equal=True,
        )
        basin_equal_rows.append({
            "outcome": outcome,
            "n_sections": len(frame),
            "n_basins": frame["basin"].nunique(),
            "basin_equal_partial_r2_PC1_PC2": equal_partial,
            "within_basin_permutation_p": equal_p,
            "permutations": args.permutations,
            "analysis_role": "post hoc basin-equal sensitivity",
        })

    primary = pd.DataFrame(primary_rows)
    primary["holm_p_two_outcomes"] = holm(
        primary["within_basin_permutation_p"].to_numpy(float)
    )
    primary.to_csv(args.output_dir / "primary_pc12_results.csv", index=False)
    pd.DataFrame(all9_rows).to_csv(
        args.output_dir / "all_nine_pc_sensitivity.csv", index=False
    )
    pd.DataFrame(forcing_rows).to_csv(
        args.output_dir / "forcing_adjusted_sensitivity.csv", index=False
    )
    pd.DataFrame(basin_equal_rows).to_csv(
        args.output_dir / "basin_equal_sensitivity.csv", index=False
    )
    pd.concat(differences, ignore_index=True).to_csv(
        args.output_dir / "within_section_differences.csv.gz",
        index=False,
        compression="gzip",
    )

    heldout = []
    for outcome_index, outcome in enumerate(OUTCOMES):
        for predictor_index, predictors in enumerate([["PC1", "PC2"], PC_COLUMNS]):
            for direction_index, (source, target) in enumerate([(2023, 2024), (2024, 2023)]):
                heldout.append(
                    heldout_q2(
                        section_year,
                        outcome,
                        predictors,
                        source,
                        target,
                        args.bootstraps,
                        args.seed + 5_000 + 100 * outcome_index + 10 * predictor_index + direction_index,
                    )
                )
    heldout_table = pd.DataFrame(heldout)
    heldout_table.to_csv(args.output_dir / "heldout_q2.csv", index=False)

    cluster_rows = []
    for outcome in OUTCOMES:
        cluster_rows.extend(cluster_robust(section_year, outcome))
    cluster = pd.DataFrame(cluster_rows)
    cluster.to_csv(args.output_dir / "section_cluster_robust_results.csv", index=False)

    all9_table = pd.DataFrame(all9_rows)
    primary_null = bool((primary["holm_p_two_outcomes"] >= 0.05).all())
    all9_null = bool((all9_table["within_basin_permutation_p"] >= 0.05).all())
    heldout_null = bool((heldout_table["ci_low"] <= 0).all())
    cluster_null = bool(
        ((cluster["ci_low"] <= 0) & (cluster["ci_high"] >= 0)).all()
    )
    decision = {
        "decision": (
            "B_SCALE_SPECIFIC_OBSERVABILITY"
            if primary_null and all9_null and heldout_null and cluster_null
            else "A_STATE_RESPONSE_ASSOCIATION_REQUIRES_CONFIRMATION"
        ),
        "primary_PC1_PC2_null": primary_null,
        "all_nine_PC_sensitivity_null": all9_null,
        "heldout_intervals_include_zero": heldout_null,
        "section_cluster_intervals_include_zero": cluster_null,
        "interpretation": (
            "The lagged dominant annual-state plane did not improve the specified "
            "linear prediction of section-level peak or recovery response. A post hoc "
            "all-nine-PC sensitivity was also null. Nonlinear, event-specific, "
            "regime-specific and longer-lag dependence remain open hypotheses."
        ),
        "state_event_lag": {
            "event_2023": "annual_state_2022",
            "event_2024": "annual_state_2023",
        },
        "response_axis": response_axis_metadata,
        "permutations": args.permutations,
        "bootstraps": args.bootstraps,
        "seed": args.seed,
    }
    (args.output_dir / "decision.json").write_text(
        json.dumps(decision, indent=2), encoding="utf-8"
    )
    print(json.dumps(decision, indent=2))


if __name__ == "__main__":
    main()
