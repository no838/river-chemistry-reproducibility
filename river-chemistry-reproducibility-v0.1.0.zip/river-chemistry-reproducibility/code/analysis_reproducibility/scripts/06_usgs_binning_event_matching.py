#!/usr/bin/env python3
"""Bin cached public USGS observations, define discharge events, and match controls.

The algorithm is outcome-blind: candidate events and controls are defined from discharge,
calendar and data support before water-quality trajectory values are evaluated.
"""
from __future__ import annotations
import argparse,json
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from zoneinfo import ZoneInfo
import numpy as np,pandas as pd
VARS=['water_temp','pH','DO','EC','turbidity'];LOG={'EC','turbidity'};RELS=np.arange(-48,49,4);RESP=np.arange(-24,49,4)
RANGES={'water_temp':(-5,50),'pH':(0,14),'DO':(0,30),'EC':(0,100000),'turbidity':(0,10000)}
PARAM={'water_temp':'00010','pH':'00400','DO':'00300','EC':'00095','turbidity':'63680','discharge':'00060'}
def tz(site,meta):
 r=meta.loc[site]
 if 'time_zone_abbreviation' in meta.columns:
  ab=str(r.get('time_zone_abbreviation',''))
  dst=str(r.get('uses_daylight_savings','Y')).upper()=='Y'
  mapped={'EST':'America/New_York' if dst else 'Etc/GMT+5',
          'CST':'America/Chicago' if dst else 'Etc/GMT+6',
          'MST':'America/Denver' if dst else 'Etc/GMT+7',
          'PST':'America/Los_Angeles' if dst else 'Etc/GMT+8'}
  if ab in mapped:return mapped[ab]
 state=str(r.get('state',''))
 by_state={'Maryland':'America/New_York','District of Columbia':'America/New_York',
           'Delaware':'America/New_York','Florida':'America/New_York',
           'Connecticut':'America/New_York','Kansas':'America/Chicago',
           'Oregon':'America/Los_Angeles'}
 return by_state.get(state,'UTC')
def path_for(cache,site,year,var):
 q=list((cache/f'year={year}/site={site}').glob(f'param={PARAM[var]}*/observations.csv.gz'))
 if len(q)!=1:raise FileNotFoundError((site,year,var,q))
 return q[0]
def read(path,var,year,series_mode="median-collapse"):
 d=pd.read_csv(path,usecols=lambda c:c in {'time','value','converted_value','statistic_id','time_series_id','approval_status','qualifier'})
 d['time']=pd.to_datetime(d.time,utc=True,errors='coerce');d=d[(d.time>=pd.Timestamp(f'{year}-01-01',tz='UTC'))&(d.time<pd.Timestamp(f'{year+1}-01-01',tz='UTC'))]
 st=pd.to_numeric(d.get('statistic_id'),errors='coerce') if 'statistic_id' in d else pd.Series(np.nan,index=d.index)
 if st.notna().any():d=d[st.eq(11)]
 val=pd.to_numeric(d.get('converted_value'),errors='coerce') if 'converted_value' in d else pd.Series(np.nan,index=d.index);val=val.fillna(pd.to_numeric(d.value,errors='coerce'));d=d.assign(v=val).dropna(subset=['time','v']);lo,hi=RANGES.get(var,(-np.inf,np.inf));d=d[d.v.between(lo,hi)]
 selected='ALL_MEDIAN_COLLAPSE';series_count=int(d.time_series_id.nunique(dropna=True)) if 'time_series_id' in d else 0
 if series_mode=='metadata-primary' and 'time_series_id' in d and d.time_series_id.notna().any():
  inv=[]
  for sid,g in d[d.time_series_id.notna()].groupby('time_series_id'):
   approved=float(g.approval_status.astype(str).str.lower().isin({'approved','a','published'}).mean()) if 'approval_status' in g else 0.0
   inv.append((approved,int(g.time.nunique()),float((g.time.max()-g.time.min()).total_seconds()),str(sid)))
  inv.sort(reverse=True);selected=inv[0][3];d=d[d.time_series_id.astype(str).eq(selected)]
 raw_n=len(d);unique_n=d.time.nunique();out=d.groupby('time',as_index=False).v.median().rename(columns={'v':var});out.attrs.update({'raw_rows':raw_n,'unique_times':unique_n,'overlap_fraction':1-unique_n/raw_n if raw_n else 0.0,'series_mode':series_mode,'selected_time_series_id':selected,'available_time_series_count':series_count});return out

def res4(d,var):
 if d.empty:return pd.DataFrame(columns=['time_utc',var,var+'_n'])
 s=d.set_index('time')[var].sort_index();med=s.resample('4h',origin='start_day').median();n=s.resample('4h',origin='start_day').count();med[n<2]=np.nan;return pd.DataFrame({'time_utc':med.index,var:med.values,var+'_n':n.values})
def circ(a,b):
 d=abs(pd.Timestamp(a).dayofyear-pd.Timestamp(b).dayofyear);return min(d,(366 if pd.Timestamp(a).is_leap_year else 365)-d)
def peaks(w,q=.9):
 s=w.discharge.dropna();z=np.log1p(s.clip(lower=0));thr=z.quantile(q);iqr=z.quantile(.75)-z.quantile(.25);rm=z.rolling(13,center=True,min_periods=7).max();pm=z.shift(1).rolling(6,min_periods=3).min();c=z[(z>=thr)&(z>=rm-1e-12)&((z-pm)>=max(.25*iqr,1e-9))].sort_values(ascending=False);out=[]
 for t in c.index:
  if all(abs(t-u)>=pd.Timedelta(days=7) for u in out):out.append(t)
 return sorted(out)
def controls(w,pk,zone):
 # Vectorized implementation of the original deterministic control search.
 # It preserves the exact lexicographic ranking: maximum shared support,
 # minimum circular day-of-year distance, minimum absolute day distance,
 # then earliest timestamp.
 q50=w.discharge.quantile(.5)
 complete=w[VARS].notna().all(1).to_numpy(bool)
 idx=w.index
 pos={t:i for i,t in enumerate(idx)}
 times=idx[w.discharge.notna()&(w.discharge<=q50)]
 used=set();out=[];z=ZoneInfo(zone)
 offsets=(RELS//4).astype(int)
 peak_arr=np.asarray(pk,dtype=object)
 for p in pk:
  pl=p.tz_convert(z)
  # Apply all filters that do not depend on support before constructing windows.
  candidates=[]
  for t in times:
   if t in used:continue
   if any(abs(t-e)<pd.Timedelta(days=7) for e in pk):continue
   tl=t.tz_convert(z)
   if tl.hour==pl.hour and tl.month==pl.month:candidates.append(t)
  if not candidates:continue
  ep=pos.get(p,-10**9)
  eidx=ep+offsets
  ecomp=np.zeros(len(offsets),dtype=bool)
  ok=(eidx>=0)&(eidx<len(idx))
  if np.any(ok):ecomp[ok]=complete[eidx[ok]]
  cpos=np.fromiter((pos.get(t,-10**9) for t in candidates),dtype=np.int64,count=len(candidates))
  cidx=cpos[:,None]+offsets[None,:]
  cok=(cidx>=0)&(cidx<len(idx))
  ccomp=np.zeros(cidx.shape,dtype=bool)
  rr,cc=np.where(cok)
  ccomp[rr,cc]=complete[cidx[rr,cc]]
  shared=np.sum(ccomp&ecomp[None,:],axis=1)
  keep=np.flatnonzero(shared>=18)
  if not len(keep):continue
  ranked=[]
  for k in keep:
   t=candidates[int(k)]
   ranked.append((-int(shared[k]),circ(p,t),abs((p-t).days),t))
  ranked.sort();best=ranked[0];c=best[-1]
  used.add(c);out.append((p,c,-best[0]))
 return out
def process(task,cache,meta,node,series_mode):
 site,year=task;raw={v:read(path_for(cache,site,year,v),v,year,series_mode) for v in VARS+['discharge']};frames=[res4(raw[v],v) for v in VARS+['discharge']];wide=frames[0]
 for f in frames[1:]:wide=wide.merge(f,on='time_utc',how='outer')
 wide=wide.sort_values('time_utc').set_index('time_utc')
 for v in VARS:wide['x_'+v]=np.log1p(wide[v].clip(lower=0)) if v in LOG else wide[v]
 gap=wide.index.to_series().diff().dt.total_seconds().div(3600);sc=[]
 for v in VARS:
  dv=wide['x_'+v].diff().where(gap.eq(4));sc.append(dv.quantile(.75)-dv.quantile(.25))
 sc=np.asarray(sc,float);pk=peaks(wide);pairs=controls(wide,pk,tz(site,meta));ev=[];lev=[];nmetric=0
 for ei,(p,c,shared) in enumerate(pairs):
  E=wide.reindex([p+pd.Timedelta(hours=int(h)) for h in RELS])[['x_'+v for v in VARS]].to_numpy(float);C=wide.reindex([c+pd.Timedelta(hours=int(h)) for h in RELS])[['x_'+v for v in VARS]].to_numpy(float);eid=f'{site}_{year}_{ei:03d}'
  for ih,h in enumerate(RELS):
   row={'site':site,'year':year,'anchor':'discharge','event_id':eid,'peak_time':p,'control_time':c,'rel_h':int(h),'shared_complete_levels':shared}
   for j,v in enumerate(VARS):row['e_'+v]=E[ih,j];row['c_'+v]=C[ih,j];row['scale_'+v]=sc[j]
   lev.append(row)
  ri={int(h):i for i,h in enumerate(RELS)};rr={'site':site,'year':year,'anchor':'discharge','event_id':eid,'peak_time':p,'control_time':c};n=0
  for h in RESP:
   i=ri[h];ip=ri[h-4]
   if np.all(np.isfinite(E[[i,ip]])) and np.all(np.isfinite(C[[i,ip]])) and np.all(np.isfinite(sc)) and np.all(sc>0):
    z=((E[i]-E[ip])-(C[i]-C[ip]))/sc;rr[f'proj_{h}']=z@node
    for j,v in enumerate(VARS):rr[f'{v}_{h}']=z[j]
    n+=1
  rr['n_response_bins']=n
  if n>=14:ev.append(rr);nmetric+=1
 return ev,lev,{'site':site,'year':year,'n_peaks':len(pk),'n_matched_pairs':len(pairs),'n_metric_events':nmetric,'complete5_bins':int(wide[VARS].notna().all(1).sum()),'series_mode':series_mode,'series_selection':json.dumps({v:{'selected':raw[v].attrs.get('selected_time_series_id'),'available_series':raw[v].attrs.get('available_time_series_count'),'overlap_fraction':raw[v].attrs.get('overlap_fraction')} for v in raw},sort_keys=True)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--cache',type=Path,required=True);ap.add_argument('--sites',type=Path,required=True);ap.add_argument('--metadata',type=Path,required=True);ap.add_argument('--node-direction',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--years',nargs='+',type=int,default=list(range(2019,2025)));ap.add_argument('--workers',type=int,default=6);ap.add_argument('--series-mode',choices=['median-collapse','metadata-primary'],default='median-collapse');a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True);sites=pd.read_csv(a.sites).site.astype(str).tolist();meta=pd.read_csv(a.metadata).set_index('id');node=pd.read_csv(a.node_direction).set_index('variable').reindex(VARS).weight.to_numpy(float);node/=np.linalg.norm(node);tasks=[(s,y) for s in sites for y in a.years];ev=[];lev=[];qa=[]
 with ThreadPoolExecutor(max_workers=max(1,a.workers)) as ex:
  fut={ex.submit(process,t,a.cache,meta,node,a.series_mode):t for t in tasks}
  for f in as_completed(fut):
   try:e,l,q=f.result();ev.extend(e);lev.extend(l);qa.append(q)
   except Exception as exc:site,year=fut[f];qa.append({'site':site,'year':year,'error':repr(exc),'n_peaks':0,'n_matched_pairs':0,'n_metric_events':0,'complete5_bins':0})
 evdf=pd.DataFrame(ev);levdf=pd.DataFrame(lev);qadf=pd.DataFrame(qa)
 if len(evdf):evdf=evdf.sort_values(['site','year','peak_time'])
 if len(levdf):levdf=levdf.sort_values(['site','year','peak_time','rel_h'])
 if len(qadf):qadf=qadf.sort_values(['site','year'])
 evdf.to_csv(a.output_dir/'event_response_rows.csv.gz',index=False,compression='gzip');levdf.to_csv(a.output_dir/'event_level_pairs.csv.gz',index=False,compression='gzip');qadf.to_csv(a.output_dir/'event_support_QA.csv',index=False);print(json.dumps({'site_year_tasks':len(tasks),'events':len(ev),'level_rows':len(lev),'workers':a.workers},indent=2))
if __name__=='__main__':main()
