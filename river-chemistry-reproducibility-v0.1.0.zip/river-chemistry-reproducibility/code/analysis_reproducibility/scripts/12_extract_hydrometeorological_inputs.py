#!/usr/bin/env python3
"""Extract daily major-basin means from local CHIRPS v2.0 and MERRA-2 files.

Large source products are not redistributed. The user supplies local paths to
CHIRPS annual NetCDF files, MERRA-2 daily NetCDF files and a polygon layer with
the major-basin labels used by the analysis.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import xarray as xr
from rasterio.features import rasterize
from rasterio.transform import from_origin


def grid_context(longitude, latitude, basins):
    lon = np.asarray(longitude, float)
    lat = np.asarray(latitude, float)
    xmin, ymin, xmax, ymax = basins.total_bounds
    lon_index = np.flatnonzero((lon >= xmin - 1) & (lon <= xmax + 1))
    lat_index = np.flatnonzero((lat >= ymin - 1) & (lat <= ymax + 1))
    if not len(lon_index) or not len(lat_index):
        raise ValueError("Basin polygons do not intersect the source grid")
    cropped_lon = lon[lon_index]
    cropped_lat = lat[lat_index]
    dx = float(np.median(np.diff(cropped_lon)))
    dy = float(np.median(np.diff(cropped_lat)))
    north_up_lat = cropped_lat[::-1] if dy > 0 else cropped_lat
    transform = from_origin(
        float(cropped_lon.min() - abs(dx) / 2),
        float(north_up_lat.max() + abs(dy) / 2),
        abs(dx), abs(dy),
    )
    shapes = [(geometry, index + 1) for index, geometry in enumerate(basins.geometry)]
    labels = rasterize(shapes, out_shape=(len(cropped_lat), len(cropped_lon)), transform=transform, fill=0, dtype="int32")
    if dy > 0:
        labels = np.flipud(labels)
    return lon_index, lat_index, labels


def labelled_means(array, labels, n_basins):
    values = np.asarray(array, float)
    output = np.full((values.shape[0], n_basins), np.nan)
    flat_labels = labels.ravel()
    for time_index in range(values.shape[0]):
        flat = values[time_index].ravel()
        valid = np.isfinite(flat) & (flat_labels > 0)
        if valid.any():
            sums = np.bincount(flat_labels[valid], weights=flat[valid], minlength=n_basins + 1)
            counts = np.bincount(flat_labels[valid], minlength=n_basins + 1)
            output[time_index] = np.divide(
                sums[1:], counts[1:], out=np.full(n_basins, np.nan), where=counts[1:] > 0
            )
    return output


def chirps_daily(chirps_root, basins, basin_field, start, end):
    rows = []
    for year in range(pd.Timestamp(start).year, pd.Timestamp(end).year + 1):
        files = sorted(chirps_root.glob(f"chirps-v2.0.{year}.days_p05.nc"))
        if len(files) != 1:
            raise FileNotFoundError(f"Expected one CHIRPS v2.0 file for {year}; found {files}")
        with xr.open_dataset(files[0]) as dataset:
            longitude_name = "longitude" if "longitude" in dataset.coords else "lon"
            latitude_name = "latitude" if "latitude" in dataset.coords else "lat"
            variable = dataset["precip"].sel(time=slice(start, end))
            lon_index, lat_index, labels = grid_context(
                dataset[longitude_name].values, dataset[latitude_name].values, basins
            )
            array = variable.isel({latitude_name: lat_index, longitude_name: lon_index}).values
            means = labelled_means(array, labels, len(basins))
            for time_index, timestamp in enumerate(pd.to_datetime(variable.time.values)):
                for basin_index, basin in enumerate(basins[basin_field]):
                    rows.append({
                        "major_basin": basin,
                        "date_local": timestamp.normalize(),
                        "precip_polygon_mm": means[time_index, basin_index],
                    })
    return pd.DataFrame(rows)


def merra_daily(merra_root, basins, basin_field, start, end):
    rows = []
    context = None
    for date in pd.date_range(start, end, freq="D"):
        files = sorted(merra_root.glob(f"MERRA2_*.tavg1_2d_lnd_Nx.{date:%Y%m%d}.nc4"))
        if not files:
            raise FileNotFoundError(f"Missing MERRA-2 file for {date:%Y-%m-%d}")
        with xr.open_dataset(files[-1]) as dataset:
            if context is None:
                context = grid_context(dataset.lon.values, dataset.lat.values, basins)
            lon_index, lat_index, labels = context
            runoff = dataset["RUNOFF"].isel(lat=lat_index, lon=lon_index).values * 3600.0
            daily = np.nansum(runoff, axis=0, keepdims=True)
            means = labelled_means(daily, labels, len(basins))[0]
            for basin_index, basin in enumerate(basins[basin_field]):
                rows.append({
                    "major_basin": basin,
                    "date_local": date,
                    "runoff_merra_mm": means[basin_index],
                })
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--chirps-root", type=Path, required=True)
    parser.add_argument("--merra2-root", type=Path, required=True)
    parser.add_argument("--major-basin-polygons", type=Path, required=True)
    parser.add_argument("--basin-field", default="major_basin")
    parser.add_argument("--start", default="2022-01-01")
    parser.add_argument("--end", default="2024-12-31")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    basins = gpd.read_file(args.major_basin_polygons).to_crs("EPSG:4326")
    if args.basin_field not in basins:
        raise ValueError(f"Missing basin field {args.basin_field}")
    precipitation = chirps_daily(args.chirps_root, basins, args.basin_field, args.start, args.end)
    runoff = merra_daily(args.merra2_root, basins, args.basin_field, args.start, args.end)
    output = precipitation.merge(runoff, on=["major_basin", "date_local"], how="outer")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(args.output, index=False, compression="gzip" if args.output.suffix == ".gz" else None)


if __name__ == "__main__":
    main()
