#!/usr/bin/env python3
"""Recalculate the nine-variable annual hydrochemical state and sensitivities."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.covariance import MinCovDet
from sklearn.decomposition import PCA

VARIABLES = ["temp", "pH", "DO", "EC", "turbidity", "CODMn", "NH3_N", "TP", "TN"]
LOG_VARIABLES = {"EC", "turbidity", "CODMn", "NH3_N", "TP", "TN"}
YEAR_PAIRS = [(2022, 2023), (2023, 2024), (2022, 2024)]


def transform(data: pd.DataFrame, variables: list[str] = VARIABLES, fitted=None):
    x = np.column_stack([
        np.log1p(data[v].to_numpy(float)) if v in LOG_VARIABLES else data[v].to_numpy(float)
        for v in variables
    ])
    if fitted is None:
        median = np.median(x, axis=0)
        iqr = np.quantile(x, 0.75, axis=0) - np.quantile(x, 0.25, axis=0)
    else:
        median, iqr = fitted
    if np.any(~np.isfinite(iqr)) or np.any(iqr <= 0):
        raise ValueError("Non-positive or non-finite IQR in annual-state transformation")
    return (x - median) / iqr, median, iqr


def orient_pc1(components: np.ndarray, scores: np.ndarray, variables: list[str] = VARIABLES):
    """Orient PC1 so the NH3-N loading is negative; use DO as a deterministic tie-break."""
    c = components.copy()
    s = scores.copy()
    nh3 = variables.index("NH3_N")
    do = variables.index("DO")
    sign = 1
    if c[0, nh3] > 0 or (abs(c[0, nh3]) <= 1e-12 and c[0, do] < 0):
        sign = -1
        c[0] *= -1
        s[:, 0] *= -1
    return c, s, sign


def exact_signflip(values: np.ndarray, alternative: str = "greater") -> float:
    x = np.asarray(values, float)
    x = x[np.isfinite(x)]
    observed = float(x.mean())
    values_null = []
    for bits in range(2 ** len(x)):
        signs = np.array([1 if (bits >> j) & 1 else -1 for j in range(len(x))])
        values_null.append(float(np.mean(x * signs)))
    null = np.asarray(values_null)
    if alternative == "greater":
        return float(np.mean(null >= observed - 1e-15))
    if alternative == "less":
        return float(np.mean(null <= observed + 1e-15))
    return float(np.mean(np.abs(null) >= abs(observed) - 1e-15))


def bootstrap_mean(values, replicates, rng):
    x = np.asarray(values, float)
    return np.quantile(rng.choice(x, (replicates, len(x)), replace=True).mean(axis=1), [0.025, 0.975])


def bootstrap_median(values, replicates, rng):
    x = np.asarray(values, float)
    return np.quantile(np.median(rng.choice(x, (replicates, len(x)), replace=True), axis=1), [0.025, 0.975])


def permuted_medians(a, b, strata, metric, replicates, rng):
    groups = [np.flatnonzero(strata == g) for g in pd.unique(strata)]
    out = np.empty(replicates)
    base = np.arange(len(a))
    for k in range(replicates):
        perm = base.copy()
        for group in groups:
            perm[group] = rng.permutation(group)
        out[k] = np.median(metric(a, b[perm]))
    return out


def fit_primary(data: pd.DataFrame):
    z, median, iqr = transform(data)
    pca = PCA(n_components=len(VARIABLES), svd_solver="full").fit(z)
    components, scores, sign = orient_pc1(pca.components_, pca.transform(z))
    thresholds = np.quantile(scores[:, 0], [0.2, 0.4, 0.6, 0.8])
    classes = np.digitize(scores[:, 0], thresholds) + 1
    coordinates = data.copy()
    coordinates["state_index"] = classes
    coordinates["state_class"] = [f"State Q{x}" for x in classes]
    for j in range(len(VARIABLES)):
        coordinates[f"PC{j+1}"] = scores[:, j]
    return coordinates, z, pca, components, scores, median, iqr, thresholds, sign


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--monthly", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260722)
    parser.add_argument("--permutations", type=int, default=2000)
    parser.add_argument("--bootstraps", type=int, default=5000)
    parser.add_argument("--calendar-seed", type=int, default=20260721)
    parser.add_argument("--cluster-seed", type=int, default=20260805)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    data = pd.read_csv(args.input)
    coordinates, z, pca, components, scores, median, iqr, thresholds, pc1_sign = fit_primary(data)
    coordinates.to_csv(args.output_dir / "state_coordinates.csv", index=False)
    pd.DataFrame({
        "variable": VARIABLES,
        "transformation": ["log1p" if v in LOG_VARIABLES else "identity" for v in VARIABLES],
        "median": median,
        "IQR": iqr,
    }).to_csv(args.output_dir / "scaling.csv", index=False)

    loading_rows = []
    for component in range(len(VARIABLES)):
        for j, variable in enumerate(VARIABLES):
            loading_rows.append({
                "Component": component + 1,
                "Variable": variable,
                "Loading": components[component, j],
                "Explained variance ratio": pca.explained_variance_ratio_[component],
                "Cumulative explained variance ratio": pca.explained_variance_ratio_[: component + 1].sum(),
            })
    pd.DataFrame(loading_rows).to_csv(args.output_dir / "state_loadings.csv", index=False)
    pd.DataFrame({"boundary": [1, 2, 3, 4], "pc1_threshold": thresholds}).to_csv(
        args.output_dir / "state_class_boundaries.csv", index=False
    )

    row_index = {(r.section_id, int(r.year)): i for i, r in coordinates[["section_id", "year"]].iterrows()}
    mcd = MinCovDet(random_state=args.seed).fit(z)
    inverse_covariance = np.linalg.pinv(mcd.covariance_)
    retention_rows, distance_rows, transition_rows = [], [], []

    for source_year, target_year in YEAR_PAIRS:
        source = coordinates[coordinates.year.eq(source_year)].set_index("section_id")
        target = coordinates[coordinates.year.eq(target_year)].set_index("section_id")
        keys = source.index.intersection(target.index)
        source = source.loc[keys]
        target = target.loc[keys]
        source_class = source.state_index.to_numpy(int)
        target_class = target.state_index.to_numpy(int)
        p_source = np.array([(source_class == i).mean() for i in range(1, 6)])
        p_target = np.array([(target_class == i).mean() for i in range(1, 6)])
        observed_matrix = np.array([
            [np.mean(target_class[source_class == i] == j) for j in range(1, 6)]
            for i in range(1, 6)
        ])
        null_matrix = np.tile(p_target, (5, 1))
        for matrix_name, matrix in [
            ("Observed", observed_matrix),
            ("Marginal null", null_matrix),
            ("Observed - null", observed_matrix - null_matrix),
        ]:
            for i in range(5):
                for j in range(5):
                    transition_rows.append({
                        "year_pair": f"{source_year}-{target_year}",
                        "matrix": matrix_name,
                        "from_class": f"State Q{i+1}",
                        "to_class": f"State Q{j+1}",
                        "value": matrix[i, j],
                    })

        retention_specs = [
            ("Same state", (source_class == target_class).astype(float), float(np.sum(p_source * p_target))),
            (
                "Same or adjacent",
                (np.abs(source_class - target_class) <= 1).astype(float),
                float(sum(p_source[i] * p_target[max(0, i - 1): min(5, i + 2)].sum() for i in range(5))),
            ),
        ]
        for offset, (metric_name, values, null_value) in enumerate(retention_specs):
            lo, hi = bootstrap_mean(
                values, args.bootstraps,
                np.random.default_rng(args.seed + source_year + target_year + offset * 1000),
            )
            retention_rows.append({
                "year_pair": f"{source_year}-{target_year}",
                "metric": metric_name,
                "n_sections": len(keys),
                "observed": values.mean(),
                "ci_low": lo,
                "ci_high": hi,
                "null": null_value,
                "excess": values.mean() - null_value,
            })

        ia = np.array([row_index[(key, source_year)] for key in keys])
        ib = np.array([row_index[(key, target_year)] for key in keys])
        strata = target.basin.fillna("Unknown").astype(str).to_numpy()
        euclidean = lambda x, y: np.linalg.norm(x - y, axis=1)
        spaces = {
            "PC1-PC2": scores[:, :2],
            "PC1-PC5": scores[:, :5],
            "All nine PCs": scores,
            "Whitened nine PCs": scores / np.sqrt(pca.explained_variance_),
        }
        for metric_index, (name, values) in enumerate(spaces.items()):
            same = euclidean(values[ia], values[ib])
            rng = np.random.default_rng(args.seed + source_year * 100 + target_year + metric_index)
            null = permuted_medians(values[ia], values[ib], strata, euclidean, args.permutations, rng)
            lo, hi = bootstrap_median(same, args.bootstraps, rng)
            null_median = np.median(null)
            observed_median = np.median(same)
            distance_rows.append({
                "year_pair": f"{source_year}-{target_year}",
                "distance_metric": name,
                "n_sections": len(keys),
                "same_section_median": observed_median,
                "ci_low": lo,
                "ci_high": hi,
                "null_median": null_median,
                "ratio": observed_median / null_median,
                "reduction_percent": 100 * (1 - observed_median / null_median),
                "p": (1 + int(np.sum(null <= observed_median))) / (len(null) + 1),
            })

        def mahalanobis(a, b):
            difference = a - b
            return np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", difference, inverse_covariance, difference), 0))

        same = mahalanobis(z[ia], z[ib])
        rng = np.random.default_rng(args.seed + source_year * 100 + target_year + 99)
        null = permuted_medians(z[ia], z[ib], strata, mahalanobis, args.permutations, rng)
        lo, hi = bootstrap_median(same, args.bootstraps, rng)
        null_median = np.median(null)
        observed_median = np.median(same)
        distance_rows.append({
            "year_pair": f"{source_year}-{target_year}",
            "distance_metric": "Robust Mahalanobis",
            "n_sections": len(keys),
            "same_section_median": observed_median,
            "ci_low": lo,
            "ci_high": hi,
            "null_median": null_median,
            "ratio": observed_median / null_median,
            "reduction_percent": 100 * (1 - observed_median / null_median),
            "p": (1 + int(np.sum(null <= observed_median))) / (len(null) + 1),
        })

    pd.DataFrame(retention_rows).to_csv(args.output_dir / "retention.csv", index=False)
    pd.DataFrame(distance_rows).to_csv(args.output_dir / "full_space_distances.csv", index=False)
    pd.DataFrame(transition_rows).to_csv(args.output_dir / "transition_matrices.csv", index=False)

    centroid_rows = []
    classes = coordinates.state_index.to_numpy(int)
    for state_class in range(1, 6):
        mask = classes == state_class
        for j, variable in enumerate(VARIABLES):
            centroid_rows.append({
                "state_class": f"State Q{state_class}",
                "variable": variable,
                "centroid": np.median(z[mask, j]),
                "n_section_years": int(mask.sum()),
                "n_sections": coordinates.loc[mask, "section_id"].nunique(),
            })
    pd.DataFrame(centroid_rows).to_csv(args.output_dir / "state_centroids.csv", index=False)

    section_ids = coordinates.section_id.to_numpy()
    unique_sections = pd.unique(section_ids)
    section_groups = [np.flatnonzero(section_ids == key) for key in unique_sections]
    bootstrap_values = {v: np.empty(args.bootstraps) for v in VARIABLES}
    rng = np.random.default_rng(args.cluster_seed)
    for b in range(args.bootstraps):
        sampled = np.concatenate([section_groups[i] for i in rng.integers(0, len(section_groups), len(section_groups))])
        sampled_classes = classes[sampled]
        sampled_z = z[sampled]
        for j, variable in enumerate(VARIABLES):
            bootstrap_values[variable][b] = (
                np.median(sampled_z[sampled_classes == 5, j]) - np.median(sampled_z[sampled_classes == 1, j])
            )
    contrast_rows = []
    for j, variable in enumerate(VARIABLES):
        lo, hi = np.quantile(bootstrap_values[variable], [0.025, 0.975])
        contrast_rows.append({
            "variable": variable,
            "contrast_Q5_minus_Q1": np.median(z[classes == 5, j]) - np.median(z[classes == 1, j]),
            "ci_low": lo,
            "ci_high": hi,
            "bootstrap_unit": "physical section",
            "bootstrap_replicates": args.bootstraps,
        })
    pd.DataFrame(contrast_rows).to_csv(args.output_dir / "state_contrasts.csv", index=False)

    source_year_rows = []
    for first_year, second_year in YEAR_PAIRS:
        for source_year, target_year in [(first_year, second_year), (second_year, first_year)]:
            source = data[data.year.eq(source_year)].set_index("section_id")
            target = data[data.year.eq(target_year)].set_index("section_id")
            keys = source.index.intersection(target.index)
            source = source.loc[keys]
            target = target.loc[keys]
            source_z, source_median, source_iqr = transform(source)
            target_z, _, _ = transform(target, fitted=(source_median, source_iqr))
            source_pca = PCA(n_components=len(VARIABLES), svd_solver="full").fit(source_z)
            components, source_scores, orientation = orient_pc1(source_pca.components_, source_pca.transform(source_z))
            target_scores = source_pca.transform(target_z)
            target_scores[:, 0] *= orientation
            source_thresholds = np.quantile(source_scores[:, 0], [0.2, 0.4, 0.6, 0.8])
            source_classes = np.digitize(source_scores[:, 0], source_thresholds) + 1
            target_classes = np.digitize(target_scores[:, 0], source_thresholds) + 1
            p_source = np.array([(source_classes == i).mean() for i in range(1, 6)])
            p_target = np.array([(target_classes == i).mean() for i in range(1, 6)])
            specs = [
                ("Same state", (source_classes == target_classes).astype(float), float(np.sum(p_source * p_target))),
                (
                    "Same or adjacent",
                    (np.abs(source_classes - target_classes) <= 1).astype(float),
                    float(sum(p_source[i] * p_target[max(0, i - 1): min(5, i + 2)].sum() for i in range(5))),
                ),
            ]
            for offset, (metric, values, null_value) in enumerate(specs):
                lo, hi = bootstrap_mean(
                    values, args.bootstraps,
                    np.random.default_rng(args.seed + source_year + target_year + offset * 1000),
                )
                source_year_rows.append({
                    "source_year": source_year,
                    "target_year": target_year,
                    "direction": f"{source_year}->{target_year}",
                    "metric": metric,
                    "n_sections": len(keys),
                    "observed": values.mean(),
                    "ci_low": lo,
                    "ci_high": hi,
                    "source_year_frequency_null": null_value,
                    "excess": values.mean() - null_value,
                    "pc1_orientation_sign": orientation,
                })
    pd.DataFrame(source_year_rows).to_csv(args.output_dir / "source_year_ordinal.csv", index=False)

    variant_rows = []
    variants = {
        "All nine variables": VARIABLES,
        "Without conductivity": [v for v in VARIABLES if v != "EC"],
        "Without turbidity": [v for v in VARIABLES if v != "turbidity"],
        "Without conductivity and turbidity": [v for v in VARIABLES if v not in {"EC", "turbidity"}],
        "pH, oxygen and nutrients": ["pH", "DO", "CODMn", "NH3_N", "TP", "TN"],
    }
    for variant_index, (label, variables) in enumerate(variants.items()):
        transformed, _, _ = transform(data, variables)
        variant_pca = PCA(n_components=len(variables), svd_solver="full").fit(transformed)
        variant_scores = variant_pca.transform(transformed)
        variant_index_map = {(r.section_id, int(r.year)): i for i, r in data[["section_id", "year"]].iterrows()}
        for source_year, target_year in YEAR_PAIRS:
            source = data[data.year.eq(source_year)].set_index("section_id")
            target = data[data.year.eq(target_year)].set_index("section_id")
            keys = source.index.intersection(target.index)
            ia = np.array([variant_index_map[(key, source_year)] for key in keys])
            ib = np.array([variant_index_map[(key, target_year)] for key in keys])
            strata = target.loc[keys].basin.fillna("Unknown").astype(str).to_numpy()
            metric = lambda x, y: np.linalg.norm(x - y, axis=1)
            same = metric(variant_scores[ia], variant_scores[ib])
            rng = np.random.default_rng(args.seed + variant_index * 10000 + source_year + target_year)
            null = permuted_medians(
                variant_scores[ia], variant_scores[ib], strata, metric, args.permutations, rng
            )
            lo, hi = bootstrap_median(same, args.bootstraps, rng)
            null_median = np.median(null)
            observed_median = np.median(same)
            variant_rows.append({
                "Representation": label,
                "Variables": "; ".join(variables),
                "Year pair": f"{source_year}-{target_year}",
                "Sections": len(keys),
                "Same-section median": observed_median,
                "Lower 95% CI": lo,
                "Upper 95% CI": hi,
                "Basin-null median": null_median,
                "Reduction (%)": 100 * (1 - observed_median / null_median),
                "Lower-tail P": (1 + int(np.sum(null <= observed_median))) / (len(null) + 1),
                "Permutations": args.permutations,
            })
    pd.DataFrame(variant_rows).to_csv(args.output_dir / "method_sensitive_exclusion.csv", index=False)

    monthly = pd.read_csv(args.monthly)
    monthly = monthly[monthly.complete9_month.astype(bool)].copy()
    calendar_rows = []
    for min_observations, min_months in [(12, 6), (30, 3), (60, 3)]:
        eligible = monthly.copy()
        mask = np.ones(len(eligible), bool)
        for variable in VARIABLES:
            mask &= eligible[f"{variable}_n"].ge(min_observations).to_numpy()
        eligible = eligible[mask].copy()
        for source_year, target_year in YEAR_PAIRS:
            source_months = eligible[eligible.year.eq(source_year)].set_index(["section_id", "month"])
            target_months = eligible[eligible.year.eq(target_year)].set_index(["section_id", "month"])
            common = source_months.index.intersection(target_months.index)
            source_months = source_months.loc[common].reset_index()
            target_months = target_months.loc[common].reset_index()
            counts = source_months.groupby("section_id").size()
            keys = counts[counts.ge(min_months)].index
            source = source_months[source_months.section_id.isin(keys)].groupby(
                ["section_id", "basin"], as_index=False
            )[VARIABLES].mean().set_index("section_id")
            target = target_months[target_months.section_id.isin(keys)].groupby(
                "section_id", as_index=False
            )[VARIABLES].mean().set_index("section_id")
            keys = source.index.intersection(target.index)
            source = source.loc[keys]
            target = target.loc[keys]
            source_z, source_median, source_iqr = transform(source)
            target_z, _, _ = transform(target, fitted=(source_median, source_iqr))
            source_pca = PCA(n_components=len(VARIABLES), svd_solver="full").fit(source_z)
            source_scores = source_pca.transform(source_z)
            target_scores = source_pca.transform(target_z)
            eigenvalues = np.maximum(source_pca.explained_variance_, 1e-12)
            robust = MinCovDet(random_state=args.calendar_seed).fit(source_z)
            inverse = np.linalg.pinv(robust.covariance_)
            strata = source.basin.fillna("Unknown").astype(str).to_numpy()
            metrics = [
                ("all nine PCs", source_scores, target_scores, lambda a, b: np.linalg.norm(a - b, axis=1)),
                (
                    "whitened nine PCs", source_scores, target_scores,
                    lambda a, b: np.linalg.norm((a - b) / np.sqrt(eigenvalues), axis=1),
                ),
                (
                    "robust Mahalanobis", source_z, target_z,
                    lambda a, b: np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", a - b, inverse, a - b), 0)),
                ),
            ]
            for metric_index, (metric_name, source_values, target_values, metric) in enumerate(metrics):
                same = metric(source_values, target_values)
                rng = np.random.default_rng(
                    args.calendar_seed + min_observations * 100 + min_months * 10 + source_year + target_year + metric_index
                )
                null = permuted_medians(
                    source_values, target_values, strata, metric, args.permutations, rng
                )
                null_median = np.median(null)
                observed_median = np.median(same)
                calendar_rows.append({
                    "Minimum observations per month": min_observations,
                    "Minimum common months": min_months,
                    "Year pair": f"{source_year}-{target_year}",
                    "Distance metric": metric_name,
                    "Sections": len(keys),
                    "Median common months": float(np.median(counts.loc[keys])),
                    "Same-section median": observed_median,
                    "Basin-null median": null_median,
                    "Reduction (%)": 100 * (1 - observed_median / null_median),
                    "Lower-tail P": (1 + int(np.sum(null <= observed_median))) / (len(null) + 1),
                })
    pd.DataFrame(calendar_rows).to_csv(args.output_dir / "calendar_sensitivity.csv", index=False)

    fine_rows = []
    for source_year, target_year in YEAR_PAIRS:
        source = coordinates[coordinates.year.eq(source_year)].set_index("section_id")
        target = coordinates[coordinates.year.eq(target_year)].set_index("section_id")
        keys = source.index.intersection(target.index)
        source = source.loc[keys]
        target = target.loc[keys]
        ia = np.array([row_index[(key, source_year)] for key in keys])
        ib = np.array([row_index[(key, target_year)] for key in keys])
        metric = lambda a, b: np.linalg.norm(a - b, axis=1)
        observed = np.median(metric(scores[ia], scores[ib]))
        definitions = [
            ("Province", target.province.fillna("Unknown").astype(str).to_numpy()),
            (
                "Basin x province",
                (target.basin.fillna("Unknown").astype(str) + "|" + target.province.fillna("Unknown").astype(str)).to_numpy(),
            ),
        ]
        for definition_index, (label, strata) in enumerate(definitions):
            rng = np.random.default_rng(args.seed + source_year * 100 + target_year + definition_index + 700)
            null = permuted_medians(scores[ia], scores[ib], strata, metric, args.permutations, rng)
            null_median = np.median(null)
            counts = pd.Series(strata).value_counts()
            fine_rows.append({
                "Year pair": f"{source_year}-{target_year}",
                "Stratification": label,
                "Sections": len(keys),
                "Strata": len(counts),
                "Singleton strata": int((counts == 1).sum()),
                "Same-section median": observed,
                "Null median": null_median,
                "Reduction (%)": 100 * (1 - observed / null_median),
                "Lower-tail P": (1 + int(np.sum(null <= observed))) / (len(null) + 1),
                "Permutations": args.permutations,
            })
    pd.DataFrame(fine_rows).to_csv(args.output_dir / "fine_spatial_nulls.csv", index=False)

    support_rows = []
    support_rules = [
        ("All complete section-years", None, None),
        ("Normal-status share >= 0.80", 0.80, None),
        ("Normal-status share >= 0.90", 0.90, None),
        ("Normal-status share >= 0.95", 0.95, None),
        ("Records >= 200", None, 200),
        ("Records >= 500", None, 500),
        ("Normal-status share >= 0.90 and records >= 500", 0.90, 500),
    ]
    for rule_index, (rule, status_min, records_min) in enumerate(support_rules):
        subset = data.copy()
        if status_min is not None:
            subset = subset[subset.normal_status_share.ge(status_min)]
        if records_min is not None:
            subset = subset[subset.records.ge(records_min)]
        subset = subset.reset_index(drop=True)
        subset_z, _, _ = transform(subset)
        subset_pca = PCA(n_components=len(VARIABLES), svd_solver="full").fit(subset_z)
        subset_scores = subset_pca.transform(subset_z)
        index_map = {(r.section_id, int(r.year)): i for i, r in subset[["section_id", "year"]].iterrows()}
        for pair_index, (source_year, target_year) in enumerate(YEAR_PAIRS):
            source = subset[subset.year.eq(source_year)].set_index("section_id")
            target = subset[subset.year.eq(target_year)].set_index("section_id")
            keys = source.index.intersection(target.index)
            ia = np.array([index_map[(key, source_year)] for key in keys])
            ib = np.array([index_map[(key, target_year)] for key in keys])
            strata = target.loc[keys].basin.fillna("Unknown").astype(str).to_numpy()
            metric = lambda a, b: np.linalg.norm(a - b, axis=1)
            observed = np.median(metric(subset_scores[ia], subset_scores[ib]))
            rng = np.random.default_rng(args.seed + 50000 + rule_index * 100 + pair_index)
            null = permuted_medians(
                subset_scores[ia], subset_scores[ib], strata, metric, args.permutations, rng
            )
            null_median = np.median(null)
            support_rows.append({
                "support_rule": rule,
                "section_years": len(subset),
                "physical_sections": subset.section_id.nunique(),
                "year_pair": f"{source_year}-{target_year}",
                "matched_sections": len(keys),
                "same_section_median": observed,
                "basin_null_median": null_median,
                "reduction_percent": 100 * (1 - observed / null_median),
                "lower_tail_p": (1 + int(np.sum(null <= observed))) / (len(null) + 1),
                "permutations": args.permutations,
            })
    pd.DataFrame(support_rows).to_csv(args.output_dir / "observation_support_sensitivity.csv", index=False)

    basin_rows = []
    for pair_index, (source_year, target_year) in enumerate(YEAR_PAIRS):
        source = coordinates[coordinates.year.eq(source_year)].set_index("section_id")
        target = coordinates[coordinates.year.eq(target_year)].set_index("section_id")
        keys = source.index.intersection(target.index)
        for basin_index, (basin, basin_keys_index) in enumerate(target.loc[keys].groupby("basin").groups.items()):
            basin_keys = list(basin_keys_index)
            if len(basin_keys) < 5:
                continue
            source_values = source.loc[basin_keys, [f"PC{i}" for i in range(1, 10)]].to_numpy(float)
            target_values = target.loc[basin_keys, [f"PC{i}" for i in range(1, 10)]].to_numpy(float)
            observed = float(np.median(np.linalg.norm(source_values - target_values, axis=1)))
            rng = np.random.default_rng(args.seed + 60000 + pair_index * 100 + basin_index)
            null = np.array([
                np.median(np.linalg.norm(source_values - target_values[rng.permutation(len(basin_keys))], axis=1))
                for _ in range(args.permutations)
            ])
            null_median = float(np.median(null))
            basin_rows.append({
                "year_pair": f"{source_year}-{target_year}",
                "basin": basin,
                "matched_sections": len(basin_keys),
                "same_section_median": observed,
                "within_basin_null_median": null_median,
                "reduction_percent": 100 * (1 - observed / null_median),
                "lower_tail_p": (1 + int(np.sum(null <= observed))) / (len(null) + 1),
                "permutations": args.permutations,
            })
    pd.DataFrame(basin_rows).to_csv(args.output_dir / "basin_specific_persistence.csv", index=False)

    metadata = {
        "seed": args.seed,
        "permutations": args.permutations,
        "bootstraps": args.bootstraps,
        "rows": len(data),
        "sections": data.section_id.nunique(),
        "explained_variance_ratio": pca.explained_variance_ratio_.tolist(),
        "quintile_thresholds": thresholds.tolist(),
        "pc1_orientation_sign": pc1_sign,
        "calendar_seed": args.calendar_seed,
        "cluster_bootstrap_seed": args.cluster_seed,
        "pc1_orientation_rule": "NH3-N loading negative; dissolved-oxygen loading positive as numerical tie-break",
    }
    (args.output_dir / "analysis_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
