#!/usr/bin/env python3
"""Authoritative restricted-China raw-to-residual preprocessing.

This stage must be run by an authorised data holder. It recreates the exact
semantic conventions used by the frozen Round58 event objects and writes only
pseudonymised four-hour residuals and aggregate QA.

The three conventions that distinguish this implementation from an ordinary
pandas standardisation are:

1. IQR endpoints use nearest-order-statistic quantiles with half-up rounding of
   ``p * (n - 1)``.
2. A zero IQR is a valid observed scale. Non-zero/zero ratios become signed
   infinity and are clipped to +/-8.
3. Zero/zero ratios remain arithmetic NaN but are still counted as structurally
   present for the event-support gate. True missing delta, centre or scale is
   structurally absent.

Raw names and untransformed concentration series are never exported.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import unicodedata
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

AUTHORITY_ID = "ROUND100_RESTORED_ROUND58_SEMANTICS_V1"
VARIABLES = ["water_temp", "pH", "DO", "EC", "turbidity", "CODMn", "NH3N", "TP", "TN"]
RAW_COLUMNS = {
    "水温(℃)": "water_temp",
    "pH(无量纲)": "pH",
    "溶解氧(mg/L)": "DO",
    "电导率(μS/cm)": "EC",
    "浊度(NTU)": "turbidity",
    "高锰酸盐指数(mg/L)": "CODMn",
    "氨氮(mg/L)": "NH3N",
    "总磷(mg/L)": "TP",
    "总氮(mg/L)": "TN",
}
LOG_VARIABLES = {"EC", "turbidity", "CODMn", "NH3N", "TP", "TN"}
USE_COLUMNS = ["省份", "流域", "断面名称", "监测时间", "站点情况"] + list(RAW_COLUMNS)
RANGES = {
    "water_temp": (-5.0, 50.0),
    "pH": (0.0, 14.0),
    "DO": (0.0, 35.0),
    "EC": (0.0, np.inf),
    "turbidity": (0.0, np.inf),
    "CODMn": (0.0, np.inf),
    "NH3N": (0.0, np.inf),
    "TP": (0.0, np.inf),
    "TN": (0.0, np.inf),
}
MISSING_TOKENS = {"*": np.nan, "--": np.nan, "": np.nan, "NA": np.nan, "N/A": np.nan}


def normalize_text(value) -> str:
    if pd.isna(value):
        return ""
    return re.sub(r"\s+", "", unicodedata.normalize("NFKC", str(value)).strip())


def normalize_series(series: pd.Series) -> pd.Series:
    values = series.fillna("").astype(str)
    mapping = {value: normalize_text(value) for value in values.unique()}
    return values.map(mapping)


def parse_mmdd(value: str) -> tuple[int, int]:
    match = re.fullmatch(r"(\d{2})-(\d{2})", value)
    if not match:
        raise argparse.ArgumentTypeError("Expected MM-DD")
    return int(match.group(1)), int(match.group(2))


def nearest_quantile_half_up(values: Iterable[float], probability: float) -> float:
    """Nearest order statistic using half-up, not banker's, tie handling."""
    if not 0.0 <= probability <= 1.0:
        raise ValueError("probability must be in [0, 1]")
    array = np.asarray(list(values) if not isinstance(values, np.ndarray) else values, dtype=float)
    array = np.sort(array[np.isfinite(array)])
    if array.size == 0:
        return float("nan")
    position = probability * (array.size - 1)
    index = int(math.floor(position + 0.5))
    return float(array[index])


def unit_nearest_quantile(data: pd.DataFrame, column: str, probability: float) -> pd.Series:
    return data.groupby("unit_id", sort=False)[column].agg(
        lambda series: nearest_quantile_half_up(series.to_numpy(dtype=float), probability)
    )


def standardize_with_structural_presence(
    delta: np.ndarray,
    centre: np.ndarray,
    scale: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, dict[str, np.ndarray]]:
    """Return bounded z values and the independent structural-presence mask."""
    delta = np.asarray(delta, dtype=float)
    centre = np.asarray(centre, dtype=float)
    scale = np.asarray(scale, dtype=float)
    present = np.isfinite(delta) & np.isfinite(centre) & np.isfinite(scale)
    numerator = delta - centre
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = numerator / scale
    positive_infinity = np.isposinf(ratio) & present
    negative_infinity = np.isneginf(ratio) & present
    arithmetic_nan = np.isnan(ratio) & present
    bounded = np.clip(ratio, -8.0, 8.0)
    bounded[~present] = np.nan
    return bounded, present, {
        "positive_infinity": positive_infinity,
        "negative_infinity": negative_infinity,
        "arithmetic_nan": arithmetic_nan,
        "zero_scale": (scale == 0.0) & np.isfinite(scale),
    }


def read_target_rows(
    path: Path,
    targets: dict[str, tuple[str, str, str]],
    status_value: str,
    chunksize: int,
):
    parts = []
    qa = {
        "source_file": str(path),
        "raw_file_rows": 0,
        "target_section_rows": 0,
        "valid_timestamp_rows": 0,
        "normal_status_rows": 0,
    }
    variable_qa = {variable: {"numeric_rows_before_range": 0, "out_of_range_rows": 0} for variable in VARIABLES}
    for chunk in pd.read_csv(path, usecols=USE_COLUMNS, dtype=str, chunksize=chunksize, low_memory=False):
        qa["raw_file_rows"] += len(chunk)
        key = normalize_series(chunk["省份"]) + "|" + normalize_series(chunk["流域"]) + "|" + normalize_series(chunk["断面名称"])
        selected = key.isin(targets)
        if not selected.any():
            continue
        table = chunk.loc[selected].copy()
        table["key"] = key.loc[selected].values
        qa["target_section_rows"] += len(table)
        table["unit_id"] = table["key"].map(lambda k: targets[k][0])
        table["waterbody_class"] = table["key"].map(lambda k: targets[k][1])
        table["basin"] = table["key"].map(lambda k: targets[k][2])
        table["timestamp_local"] = pd.to_datetime(table["监测时间"], errors="coerce")
        qa["valid_timestamp_rows"] += int(table.timestamp_local.notna().sum())
        table = table[table.timestamp_local.notna()].copy()
        table["station_status"] = table["站点情况"].fillna("").map(normalize_text)
        status_mask = table.station_status.eq(normalize_text(status_value))
        qa["normal_status_rows"] += int(status_mask.sum())
        table = table[status_mask].copy()
        for raw, variable in RAW_COLUMNS.items():
            numeric = pd.to_numeric(table[raw].replace(MISSING_TOKENS), errors="coerce")
            variable_qa[variable]["numeric_rows_before_range"] += int(numeric.notna().sum())
            lower, upper = RANGES[variable]
            invalid = numeric.notna() & ~numeric.between(lower, upper)
            variable_qa[variable]["out_of_range_rows"] += int(invalid.sum())
            table[variable] = numeric.mask(invalid)
        parts.append(table[["unit_id", "waterbody_class", "basin", "timestamp_local"] + VARIABLES])
    if not parts:
        raise RuntimeError(f"No target rows found in {path}")
    data = pd.concat(parts, ignore_index=True)
    before_duplicates = len(data)
    data["time_4h"] = data.timestamp_local.dt.floor("4h")
    aggregated = data.groupby(
        ["unit_id", "waterbody_class", "basin", "time_4h"], as_index=False
    )[VARIABLES].median(numeric_only=True)
    qa["duplicate_or_within_bin_rows_collapsed"] = before_duplicates - len(aggregated)
    qa["four_hour_rows"] = len(aggregated)
    return aggregated, qa, variable_qa


def residualize(
    data: pd.DataFrame,
    year: int,
    start_mmdd: tuple[int, int],
    end_mmdd: tuple[int, int],
) -> tuple[pd.DataFrame, list[dict[str, object]]]:
    start = pd.Timestamp(year=year, month=start_mmdd[0], day=start_mmdd[1])
    end = pd.Timestamp(year=year, month=end_mmdd[0], day=end_mmdd[1]) + pd.Timedelta(days=1) - pd.Timedelta(microseconds=1)
    data = data[data.time_4h.between(start, end)].copy()
    for variable in VARIABLES:
        data["x_" + variable] = np.log1p(data[variable]) if variable in LOG_VARIABLES else data[variable]
    data = data.sort_values(["unit_id", "time_4h"]).reset_index(drop=True)
    gap = data.groupby("unit_id", sort=False).time_4h.diff().dt.total_seconds().div(3600)
    for variable in VARIABLES:
        data["d_" + variable] = data.groupby("unit_id", sort=False)["x_" + variable].diff().where(gap.eq(4))
    data["month"] = data.time_4h.dt.month.astype("int8")
    data["hour"] = data.time_4h.dt.hour.astype("int8")
    data["date_local"] = data.time_4h.dt.normalize()

    presence_columns: list[str] = []
    semantics_qa: list[dict[str, object]] = []
    for variable in VARIABLES:
        column = "d_" + variable
        centre = data.groupby(["unit_id", "month", "hour"], sort=False)[column].transform("median")
        centre = centre.fillna(data.groupby("unit_id", sort=False)[column].transform("median"))
        q25 = unit_nearest_quantile(data, column, 0.25)
        q75 = unit_nearest_quantile(data, column, 0.75)
        unit_scale = q75 - q25  # zero is deliberately preserved
        mapped_scale = data.unit_id.map(unit_scale).to_numpy(dtype=float)
        z, present, masks = standardize_with_structural_presence(
            data[column].to_numpy(dtype=float), centre.to_numpy(dtype=float), mapped_scale
        )
        z_column = "z_" + variable
        present_column = "present_" + variable
        data[z_column] = z
        data[present_column] = present
        presence_columns.append(present_column)
        zero_scale_units = int((unit_scale == 0.0).sum())
        semantics_qa.append({
            "year": year,
            "variable": variable,
            "finite_delta_rows": int(data[column].notna().sum()),
            "structurally_present_rows": int(present.sum()),
            "finite_standardised_rows": int(np.isfinite(z).sum()),
            "arithmetic_nan_present_rows": int(masks["arithmetic_nan"].sum()),
            "positive_infinity_clipped_rows": int(masks["positive_infinity"].sum()),
            "negative_infinity_clipped_rows": int(masks["negative_infinity"].sum()),
            "zero_iqr_units": zero_scale_units,
        })
    data["complete9"] = data[presence_columns].all(axis=1)
    support = data.groupby("unit_id", sort=False).complete9.sum()
    data["n_complete9"] = data.unit_id.map(support)
    return data, semantics_qa


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-2023", type=Path, required=True)
    parser.add_argument("--raw-2024", type=Path, required=True)
    parser.add_argument("--classification", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--status-value", default="正常")
    parser.add_argument("--start-mmdd", type=parse_mmdd, default=parse_mmdd("01-16"))
    parser.add_argument("--end-mmdd", type=parse_mmdd, default=parse_mmdd("09-19"))
    parser.add_argument("--minimum-section-residuals", type=int, default=200)
    parser.add_argument("--chunksize", type=int, default=500000)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    metadata = pd.read_csv(args.classification)
    metadata["key"] = metadata["key_norm_std"].map(normalize_text)
    targets = {row.key: (row.unit_id, row.waterbody_class, row.basin) for row in metadata.itertuples()}
    daily_support, qa_rows, variable_rows, semantics_rows = [], [], [], []
    for year, path in [(2023, args.raw_2023), (2024, args.raw_2024)]:
        four_hour, qa, variable_qa = read_target_rows(path, targets, args.status_value, args.chunksize)
        residual, semantic_qa = residualize(four_hour, year, args.start_mmdd, args.end_mmdd)
        keep = [
            "unit_id", "basin", "waterbody_class", "time_4h", "date_local",
            "month", "hour", "n_complete9", "complete9",
        ] + ["z_" + variable for variable in VARIABLES]
        residual[keep].to_csv(
            args.output_dir / f"china_{year}_deidentified_9var_residuals.csv.gz",
            index=False,
            compression="gzip",
        )
        eligible = residual[
            residual.waterbody_class.eq("river")
            & residual.complete9
            & residual.n_complete9.ge(args.minimum_section_residuals)
        ].copy()
        support_table = eligible.groupby(["basin", "date_local"]).agg(
            n_obs=("unit_id", "size"), n_sections=("unit_id", "nunique")
        ).reset_index()
        support_table["year"] = year
        daily_support.append(support_table)
        qa.update({
            "year": year,
            "analysis_start": f"{year}-{args.start_mmdd[0]:02d}-{args.start_mmdd[1]:02d}",
            "analysis_end": f"{year}-{args.end_mmdd[0]:02d}-{args.end_mmdd[1]:02d}",
            "required_status": args.status_value,
            "residual_rows_in_analysis_window": len(residual),
            "eligible_complete_rows": len(eligible),
            "eligible_sections": int(eligible.unit_id.nunique()),
        })
        qa_rows.append(qa)
        semantics_rows.extend(semantic_qa)
        for variable, values in variable_qa.items():
            variable_rows.append({"year": year, "variable": variable, **values})

    pd.concat(daily_support, ignore_index=True).to_csv(
        args.output_dir / "daily_chemistry_support.csv.gz", index=False, compression="gzip"
    )
    pd.DataFrame(qa_rows).to_csv(args.output_dir / "raw_preprocessing_QA.csv", index=False)
    pd.DataFrame(variable_rows).to_csv(args.output_dir / "variable_range_QA.csv", index=False)
    pd.DataFrame(semantics_rows).to_csv(args.output_dir / "authoritative_semantics_QA.csv", index=False)
    metadata_out = {
        "authority_id": AUTHORITY_ID,
        "status_filter": args.status_value,
        "analysis_start_mmdd": f"{args.start_mmdd[0]:02d}-{args.start_mmdd[1]:02d}",
        "analysis_end_mmdd": f"{args.end_mmdd[0]:02d}-{args.end_mmdd[1]:02d}",
        "minimum_complete_residuals_per_section": args.minimum_section_residuals,
        "quantile_rule": "nearest order statistic; index=floor(p*(n-1)+0.5)",
        "zero_iqr_nonzero_numerator": "signed infinity clipped to +/-8",
        "zero_iqr_zero_numerator": "arithmetic NaN retained; structural presence remains true",
        "support_rule": "all nine delta, centre and scale objects structurally present; numeric finiteness is separate",
        "raw_observations_redistributed": False,
    }
    (args.output_dir / "preprocessing_metadata.json").write_text(
        json.dumps(metadata_out, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({"authority": metadata_out, "years": qa_rows}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
