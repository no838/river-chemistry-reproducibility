#!/usr/bin/env python3
"""Bounded post hoc sensitivities for scale-separation claims."""
from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.neighbors import NearestNeighbors

PC_COLUMNS = [f"PC{i}" for i in range(1, 10)]
DELTA_COLUMNS = [
    "d_water_temp", "d_pH", "d_DO", "d_EC", "d_turbidity",
    "d_CODMn", "d_NH3N", "d_TP", "d_TN",
]
RELATIVE_HOURS = list(range(-24, 49, 4))


def plus_one(count: int, total: int) -> float:
    return float((count + 1) / (total + 1))


def load_annual_module(script_path: Path):
    spec = importlib.util.spec_from_file_location("annual_state_analysis", script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def minimum_per_variable_support(annual, annual_module, output_dir, seed):
    count_columns = [f"{variable}_n" for variable in annual_module.VARIABLES]
    rows = []
    for threshold_index, threshold in enumerate([50, 100, 200, 500]):
        subset = annual[annual[count_columns].min(axis=1).ge(threshold)].reset_index(drop=True)
        coordinates, *_ = annual_module.fit_primary(subset)
        for pair_index, (year_a, year_b) in enumerate(annual_module.YEAR_PAIRS):
            first = coordinates[coordinates["year"].eq(year_a)].set_index("section_id")
            second = coordinates[coordinates["year"].eq(year_b)].set_index("section_id")
            keys = first.index.intersection(second.index)
            state_a = first.loc[keys, PC_COLUMNS].to_numpy(float)
            state_b = second.loc[keys, PC_COLUMNS].to_numpy(float)
            observed = float(np.median(np.linalg.norm(state_a - state_b, axis=1)))
            strata = second.loc[keys, "basin"].astype(str).to_numpy()
            rng = np.random.default_rng(seed + threshold_index * 10 + pair_index)
            null = annual_module.permuted_medians(
                state_a,
                state_b,
                strata,
                lambda left, right: np.linalg.norm(left - right, axis=1),
                2_000,
                rng,
            )
            null_median = float(np.median(null))
            rows.append({
                "minimum_observations_for_each_variable": threshold,
                "section_years": len(subset),
                "physical_sections": subset["section_id"].nunique(),
                "year_pair": f"{year_a}-{year_b}",
                "matched_sections": len(keys),
                "same_section_median": observed,
                "basin_null_median": null_median,
                "reduction_percent": 100 * (1 - observed / null_median),
                "lower_tail_p": plus_one(int((null <= observed).sum()), len(null)),
                "permutations": 2_000,
                "analysis_role": "post hoc support sensitivity",
            })
    table = pd.DataFrame(rows)
    table.to_csv(output_dir / "minimum_per_variable_support.csv", index=False)


def nearest_other_section(coordinates, section_coordinates, output_dir, seed):
    data = coordinates.merge(
        section_coordinates,
        on=["section_id", "basin"],
        how="left",
        validate="many_to_one",
    )
    rows = []
    for pair_index, (year_a, year_b) in enumerate([(2022, 2023), (2023, 2024), (2022, 2024)]):
        first = data[data["year"].eq(year_a)].set_index("section_id")
        second = data[data["year"].eq(year_b)].set_index("section_id")
        keys = first.index.intersection(second.index)
        keys = [
            key for key in keys
            if pd.notna(first.loc[key, "longitude"]) and pd.notna(second.loc[key, "longitude"])
        ]
        same_distances = []
        nearest_distances = []
        basin_labels = []
        for basin in sorted(set(first.loc[keys, "basin"])):
            basin_keys = [key for key in keys if first.loc[key, "basin"] == basin]
            if len(basin_keys) < 2:
                continue
            locations = np.radians(second.loc[basin_keys, ["latitude", "longitude"]].to_numpy(float))
            neighbours = NearestNeighbors(n_neighbors=2, metric="haversine").fit(locations)
            _, indices = neighbours.kneighbors(locations)
            state_a = first.loc[basin_keys, PC_COLUMNS].to_numpy(float)
            state_b = second.loc[basin_keys, PC_COLUMNS].to_numpy(float)
            for position in range(len(basin_keys)):
                same_distances.append(np.linalg.norm(state_a[position] - state_b[position]))
                nearest_distances.append(np.linalg.norm(state_a[position] - state_b[indices[position, 1]]))
                basin_labels.append(basin)
        same = np.asarray(same_distances)
        nearest = np.asarray(nearest_distances)
        labels = np.asarray(basin_labels)
        reduction = 100 * (1 - np.median(same) / np.median(nearest))
        groups = {basin: np.flatnonzero(labels == basin) for basin in np.unique(labels)}
        rng = np.random.default_rng(seed + 100 + pair_index)
        bootstrap = np.empty(5_000)
        for replicate in range(5_000):
            positions = np.concatenate(
                [rng.choice(group, size=len(group), replace=True) for group in groups.values()]
            )
            bootstrap[replicate] = 100 * (
                1 - np.median(same[positions]) / np.median(nearest[positions])
            )
        rows.append({
            "year_pair": f"{year_a}-{year_b}",
            "mapped_matched_sections": len(same),
            "same_section_median": np.median(same),
            "nearest_other_section_median": np.median(nearest),
            "reduction_vs_nearest_other_percent": reduction,
            "ci_low": np.quantile(bootstrap, 0.025),
            "ci_high": np.quantile(bootstrap, 0.975),
            "fraction_same_section_closer": np.mean(same < nearest),
            "coordinate_resolution": "0.02 degree rounded coordinates",
            "analysis_role": "post hoc local-spatial sensitivity",
        })
    pd.DataFrame(rows).to_csv(output_dir / "nearest_other_section_null.csv", index=False)


def leave_one_basin_out(basin_trajectory, output_dir):
    basins = sorted(basin_trajectory["basin"].unique())
    rows = []
    for source_year, target_year in [(2024, 2023), (2023, 2024)]:
        for held_out_basin in basins:
            source = (
                basin_trajectory[
                    basin_trajectory["year"].eq(source_year)
                    & ~basin_trajectory["basin"].eq(held_out_basin)
                ]
                .groupby("rel_h")[DELTA_COLUMNS]
                .mean()
                .reindex(RELATIVE_HOURS)
                .to_numpy(float)
            )
            direction = source.ravel()
            direction = direction / np.linalg.norm(direction)
            target = (
                basin_trajectory[
                    basin_trajectory["year"].eq(target_year)
                    & basin_trajectory["basin"].eq(held_out_basin)
                ]
                .set_index("rel_h")
                .reindex(RELATIVE_HOURS)[DELTA_COLUMNS]
                .to_numpy(float)
            )
            rows.append({
                "source_year": source_year,
                "target_year": target_year,
                "held_out_basin": held_out_basin,
                "projection": float(target.ravel() @ direction),
            })
    table = pd.DataFrame(rows)
    table.to_csv(output_dir / "leave_one_basin_out_china.csv", index=False)
    summary = (
        table.groupby(["source_year", "target_year"])
        .agg(
            basins=("projection", "size"),
            positive_basins=("projection", lambda values: int((values > 0).sum())),
            mean_projection=("projection", "mean"),
            minimum_projection=("projection", "min"),
        )
        .reset_index()
    )
    summary["exact_signflip_p"] = summary["basins"].map(lambda n: 1 / (2**n))
    summary.to_csv(output_dir / "leave_one_basin_out_china_summary.csv", index=False)


def usgs_site_influence(site_projections, output_dir):
    rows = []
    for site in site_projections["site"]:
        subset = site_projections[~site_projections["site"].eq(site)]
        rows.append({
            "analysis": "leave one site out",
            "omitted_site": site,
            "sites": len(subset),
            "mean_projection": subset["projection"].mean(),
            "positive_sites": int((subset["projection"] > 0).sum()),
            "exact_signflip_p": np.nan,
        })
    supported = site_projections[site_projections["n_site_years"].ge(2)]
    rows.append({
        "analysis": "at least two site-years",
        "omitted_site": "",
        "sites": len(supported),
        "mean_projection": supported["projection"].mean(),
        "positive_sites": int((supported["projection"] > 0).sum()),
        "exact_signflip_p": 1 / (2 ** len(supported)) if (supported["projection"] > 0).all() else np.nan,
    })
    pd.DataFrame(rows).to_csv(output_dir / "usgs_site_influence.csv", index=False)



def laboratory_analyte_persistence(annual, output_dir, seed):
    variables = ["CODMn", "NH3_N", "TP", "TN"]
    transformed = np.column_stack([
        np.log1p(annual[variable].to_numpy(float))
        for variable in variables
    ])
    median = np.median(transformed, axis=0)
    iqr = (
        np.quantile(transformed, 0.75, axis=0)
        - np.quantile(transformed, 0.25, axis=0)
    )
    scaled = (transformed - median) / iqr
    scores = PCA(
        n_components=len(variables), svd_solver="full"
    ).fit_transform(scaled)
    coordinates = annual[["section_id", "year", "basin"]].copy()
    pc_columns = []
    for index in range(scores.shape[1]):
        column = f"PC{index+1}"
        coordinates[column] = scores[:, index]
        pc_columns.append(column)

    rows = []
    for pair_index, (year_a, year_b) in enumerate([(2022, 2023), (2023, 2024), (2022, 2024)]):
        first = coordinates[coordinates.year.eq(year_a)].set_index("section_id")
        second = coordinates[coordinates.year.eq(year_b)].set_index("section_id")
        keys = first.index.intersection(second.index)
        state_a = first.loc[keys, pc_columns].to_numpy(float)
        state_b = second.loc[keys, pc_columns].to_numpy(float)
        strata = second.loc[keys, "basin"].astype(str).to_numpy()
        observed = float(np.median(np.linalg.norm(state_a - state_b, axis=1)))
        groups = [np.flatnonzero(strata == value) for value in pd.unique(strata)]
        rng = np.random.default_rng(seed + 500 + pair_index)
        null = np.empty(2000)
        for replicate in range(2000):
            permutation = np.arange(len(keys))
            for group in groups:
                permutation[group] = rng.permutation(group)
            null[replicate] = np.median(
                np.linalg.norm(state_a - state_b[permutation], axis=1)
            )
        null_median = float(np.median(null))
        rows.append({
            "representation": "CODMn + NH3-N + TP + TN",
            "year_pair": f"{year_a}-{year_b}",
            "matched_sections": len(keys),
            "same_section_median": observed,
            "basin_null_median": null_median,
            "reduction_percent": 100 * (1 - observed / null_median),
            "lower_tail_p": plus_one(int((null <= observed).sum()), len(null)),
            "permutations": len(null),
            "analysis_role": "post hoc laboratory-analyte sensitivity",
        })
    pd.DataFrame(rows).to_csv(
        output_dir / "laboratory_analyte_persistence.csv", index=False
    )

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--annual-input", type=Path, required=True)
    parser.add_argument("--annual-coordinates", type=Path, required=True)
    parser.add_argument("--section-coordinates", type=Path, required=True)
    parser.add_argument("--annual-script", type=Path, required=True)
    parser.add_argument("--basin-trajectory", type=Path, required=True)
    parser.add_argument("--usgs-site-projections", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20262000)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    annual = pd.read_csv(args.annual_input)
    coordinates = pd.read_csv(args.annual_coordinates)
    section_coordinates = pd.read_csv(args.section_coordinates)
    basin_trajectory = pd.read_csv(args.basin_trajectory)
    site_projections = pd.read_csv(args.usgs_site_projections)

    annual_module = load_annual_module(args.annual_script)
    minimum_per_variable_support(annual, annual_module, args.output_dir, args.seed)
    nearest_other_section(coordinates, section_coordinates, args.output_dir, args.seed)
    leave_one_basin_out(basin_trajectory, args.output_dir)
    usgs_site_influence(site_projections, args.output_dir)
    laboratory_analyte_persistence(annual, args.output_dir, args.seed)
    print("Scale-separation sensitivities completed")


if __name__ == "__main__":
    main()
