#!/usr/bin/env python3
"""Validate Round100 raw preprocessing semantics and optional event-table regression.

The self-test requires no governed data. An authorised holder may additionally pass a
newly reconstructed section-event table and the frozen table to execute the full
raw-to-event semantic regression.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd


def load_authority_module(script: Path):
    spec = importlib.util.spec_from_file_location("round100_raw_authority", script)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {script}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def self_test(module) -> dict[str, object]:
    checks: dict[str, object] = {}
    checks["nearest_q25_half_up"] = module.nearest_quantile_half_up(np.array([0.0, 1.0, 2.0]), 0.25)
    checks["nearest_q75_half_up"] = module.nearest_quantile_half_up(np.array([0.0, 1.0, 2.0]), 0.75)
    delta = np.array([0.0, 1.0, -1.0, np.nan])
    centre = np.array([0.0, 0.0, 0.0, 0.0])
    scale = np.array([0.0, 0.0, 0.0, 0.0])
    z, present, masks = module.standardize_with_structural_presence(delta, centre, scale)
    checks.update({
        "zero_over_zero_is_nan": bool(np.isnan(z[0])),
        "positive_over_zero_clips_to_8": float(z[1]),
        "negative_over_zero_clips_to_minus8": float(z[2]),
        "true_missing_is_absent": bool(not present[3]),
        "zero_over_zero_is_structurally_present": bool(present[0]),
        "arithmetic_nan_count": int(masks["arithmetic_nan"].sum()),
    })
    expected = {
        "nearest_q25_half_up": 1.0,
        "nearest_q75_half_up": 2.0,
        "zero_over_zero_is_nan": True,
        "positive_over_zero_clips_to_8": 8.0,
        "negative_over_zero_clips_to_minus8": -8.0,
        "true_missing_is_absent": True,
        "zero_over_zero_is_structurally_present": True,
        "arithmetic_nan_count": 1,
    }
    checks["pass"] = all(checks[key] == value for key, value in expected.items())
    checks["expected"] = expected
    return checks


def compare_event_tables(reconstructed: Path, frozen: Path, tolerance: float) -> dict[str, object]:
    left = pd.read_csv(reconstructed)
    right = pd.read_csv(frozen)
    key_candidates = ["year", "episode_id", "basin", "unit_id"]
    keys = [key for key in key_candidates if key in left.columns and key in right.columns]
    if len(keys) < 3:
        raise ValueError(f"Insufficient shared keys: {keys}")
    merged = left.merge(right, on=keys, how="outer", suffixes=("_new", "_frozen"), indicator=True)
    left_only = int((merged._merge == "left_only").sum())
    right_only = int((merged._merge == "right_only").sum())
    common = merged[merged._merge == "both"]
    numeric_bases = []
    for column in left.select_dtypes(include=[np.number]).columns:
        if column in keys or column not in right.columns:
            continue
        numeric_bases.append(column)
    max_abs = 0.0
    per_column = {}
    for column in numeric_bases:
        a = pd.to_numeric(common[f"{column}_new"], errors="coerce").to_numpy(float)
        b = pd.to_numeric(common[f"{column}_frozen"], errors="coerce").to_numpy(float)
        finite = np.isfinite(a) & np.isfinite(b)
        mismatch_nan = int((np.isnan(a) ^ np.isnan(b)).sum())
        diff = float(np.max(np.abs(a[finite] - b[finite]))) if finite.any() else 0.0
        max_abs = max(max_abs, diff)
        per_column[column] = {"max_abs_error": diff, "nan_pattern_mismatches": mismatch_nan}
    passed = left_only == 0 and right_only == 0 and max_abs <= tolerance and all(
        item["nan_pattern_mismatches"] == 0 for item in per_column.values()
    )
    return {
        "reconstructed_rows": int(len(left)),
        "frozen_rows": int(len(right)),
        "keys": keys,
        "left_only_keys": left_only,
        "right_only_keys": right_only,
        "numeric_columns_compared": len(numeric_bases),
        "maximum_absolute_numeric_error": max_abs,
        "tolerance": tolerance,
        "pass": passed,
        "per_column": per_column,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    default_script = Path(__file__).with_name("10_raw_china_water_quality_to_daily_support.py")
    parser.add_argument("--authority-script", type=Path, default=default_script)
    parser.add_argument("--reconstructed-event-table", type=Path)
    parser.add_argument("--frozen-event-table", type=Path)
    parser.add_argument("--tolerance", type=float, default=1e-10)
    parser.add_argument("--expected-authority-qa", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    module = load_authority_module(args.authority_script)
    report: dict[str, object] = {
        "authority_script": str(args.authority_script.resolve()),
        "authority_id": getattr(module, "AUTHORITY_ID", "UNKNOWN"),
        "semantic_self_test": self_test(module),
        "raw_event_regression_executed": False,
    }
    if bool(args.reconstructed_event_table) != bool(args.frozen_event_table):
        raise ValueError("Pass both --reconstructed-event-table and --frozen-event-table, or neither")
    if args.reconstructed_event_table and args.frozen_event_table:
        report["raw_event_regression"] = compare_event_tables(
            args.reconstructed_event_table, args.frozen_event_table, args.tolerance
        )
        report["raw_event_regression_executed"] = True
    if args.expected_authority_qa:
        report["previous_authority_regression"] = json.loads(args.expected_authority_qa.read_text(encoding="utf-8"))
    report["pass"] = bool(report["semantic_self_test"]["pass"]) and (
        not report["raw_event_regression_executed"] or bool(report["raw_event_regression"]["pass"])
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
