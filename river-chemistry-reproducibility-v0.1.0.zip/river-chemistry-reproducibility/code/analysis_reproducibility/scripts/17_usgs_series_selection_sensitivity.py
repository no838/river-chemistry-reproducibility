#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
KEY=["site","year","peak_time","control_time"]
def numdiff(a,b,keys):
 m=a.merge(b,on=keys,suffixes=("_a","_b"));rows=[]
 for c in sorted((set(a.columns)&set(b.columns))-set(keys)):
  x=pd.to_numeric(m.get(c+"_a"),errors="coerce");y=pd.to_numeric(m.get(c+"_b"),errors="coerce")
  if x is None or y is None or (not x.notna().any() and not y.notna().any()):continue
  rows.append({"column":c,"compared_rows":int((x.notna()&y.notna()).sum()),"maximum_absolute_difference":float((x-y).abs().max(skipna=True))})
 return pd.DataFrame(rows),m
def inventory(path,mode):
 q=pd.read_csv(path);rows=[]
 for _,r in q.iterrows():
  d=json.loads(r.get("series_selection","{}")) if pd.notna(r.get("series_selection")) else {}
  for v,z in d.items():rows.append({"series_mode":mode,"site":r.site,"year":int(r.year),"variable":v,"selected_time_series_id":z.get("selected"),"available_time_series_count":z.get("available_series"),"overlap_fraction":z.get("overlap_fraction"),"n_metric_events":r.get("n_metric_events")})
 return pd.DataFrame(rows)
def main():
 ap=argparse.ArgumentParser()
 for x in ["formal-events","median-events","primary-events","median-qa","primary-qa","median-inference","primary-inference","output-dir"]:ap.add_argument("--"+x,type=Path,required=True)
 a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
 f=pd.read_csv(a.formal_events);m=pd.read_csv(a.median_events);p=pd.read_csv(a.primary_events);f=f[f.year.isin([2022,2023,2024])]
 fk=set(map(tuple,f[KEY].astype(str).to_numpy()));mk=set(map(tuple,m[KEY].astype(str).to_numpy()));pk=set(map(tuple,p[KEY].astype(str).to_numpy()))
 overlap=pd.DataFrame([{"comparison":"cache median versus metadata-primary","events_left":len(m),"events_right":len(p),"shared_event_keys":len(mk&pk),"left_only":len(mk-pk),"right_only":len(pk-mk)},{"comparison":"formal distributed cohort versus regenerated cache median","events_left":len(f),"events_right":len(m),"shared_event_keys":len(fk&mk),"left_only":len(fk-mk),"right_only":len(mk-fk)}]);overlap.to_csv(a.output_dir/"event_overlap_summary.csv",index=False)
 nd,_=numdiff(m,p,KEY);nd.to_csv(a.output_dir/"event_numeric_identity.csv",index=False)
 summaries=[];allnum=[];keymap={"primary_three_test_family.csv":["Test"],"site_projections.csv":["site"],"leave_one_variable_out.csv":["omitted_variable"]}
 for fn,keys in keymap.items():
  aa=pd.read_csv(a.median_inference/fn);bb=pd.read_csv(a.primary_inference/fn);n,mm=numdiff(aa,bb,keys)
  summaries.append({"table":fn,"rows_median":len(aa),"rows_metadata_primary":len(bb),"matched_rows":len(mm),"maximum_absolute_numeric_difference":float(n.maximum_absolute_difference.max()) if len(n) else 0.})
  n.insert(0,"table",fn);allnum.append(n)
 pd.DataFrame(summaries).to_csv(a.output_dir/"inference_comparison_summary.csv",index=False);pd.concat(allnum,ignore_index=True).to_csv(a.output_dir/"inference_numeric_identity.csv",index=False)
 inv=pd.concat([inventory(a.median_qa,"median-collapse"),inventory(a.primary_qa,"metadata-primary")],ignore_index=True);inv.to_csv(a.output_dir/"series_selection_inventory.csv",index=False)
 fam=pd.read_csv(a.primary_inference/"primary_three_test_family.csv");meta={"decision":"SERIES_SELECTION_INVARIANT_IN_REGENERATED_CACHE","regenerated_cache_events":len(p),"formal_primary_event_overlap":len(fk&pk),"cache_event_keys_identical":bool(mk==pk),"cache_trajectory_max_abs_difference":float(nd.maximum_absolute_difference.max()) if len(nd) else 0.,"inference_max_abs_difference":float(pd.DataFrame(summaries).maximum_absolute_numeric_difference.max()),"metadata_primary_whole_trajectory_estimate":float(fam.loc[fam.Test.eq("Whole-trajectory projection"),"Estimate"].iloc[0]),"interpretation":"Within the regenerated 2022–2024 public cache, both rules produced identical events and inference. The cache includes events beyond the formal cohort, so this is a sensitivity rather than a replacement analysis."}
 (a.output_dir/"decision.json").write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
if __name__=="__main__":main()
