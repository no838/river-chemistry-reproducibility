#!/usr/bin/env python3
"""Recalculate China event-response objects and estimand-aligned cross-year tests.

Two response objects are kept distinct.

1. ``constituent direction``: a nine-variable unit vector estimated from
   basin-level constituent responses. It is used to score event phases.
2. ``whole-trajectory template``: a relative-time-by-variable matrix flattened
   to a unit vector. It is used for cross-year trajectory transfer and, after
   restricting to five variables, for the USGS external projection.

The primary China phase estimand is basin held out: for each target basin, its
source-year counterpart is excluded when the constituent direction is fitted.
Uncertainty intervals resample both target basins and the corresponding
source-basin pools. Whole-trajectory transfer uses the analogous held-out
estimand and estimand-aligned source-target bootstrap intervals.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import t as student_t

VARIABLES = ["water_temp", "pH", "DO", "EC", "turbidity", "CODMn", "NH3N", "TP", "TN"]
SHARED_VARIABLES = ["water_temp", "pH", "DO", "EC", "turbidity"]
DELTA_COLUMNS = [f"d_{variable}" for variable in VARIABLES]
SHARED_DELTA_COLUMNS = [f"d_{variable}" for variable in SHARED_VARIABLES]
RELATIVE_HOURS = list(range(-24, 49, 4))
PHASES = {
    "pre": [-24, -20, -16],
    "rising": [-12, -8, -4],
    "peak": [0, 4, 8],
    "early_recovery": [12, 16, 20, 24],
    "late_recovery": [28, 32, 36, 40, 44, 48],
}


def unit_vector(values: np.ndarray) -> np.ndarray:
    array = np.asarray(values, float)
    norm = np.linalg.norm(array)
    if not np.isfinite(norm) or norm <= 0:
        raise ValueError("Cannot normalise a zero or non-finite vector")
    return array / norm


def exact_signflip(values: np.ndarray, alternative: str = "greater") -> float:
    array = np.asarray(values, float)
    array = array[np.isfinite(array)]
    observed = float(array.mean())
    null = []
    for bits in range(2 ** len(array)):
        signs = np.array([1 if (bits >> index) & 1 else -1 for index in range(len(array))])
        null.append(float(np.mean(array * signs)))
    null = np.asarray(null)
    if alternative == "greater":
        return float(np.mean(null >= observed - 1e-15))
    if alternative == "less":
        return float(np.mean(null <= observed + 1e-15))
    return float(np.mean(np.abs(null) >= abs(observed) - 1e-15))


def percentile_interval(values: np.ndarray, replicates: int, seed: int) -> tuple[float, float]:
    array = np.asarray(values, float)
    rng = np.random.default_rng(seed)
    sample = rng.choice(array, (replicates, len(array)), replace=True).mean(axis=1)
    return tuple(np.quantile(sample, [0.025, 0.975]))


def t_interval(values: np.ndarray) -> tuple[float, float]:
    array = np.asarray(values, float)
    array = array[np.isfinite(array)]
    if len(array) < 2:
        return np.nan, np.nan
    mean = float(array.mean())
    se = float(array.std(ddof=1) / np.sqrt(len(array)))
    critical = float(student_t.ppf(0.975, len(array) - 1))
    return mean - critical * se, mean + critical * se


def holm(raw_p: list[float] | np.ndarray) -> np.ndarray:
    p_values = np.asarray(raw_p, float)
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, (len(p_values) - rank) * p_values[index])
        adjusted[index] = min(1.0, running)
    return adjusted


def direction_from_summary(variable_response: pd.DataFrame, year: int) -> np.ndarray:
    vector = (
        variable_response[variable_response.year.eq(year)]
        .set_index("variable")
        .reindex(VARIABLES)
        .mean_delta.to_numpy(float)
    )
    if not np.isfinite(vector).all():
        raise ValueError(f"Non-finite constituent vector for {year}")
    return unit_vector(vector)


def direction_from_basin_summary(
    basin_response: pd.DataFrame,
    year: int,
    exclude_basin: str | None = None,
    resample_indices: np.ndarray | None = None,
) -> np.ndarray:
    subset = basin_response[basin_response.year.eq(year)].copy()
    if exclude_basin is not None:
        subset = subset[~subset.basin.eq(exclude_basin)]
    subset = subset.sort_values("basin").reset_index(drop=True)
    matrix = subset[VARIABLES].to_numpy(float)
    if resample_indices is not None:
        matrix = matrix[np.asarray(resample_indices, int)]
    return unit_vector(matrix.mean(axis=0))


def phase_table(
    basin_time: pd.DataFrame,
    directions: dict[int, np.ndarray],
    cross_fitted: bool,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for (year, basin), group in basin_time.groupby(["year", "basin"], sort=True):
        scoring_year = (2024 if year == 2023 else 2023) if cross_fitted else year
        direction = directions[scoring_year]
        aligned = group.set_index("rel_h").reindex(RELATIVE_HOURS)
        matrix = aligned[DELTA_COLUMNS].to_numpy(float)
        rate = matrix @ direction
        cumulative = np.cumsum(rate)
        for hour, rate_value, cumulative_value in zip(RELATIVE_HOURS, rate, cumulative):
            rows.append({
                "object": "time", "year": int(year), "scoring_direction_year": int(scoring_year),
                "basin": basin, "rel_h": int(hour), "phase": "",
                "rate_projection": float(rate_value), "cumulative_projection": float(cumulative_value),
                "node_projection": np.nan,
                **{variable: np.nan for variable in VARIABLES},
            })
        for phase, hours in PHASES.items():
            vector = aligned.loc[hours, DELTA_COLUMNS].mean(axis=0).to_numpy(float)
            rows.append({
                "object": "phase", "year": int(year), "scoring_direction_year": int(scoring_year),
                "basin": basin, "rel_h": np.nan, "phase": phase,
                "rate_projection": np.nan, "cumulative_projection": np.nan,
                "node_projection": float(vector @ direction),
                **{variable: float(vector[index]) for index, variable in enumerate(VARIABLES)},
            })
    table = pd.DataFrame(rows)
    trajectory = table[table.object.eq("time")].drop(columns=["object", "phase", "node_projection"] + VARIABLES)
    phase = table[table.object.eq("phase")].drop(
        columns=["object", "rel_h", "rate_projection", "cumulative_projection"]
    )
    return trajectory.reset_index(drop=True), phase.reset_index(drop=True)


def conditional_phase_tests(phase: pd.DataFrame, bootstraps: int, seed: int) -> pd.DataFrame:
    """Non-held-out cross-fitted tests retained as a secondary sensitivity."""
    rows = []
    for year in [2023, 2024]:
        subset = phase[phase.year.eq(year)]
        scoring_year = int(subset.scoring_direction_year.iloc[0])
        pivot = subset.pivot(index="basin", columns="phase", values="node_projection")
        definitions = [
            ("peak_minus_pre", pivot["peak"] - pivot["pre"], "greater"),
            ("late_minus_peak", pivot["late_recovery"] - pivot["peak"], "less"),
        ]
        year_rows = []
        for index, (name, values, alternative) in enumerate(definitions):
            array = values.dropna().to_numpy(float)
            low, high = percentile_interval(array, bootstraps, seed + year + index * 100)
            t_low, t_high = t_interval(array)
            year_rows.append({
                "year": year,
                "scoring_direction_year": scoring_year,
                "inference_role": "non-held-out cross-fitted sensitivity",
                "test": name,
                "n_basins": len(array),
                "estimate": float(array.mean()),
                "median": float(np.median(array)),
                "bootstrap_ci_low": low,
                "bootstrap_ci_high": high,
                "t_ci_low": t_low,
                "t_ci_high": t_high,
                "alternative": alternative,
                "conditional_exact_p": exact_signflip(array, alternative),
                "basins_in_expected_direction": int(
                    (array > 0).sum() if alternative == "greater" else (array < 0).sum()
                ),
            })
        adjusted = holm([row["conditional_exact_p"] for row in year_rows])
        for row, value in zip(year_rows, adjusted):
            row["conditional_holm_p"] = value
        rows.extend(year_rows)
    return pd.DataFrame(rows)


def construction_descriptive(phase: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for year in [2023, 2024]:
        subset = phase[phase.year.eq(year)]
        pivot = subset.pivot(index="basin", columns="phase", values="node_projection")
        for name, values in [
            ("peak_minus_pre", pivot["peak"] - pivot["pre"]),
            ("late_minus_peak", pivot["late_recovery"] - pivot["peak"]),
        ]:
            array = values.dropna().to_numpy(float)
            rows.append({
                "year": year, "scoring_direction_year": year,
                "role": "same-year construction descriptive", "test": name,
                "n_basins": len(array), "estimate": float(array.mean()),
                "median": float(np.median(array)), "minimum": float(array.min()),
                "maximum": float(array.max()), "p_value_reported": False,
            })
    return pd.DataFrame(rows)


def basin_phase_vectors(basin_time: pd.DataFrame, year: int) -> dict[str, dict[str, np.ndarray]]:
    output: dict[str, dict[str, np.ndarray]] = {}
    for basin, group in basin_time[basin_time.year.eq(year)].groupby("basin", sort=True):
        aligned = group.set_index("rel_h").reindex(RELATIVE_HOURS)
        output[basin] = {
            phase: aligned.loc[hours, DELTA_COLUMNS].mean(axis=0).to_numpy(float)
            for phase, hours in PHASES.items()
        }
    return output


def heldout_phase_analysis(
    basin_time: pd.DataFrame,
    basin_response: pd.DataFrame,
    replicates: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Basin-held-out time/phase scores with estimand-aligned source-target intervals."""
    trajectory_rows = []
    phase_rows = []
    test_rows = []
    basins = sorted(set(basin_time.basin) & set(basin_response.basin))
    for target_year, source_year, offset in [(2023, 2024, 0), (2024, 2023, 10000)]:
        vectors = basin_phase_vectors(basin_time, target_year)
        source_table = (
            basin_response[basin_response.year.eq(source_year)]
            .set_index("basin").reindex(basins)[VARIABLES]
        )
        if source_table.isna().any().any():
            raise RuntimeError(f"Incomplete source constituent response for {source_year}")
        source_matrix = source_table.to_numpy(float)
        source_lookup = {basin: index for index, basin in enumerate(basins)}

        point_scores: dict[str, dict[str, float]] = {}
        for basin in basins:
            keep = np.array([index for index, name in enumerate(basins) if name != basin])
            direction = unit_vector(source_matrix[keep].mean(axis=0))
            point_scores[basin] = {}
            aligned_time = (
                basin_time[
                    basin_time.year.eq(target_year) & basin_time.basin.eq(basin)
                ]
                .set_index("rel_h").reindex(RELATIVE_HOURS)
            )
            time_matrix = aligned_time[DELTA_COLUMNS].to_numpy(float)
            rate = time_matrix @ direction
            cumulative = np.cumsum(rate)
            for hour, rate_value, cumulative_value in zip(RELATIVE_HOURS, rate, cumulative):
                trajectory_rows.append({
                    "year": target_year,
                    "target_year": target_year,
                    "scoring_direction_year": source_year,
                    "source_direction_year": source_year,
                    "basin": basin,
                    "held_out_basin": basin,
                    "rel_h": int(hour),
                    "rate_projection": float(rate_value),
                    "cumulative_projection": float(cumulative_value),
                })
            for phase, vector in vectors[basin].items():
                value = float(vector @ direction)
                point_scores[basin][phase] = value
                phase_rows.append({
                    "year": target_year,
                    "target_year": target_year,
                    "scoring_direction_year": source_year,
                    "source_direction_year": source_year,
                    "basin": basin,
                    "held_out_basin": basin,
                    "phase": phase,
                    "node_projection": value,
                })

        contrast_definitions = [
            ("peak_minus_pre", "peak", "pre", "greater"),
            ("late_minus_peak", "late_recovery", "peak", "less"),
        ]
        rng = np.random.default_rng(seed + offset)
        for contrast_index, (name, phase_a, phase_b, alternative) in enumerate(contrast_definitions):
            fixed = np.asarray([
                point_scores[basin][phase_a] - point_scores[basin][phase_b]
                for basin in basins
            ])
            draws = np.empty(replicates)
            for start in range(0, replicates, 2500):
                count = min(2500, replicates - start)
                target_indices = rng.integers(0, len(basins), size=(count, len(basins)))
                replicate_values = np.empty((count, len(basins)))
                for position in range(len(basins)):
                    selected = target_indices[:, position]
                    for row_index, basin_index in enumerate(selected):
                        basin = basins[basin_index]
                        pool = np.array([i for i, name_ in enumerate(basins) if name_ != basin])
                        sampled = rng.choice(pool, size=len(pool), replace=True)
                        direction = unit_vector(source_matrix[sampled].mean(axis=0))
                        contrast_vector = vectors[basin][phase_a] - vectors[basin][phase_b]
                        replicate_values[row_index, position] = contrast_vector @ direction
                draws[start:start+count] = replicate_values.mean(axis=1)
            t_low, t_high = t_interval(fixed)
            conditional_p = exact_signflip(fixed, alternative)
            test_rows.append({
                "year": target_year,
                "target_year": target_year,
                "scoring_direction_year": source_year,
                "source_direction_year": source_year,
                "inference_role": (
                    "primary basin-held-out cross-year evaluation"
                    if target_year == 2023
                    else "secondary basin-held-out reverse-year sensitivity"
                ),
                "test": name,
                "n_basins": len(fixed),
                "estimate": float(fixed.mean()),
                "median": float(np.median(fixed)),
                "source_target_ci_low": float(np.quantile(draws, 0.025)),
                "source_target_ci_high": float(np.quantile(draws, 0.975)),
                "t_ci_low": t_low,
                "t_ci_high": t_high,
                "alternative": alternative,
                "conditional_exact_p": conditional_p,
                "basins_in_expected_direction": int(
                    (fixed > 0).sum() if alternative == "greater" else (fixed < 0).sum()
                ),
                "source_target_bootstrap_replicates": replicates,
                "uncertainty_note": "source directions and target basins resampled; sign-flip P conditional on fitted held-out directions",
            })
        subset_indices = [i for i, row in enumerate(test_rows) if row["target_year"] == target_year]
        adjusted = holm([test_rows[i]["conditional_exact_p"] for i in subset_indices])
        for index, value in zip(subset_indices, adjusted):
            test_rows[index]["conditional_holm_p"] = value
    test_table = pd.DataFrame(test_rows)
    test_table["bootstrap_ci_low"] = test_table["source_target_ci_low"]
    test_table["bootstrap_ci_high"] = test_table["source_target_ci_high"]
    test_table["exact_p"] = test_table["conditional_exact_p"]
    test_table["holm_p"] = test_table["conditional_holm_p"]
    return pd.DataFrame(trajectory_rows), pd.DataFrame(phase_rows), test_table


def cross_year_trajectory_projection(
    basin_time: pd.DataFrame, source_year: int, target_year: int
) -> tuple[pd.DataFrame, dict]:
    source_template = (
        basin_time[basin_time.year.eq(source_year)]
        .groupby("rel_h")[DELTA_COLUMNS]
        .mean().reindex(RELATIVE_HOURS).to_numpy(float)
    )
    direction = unit_vector(source_template.ravel())
    rows = []
    for basin, group in basin_time[basin_time.year.eq(target_year)].groupby("basin", sort=True):
        target = group.set_index("rel_h").reindex(RELATIVE_HOURS)[DELTA_COLUMNS].to_numpy(float)
        if np.isfinite(target).all():
            rows.append({
                "source_year": source_year, "target_year": target_year, "basin": basin,
                "projection": float(target.ravel() @ direction),
                "cosine_similarity": float(target.ravel() @ direction / np.linalg.norm(target.ravel())),
            })
    result = pd.DataFrame(rows)
    return result, {
        "source_year": source_year, "target_year": target_year,
        "n_basins": len(result), "mean_projection": float(result.projection.mean()),
        "mean_cosine_similarity": float(result.cosine_similarity.mean()),
        "positive_basins": int((result.projection > 0).sum()),
        "exact_signflip_p": exact_signflip(result.projection.to_numpy(float), "greater"),
    }


def heldout_trajectory_analysis(
    basin_time: pd.DataFrame,
    replicates: int,
    seed: int,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Held-out points, cosine sensitivity and estimand-aligned nested intervals."""
    basins = sorted(basin_time.basin.unique())
    point_rows = []
    uncertainty_rows = []
    cosine_rows = []
    cosine_summary_rows = []
    for source_year, target_year, offset in [(2024, 2023, 0), (2023, 2024, 10000)]:
        source = np.stack([
            basin_time[basin_time.year.eq(source_year) & basin_time.basin.eq(basin)]
            .set_index("rel_h").reindex(RELATIVE_HOURS)[DELTA_COLUMNS].to_numpy(float).ravel()
            for basin in basins
        ])
        target = np.stack([
            basin_time[basin_time.year.eq(target_year) & basin_time.basin.eq(basin)]
            .set_index("rel_h").reindex(RELATIVE_HOURS)[DELTA_COLUMNS].to_numpy(float).ravel()
            for basin in basins
        ])
        fixed_values = []
        fixed_cosines = []
        for index, basin in enumerate(basins):
            pool = np.array([j for j in range(len(basins)) if j != index])
            direction = unit_vector(source[pool].mean(axis=0))
            projection = float(target[index] @ direction)
            cosine = float(projection / np.linalg.norm(target[index]))
            fixed_values.append(projection)
            fixed_cosines.append(cosine)
            point_rows.append({
                "source_year": source_year, "target_year": target_year,
                "held_out_basin": basin, "projection": projection,
                "cosine_similarity": cosine,
            })
            cosine_rows.append({
                "source_year": source_year, "target_year": target_year,
                "held_out_basin": basin, "cosine_similarity": cosine,
            })
        fixed_values = np.asarray(fixed_values)
        fixed_cosines = np.asarray(fixed_cosines)

        rng = np.random.default_rng(seed + offset)
        projection_draws = np.empty(replicates)
        cosine_draws = np.empty(replicates)
        for start in range(0, replicates, 2500):
            count = min(2500, replicates - start)
            target_indices = rng.integers(0, len(basins), size=(count, len(basins)))
            replicate_projections = np.empty((count, len(basins)))
            replicate_cosines = np.empty((count, len(basins)))
            for position in range(len(basins)):
                for row_index, target_index in enumerate(target_indices[:, position]):
                    pool = np.array([j for j in range(len(basins)) if j != target_index])
                    sampled = rng.choice(pool, size=len(pool), replace=True)
                    direction = unit_vector(source[sampled].mean(axis=0))
                    projection = float(target[target_index] @ direction)
                    replicate_projections[row_index, position] = projection
                    replicate_cosines[row_index, position] = projection / np.linalg.norm(target[target_index])
            projection_draws[start:start+count] = replicate_projections.mean(axis=1)
            cosine_draws[start:start+count] = replicate_cosines.mean(axis=1)

        uncertainty_rows.append({
            "source_year": source_year, "target_year": target_year,
            "estimand": "basin-held-out mean whole-trajectory projection",
            "point_estimate": float(fixed_values.mean()),
            "ci_low": float(np.quantile(projection_draws, 0.025)),
            "median": float(np.quantile(projection_draws, 0.5)),
            "ci_high": float(np.quantile(projection_draws, 0.975)),
            "fraction_nonpositive": float(np.mean(projection_draws <= 0)),
            "replicates": replicates,
        })
        cosine_summary_rows.append({
            "source_year": source_year, "target_year": target_year,
            "estimand": "basin-held-out mean whole-trajectory cosine similarity",
            "point_estimate": float(fixed_cosines.mean()),
            "ci_low": float(np.quantile(cosine_draws, 0.025)),
            "median": float(np.quantile(cosine_draws, 0.5)),
            "ci_high": float(np.quantile(cosine_draws, 0.975)),
            "positive_basins": int((fixed_cosines > 0).sum()),
            "conditional_exact_p": exact_signflip(fixed_cosines, "greater"),
            "replicates": replicates,
        })
    return (
        pd.DataFrame(point_rows), pd.DataFrame(uncertainty_rows),
        pd.DataFrame(cosine_rows), pd.DataFrame(cosine_summary_rows),
    )


def full_template_uncertainty(
    basin_time: pd.DataFrame, replicates: int, seed: int
) -> pd.DataFrame:
    """Full-template sensitivity retained separately from the held-out estimand."""
    rows = []
    rng = np.random.default_rng(seed)
    basins = sorted(basin_time.basin.unique())
    for source_year, target_year in [(2024, 2023), (2023, 2024)]:
        source = np.stack([
            basin_time[basin_time.year.eq(source_year) & basin_time.basin.eq(basin)]
            .set_index("rel_h").reindex(RELATIVE_HOURS)[DELTA_COLUMNS].to_numpy(float).ravel()
            for basin in basins
        ])
        target = np.stack([
            basin_time[basin_time.year.eq(target_year) & basin_time.basin.eq(basin)]
            .set_index("rel_h").reindex(RELATIVE_HOURS)[DELTA_COLUMNS].to_numpy(float).ravel()
            for basin in basins
        ])
        fixed_direction = unit_vector(source.mean(axis=0))
        point = float((target @ fixed_direction).mean())
        joint = np.empty(replicates)
        source_only = np.empty(replicates)
        target_only = np.empty(replicates)
        for start in range(0, replicates, 5000):
            count = min(5000, replicates - start)
            source_index = rng.integers(0, len(source), size=(count, len(source)))
            target_index = rng.integers(0, len(target), size=(count, len(target)))
            directions = source[source_index].mean(axis=1)
            directions /= np.linalg.norm(directions, axis=1)[:, None]
            target_sample = target[target_index]
            joint[start:start+count] = np.einsum("nkd,nd->nk", target_sample, directions).mean(axis=1)
            source_only[start:start+count] = (target @ directions.T).mean(axis=0)
            target_only[start:start+count] = (target_sample @ fixed_direction).mean(axis=1)
        for method, draws in [
            ("joint source-basin and target-basin bootstrap", joint),
            ("source-basin bootstrap only", source_only),
            ("target-basin bootstrap only", target_only),
        ]:
            rows.append({
                "source_year": source_year, "target_year": target_year,
                "point_estimate": point, "uncertainty_method": method,
                "ci_low": float(np.quantile(draws, 0.025)),
                "median": float(np.quantile(draws, 0.5)),
                "ci_high": float(np.quantile(draws, 0.975)),
                "fraction_nonpositive": float(np.mean(draws <= 0)),
                "replicates": replicates,
            })
    return pd.DataFrame(rows)


def episode_contrast_vectors(
    episodes: pd.DataFrame,
    year: int,
    test: str,
    support_rule: str,
) -> dict[str, np.ndarray]:
    if test == "peak_minus_pre":
        phase_a, phase_b = "peak", "pre"
    elif test == "late_minus_peak":
        phase_a, phase_b = "late_recovery", "peak"
    else:
        raise ValueError(test)
    output: dict[str, list[np.ndarray]] = {}
    for (episode_id, basin), group in episodes[episodes.year.eq(year)].groupby(["episode_id", "basin"]):
        aligned = group.set_index("rel_h").reindex(RELATIVE_HOURS)
        phase_vectors = {}
        valid = True
        for phase_name in [phase_a, phase_b]:
            values = aligned.loc[PHASES[phase_name], DELTA_COLUMNS].dropna(how="any")
            required = len(PHASES[phase_name]) if support_rule == "all_bins" else int(np.ceil(2 * len(PHASES[phase_name]) / 3))
            if len(values) < required:
                valid = False
                break
            phase_vectors[phase_name] = values.mean(axis=0).to_numpy(float)
        if valid:
            output.setdefault(basin, []).append(phase_vectors[phase_a] - phase_vectors[phase_b])
    return {basin: np.stack(vectors) for basin, vectors in output.items() if vectors}


def heldout_paired_episode_sensitivity(
    episodes: pd.DataFrame,
    basin_response: pd.DataFrame,
    replicates: int,
    seed: int,
) -> pd.DataFrame:
    basins = sorted(basin_response.basin.unique())
    rows = []
    for target_year, source_year, year_offset in [(2023, 2024, 0), (2024, 2023, 10000)]:
        source_table = basin_response[basin_response.year.eq(source_year)].set_index("basin").reindex(basins)[VARIABLES]
        source_matrix = source_table.to_numpy(float)
        for test_index, (test, alternative) in enumerate([
            ("peak_minus_pre", "greater"), ("late_minus_peak", "less")
        ]):
            for rule_index, support_rule in enumerate(["all_bins", "minimum_bins"]):
                vectors_by_basin = episode_contrast_vectors(episodes, target_year, test, support_rule)
                eligible_basins = [basin for basin in basins if basin in vectors_by_basin]
                fixed = []
                episode_count = 0
                for basin in eligible_basins:
                    target_index = basins.index(basin)
                    pool = np.array([i for i in range(len(basins)) if i != target_index])
                    direction = unit_vector(source_matrix[pool].mean(axis=0))
                    episode_values = vectors_by_basin[basin] @ direction
                    fixed.append(float(np.median(episode_values)))
                    episode_count += len(episode_values)
                fixed = np.asarray(fixed)
                rng = np.random.default_rng(seed + year_offset + test_index * 1000 + rule_index * 100)
                draws = np.empty(replicates)
                for start in range(0, replicates, 2500):
                    count = min(2500, replicates - start)
                    target_indices = rng.integers(0, len(eligible_basins), size=(count, len(eligible_basins)))
                    replicate_values = np.empty((count, len(eligible_basins)))
                    for position in range(len(eligible_basins)):
                        for row_index, eligible_index in enumerate(target_indices[:, position]):
                            basin = eligible_basins[eligible_index]
                            basin_index = basins.index(basin)
                            pool = np.array([i for i in range(len(basins)) if i != basin_index])
                            sampled_source = rng.choice(pool, size=len(pool), replace=True)
                            direction = unit_vector(source_matrix[sampled_source].mean(axis=0))
                            episode_vectors = vectors_by_basin[basin]
                            sampled_episode = rng.integers(0, len(episode_vectors), size=len(episode_vectors))
                            episode_values = episode_vectors[sampled_episode] @ direction
                            replicate_values[row_index, position] = float(np.median(episode_values))
                    draws[start:start+count] = replicate_values.mean(axis=1)
                t_low, t_high = t_interval(fixed)
                rows.append({
                    "year": target_year,
                    "source_direction_year": source_year,
                    "inference_role": (
                        "primary basin-held-out paired-episode sensitivity"
                        if target_year == 2023 else "secondary basin-held-out reverse-year paired-episode sensitivity"
                    ),
                    "support_rule": support_rule,
                    "test": test,
                    "n_episodes": episode_count,
                    "n_basins": len(fixed),
                    "mean_basin_contrast": float(fixed.mean()),
                    "median_basin_contrast": float(np.median(fixed)),
                    "source_target_episode_ci_low": float(np.quantile(draws, 0.025)),
                    "source_target_episode_ci_high": float(np.quantile(draws, 0.975)),
                    "t_ci_low": t_low,
                    "t_ci_high": t_high,
                    "basins_in_expected_direction": int(
                        (fixed > 0).sum() if alternative == "greater" else (fixed < 0).sum()
                    ),
                    "conditional_exact_p": exact_signflip(fixed, alternative),
                    "bootstrap_replicates": replicates,
                })
    table = pd.DataFrame(rows)
    table["bootstrap_ci_low"] = table["source_target_episode_ci_low"]
    table["bootstrap_ci_high"] = table["source_target_episode_ci_high"]
    table["exact_signflip_p"] = table["conditional_exact_p"]
    return table


def write_external_template(
    basin_time: pd.DataFrame, directions: dict[int, np.ndarray], output_dir: Path
) -> tuple[pd.DataFrame, np.ndarray]:
    template = (
        basin_time[basin_time.year.eq(2024)]
        .groupby("rel_h")[SHARED_DELTA_COLUMNS]
        .mean().reindex(RELATIVE_HOURS).reset_index()
    )
    if not np.isfinite(template[SHARED_DELTA_COLUMNS].to_numpy(float)).all():
        raise RuntimeError("Non-finite values in the five-variable external template")
    template.to_csv(output_dir / "china_five_variable_template.csv", index=False)
    indices = [VARIABLES.index(variable) for variable in SHARED_VARIABLES]
    shared_direction = unit_vector(directions[2024][indices])
    pd.DataFrame({"variable": SHARED_VARIABLES, "weight": shared_direction}).to_csv(
        output_dir / "china_five_variable_node_direction.csv", index=False
    )
    return template, shared_direction


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--node-summary", type=Path, required=True)
    parser.add_argument("--episode-trajectory", type=Path, required=True)
    parser.add_argument("--basin-node-summary", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=20260716)
    parser.add_argument("--bootstraps", type=int, default=5000)
    parser.add_argument("--template-bootstraps", type=int, default=50000)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    variable_response = pd.read_csv(args.node_summary)
    required = {"year", "variable", "mean_delta"}
    missing = required - set(variable_response.columns)
    if missing:
        raise ValueError(f"Node-summary input is missing columns: {sorted(missing)}")
    variable_response.to_csv(args.output_dir / "variable_response.csv", index=False)

    basin_response = pd.read_csv(args.basin_node_summary)
    required_basin = {"year", "basin", *VARIABLES}
    missing_basin = required_basin - set(basin_response.columns)
    if missing_basin:
        raise ValueError(f"Basin-node input is missing columns: {sorted(missing_basin)}")
    basin_response.to_csv(args.output_dir / "basin_constituent_response_vectors.csv", index=False)

    directions = {year: direction_from_summary(variable_response, year) for year in [2023, 2024]}
    for year, direction in directions.items():
        pd.DataFrame({"variable": VARIABLES, "weight": direction}).to_csv(
            args.output_dir / f"constituent_direction_{year}.csv", index=False
        )
    pd.DataFrame({"variable": VARIABLES, "weight": directions[2024]}).to_csv(
        args.output_dir / "node_direction_2024.csv", index=False
    )

    episodes = pd.read_csv(args.episode_trajectory)
    basin_time = episodes.groupby(["year", "basin", "rel_h"], as_index=False)[DELTA_COLUMNS].median()
    basin_time.to_csv(args.output_dir / "basin_event_trajectory.csv", index=False)

    cross_trajectory, cross_phase = phase_table(basin_time, directions, cross_fitted=True)
    same_trajectory, same_phase = phase_table(basin_time, directions, cross_fitted=False)
    cross_trajectory.to_csv(args.output_dir / "event_trajectory.csv", index=False)
    cross_phase.to_csv(args.output_dir / "phase_response.csv", index=False)
    same_trajectory.to_csv(args.output_dir / "construction_year_event_trajectory.csv", index=False)
    same_phase.to_csv(args.output_dir / "construction_year_phase_response.csv", index=False)
    conditional_phase_tests(cross_phase, args.bootstraps, args.seed).to_csv(
        args.output_dir / "primary_phase_tests.csv", index=False
    )
    construction_descriptive(same_phase).to_csv(
        args.output_dir / "construction_year_phase_descriptive.csv", index=False
    )

    forward, forward_summary = cross_year_trajectory_projection(basin_time, 2024, 2023)
    reverse, reverse_summary = cross_year_trajectory_projection(basin_time, 2023, 2024)
    forward.to_csv(args.output_dir / "basin_projections_2024_to_2023.csv", index=False)
    reverse.to_csv(args.output_dir / "basin_projections_2023_to_2024.csv", index=False)

    heldout_event_trajectory, heldout_phase, heldout_phase_tests = heldout_phase_analysis(
        basin_time, basin_response, args.template_bootstraps, args.seed + 1000
    )
    heldout_event_trajectory.to_csv(
        args.output_dir / "leave_one_basin_out_event_trajectory.csv", index=False
    )
    heldout_phase.to_csv(args.output_dir / "leave_one_basin_out_phase_response.csv", index=False)
    heldout_phase_tests.to_csv(args.output_dir / "leave_one_basin_out_phase_tests.csv", index=False)

    heldout_projection, heldout_uncertainty, heldout_cosine, heldout_cosine_summary = heldout_trajectory_analysis(
        basin_time, args.template_bootstraps, args.seed + 2000
    )
    heldout_projection.to_csv(
        args.output_dir / "leave_one_basin_out_trajectory_projection.csv", index=False
    )
    heldout_projection.groupby(["source_year", "target_year"]).agg(
        basins=("projection", "size"),
        positive_basins=("projection", lambda values: int((values > 0).sum())),
        mean_projection=("projection", "mean"),
        minimum_projection=("projection", "min"),
        maximum_projection=("projection", "max"),
        mean_cosine_similarity=("cosine_similarity", "mean"),
    ).reset_index().to_csv(
        args.output_dir / "leave_one_basin_out_trajectory_summary.csv", index=False
    )
    heldout_uncertainty.to_csv(
        args.output_dir / "leave_one_basin_out_trajectory_uncertainty.csv", index=False
    )
    heldout_cosine.to_csv(
        args.output_dir / "leave_one_basin_out_trajectory_cosine.csv", index=False
    )
    heldout_cosine_summary.to_csv(
        args.output_dir / "leave_one_basin_out_trajectory_cosine_summary.csv", index=False
    )

    full_template_uncertainty(
        basin_time, args.template_bootstraps, args.seed + 3000
    ).to_csv(args.output_dir / "trajectory_template_uncertainty.csv", index=False)

    heldout_paired_episode_sensitivity(
        episodes, basin_response, args.template_bootstraps, args.seed + 4000
    ).to_csv(args.output_dir / "paired_episode_sensitivity.csv", index=False)

    template, _ = write_external_template(basin_time, directions, args.output_dir)
    supported_episodes = episodes.groupby("year").episode_id.nunique().astype(int).to_dict()
    metadata = {
        "constituent_direction_cosine_2024_vs_2023": float(directions[2024] @ directions[2023]),
        "forward_full_template_2024_to_2023": forward_summary,
        "reverse_full_template_2023_to_2024": reverse_summary,
        "seed": args.seed,
        "conditional_phase_bootstraps": args.bootstraps,
        "source_target_bootstraps": args.template_bootstraps,
        "variables": VARIABLES,
        "shared_variables": SHARED_VARIABLES,
        "relative_hours": RELATIVE_HOURS,
        "phases": PHASES,
        "primary_phase_estimand": "basin-held-out constituent direction with source-target basin bootstrap",
        "primary_trajectory_estimand": "basin-held-out whole-trajectory projection with estimand-aligned source-target basin bootstrap",
        "primary_cross_year": 2023,
        "reverse_year_sensitivity": 2024,
        "conditional_signflip_note": "sign-flip probabilities condition on the fitted held-out directions",
        "reference_year_selection": {
            "reference_year": 2024,
            "criterion": "larger number of supported basin episodes",
            "supported_episodes": {str(key): int(value) for key, value in supported_episodes.items()},
            "archival_status": (
                "The archived analysis design used 2024 as the reference year and 2023 as the primary cross-year evaluation; "
                "2024 scored on the 2023 direction is a secondary reverse-year sensitivity."
            ),
        },
        "external_template": {
            "definition": "2024 basin-equal mean trajectory restricted to five shared variables",
            "rows": len(template),
            "node_direction": "2024 constituent direction restricted to five shared variables and renormalised",
        },
        "status": "PASS",
    }
    (args.output_dir / "trajectory_validation.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_dir / "analysis_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
