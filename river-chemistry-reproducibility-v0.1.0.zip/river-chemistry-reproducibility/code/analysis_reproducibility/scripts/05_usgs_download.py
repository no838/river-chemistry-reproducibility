#!/usr/bin/env python3
"""Download and cache official USGS continuous data used by the analysis.

The formal event intermediate is supplied with the release; this optional network stage
recreates its public-data inputs. Set USGS_API_KEY when required by the service.
Every JSON page and a normalized all-series CSV are retained with hashes.
"""
from __future__ import annotations
import argparse,csv,gzip,hashlib,json,os,time,urllib.parse,urllib.request
from pathlib import Path
BASE='https://api.waterdata.usgs.gov/ogcapi/v0/collections/continuous/items'
CONV={('00060','ft3/s'):('m3/s',0.028316846592),('00060','ft^3/s'):('m3/s',0.028316846592),('00060','cfs'):('m3/s',0.028316846592)}
def fetch(url,key=None):
 req=urllib.request.Request(url,headers={'X-Api-Key':key} if key else {})
 with urllib.request.urlopen(req,timeout=120) as r:return json.load(r)
def nxt(p):
 for x in p.get('links',[]):
  if x.get('rel')=='next':return x.get('href')
def flatten(feat,site,param,year):
 p=feat.get('properties',{});v=p.get('value');unit=str(p.get('unit_of_measure',''));cv='';cu=''
 try:
  fv=float(v);co=CONV.get((param,unit));
  if co:cu,fac=co;cv=fv*fac
 except Exception:pass
 return {'monitoring_location_id':site,'parameter_code':param,'year':year,'time':p.get('time'),'value':v,'unit_of_measure':unit,'converted_value':cv,'converted_unit':cu,'time_series_id':p.get('time_series_id'),'approval_status':p.get('approval_status'),'qualifier':p.get('qualifier'),'last_modified':p.get('last_modified'),'statistic_id':p.get('statistic_id')}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--sites',type=Path,required=True,help='CSV with site column or one site per row');ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--years',default='2019-2024');ap.add_argument('--parameters',default='00010,00400,00300,00095,63680,00060');a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True);sites=[]
 import pandas as pd
 d=pd.read_csv(a.sites);col='site' if 'site' in d else d.columns[0];sites=sorted(d[col].astype(str).unique());y0,y1=map(int,a.years.split('-'));params=a.parameters.split(',');key=os.getenv('USGS_API_KEY');manifest=[]
 for y in range(y0,y1+1):
  for s in sites:
   for p in params:
    q={'monitoring_location_id':s,'parameter_code':p,'datetime':f'{y}-01-01T00:00:00Z/{y+1}-01-01T00:00:00Z','limit':100000};url=BASE+'?'+urllib.parse.urlencode(q);pages=[];features=[];i=0
    while url:
     i+=1;pay=fetch(url,key);pages.append(pay);features.extend(pay.get('features',[]));url=nxt(pay);time.sleep(.05)
    out=a.output_dir/f'year={y}/site={s}/param={p}/observations.csv.gz';out.parent.mkdir(parents=True,exist_ok=True);rows=[flatten(x,s,p,y) for x in features]
    with gzip.open(out,'wt',encoding='utf-8',newline='') as f:
     w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['monitoring_location_id','parameter_code','year','time','value']);w.writeheader();w.writerows(rows)
    raw=out.parent/'raw_pages';raw.mkdir(exist_ok=True)
    for j,pay in enumerate(pages,1):
     with gzip.open(raw/f'page_{j:04d}.json.gz','wt',encoding='utf-8') as f:json.dump(pay,f,separators=(',',':'))
    h=hashlib.sha256(out.read_bytes()).hexdigest();manifest.append({'site':s,'year':y,'parameter':p,'rows':len(rows),'pages':len(pages),'path':out.relative_to(a.output_dir).as_posix(),'sha256':h})
 pd.DataFrame(manifest).to_csv(a.output_dir/'download_manifest.csv',index=False)
 inventory=[]
 for obs in sorted(a.output_dir.glob('year=*/site=*/param=*/observations.csv.gz')):
  q=pd.read_csv(obs,usecols=lambda c:c in {'monitoring_location_id','parameter_code','year','time','time_series_id','approval_status','statistic_id'})
  if 'time_series_id' not in q:continue
  q['time']=pd.to_datetime(q.time,utc=True,errors='coerce')
  for (site,param,year,sid),g in q.groupby(['monitoring_location_id','parameter_code','year','time_series_id'],dropna=False):
   inventory.append({'site':site,'parameter_code':param,'year':year,'time_series_id':sid,'observations':len(g),'unique_times':g.time.nunique(),'start_time':g.time.min(),'end_time':g.time.max(),'approval_statuses':'|'.join(sorted(set(g.get('approval_status',pd.Series(dtype=str)).dropna().astype(str)))),'statistic_ids':'|'.join(sorted(set(g.get('statistic_id',pd.Series(dtype=str)).dropna().astype(str))))})
 pd.DataFrame(inventory).to_csv(a.output_dir/'series_inventory.csv',index=False)
if __name__=='__main__':main()
