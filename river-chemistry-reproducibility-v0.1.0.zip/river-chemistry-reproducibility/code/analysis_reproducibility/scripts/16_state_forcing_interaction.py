#!/usr/bin/env python3
"""Test whether event forcing modifies lagged annual-state predictability.

Compare an additive model
    response ~ basin + year + PC1 + PC2 + forcing
with
    response ~ basin + year + PC1 + PC2 + forcing
               + PC1:forcing + PC2:forcing.

The response is the within-section IQR-standardised phase score. The primary
test is the joint incremental partial R² of the two interaction terms.
Freedman-Lane residual permutations are performed within basin-year strata.
Coefficient intervals use physical-section cluster-robust covariance.
Bidirectional held-out Q² compares interaction and additive specifications.

Only the prespecified composite forcing score is tested.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd,statsmodels.api as sm
OUTCOMES=["peak_minus_pre","late_minus_peak"];STATE=["PC1","PC2"];FORCING="peak_forcing4h_score"
def plus_one(c,n):return float((c+1)/(n+1))
def holm(v):
 v=np.asarray(v,float);o=np.argsort(v);a=np.empty(len(v));r=0.
 for k,i in enumerate(o):r=max(r,(len(v)-k)*v[i]);a[i]=min(1.,r)
 return a
def std(s,mean=None,sd=None):
 x=s.to_numpy(float);mean=float(x.mean()) if mean is None else mean;sd=float(x.std(ddof=1)) if sd is None else sd
 if not np.isfinite(sd) or sd<=0:raise ValueError(s.name)
 return (x-mean)/sd,mean,sd
def bymat(f,levels=None):
 lab=f.basin.astype(str)+"|"+f.year.astype(str);levels=sorted(lab.unique()) if levels is None else levels
 return np.column_stack([(lab==v).to_numpy(float) for v in levels]),levels
def design(f,scaling=None,interaction=True,levels=None):
 B,levels=bymat(f,levels);z={}
 if scaling is None:
  scaling={}
  for c in STATE+[FORCING]:z[c],m,s=std(f[c]);scaling[c]={"mean":m,"sd":s}
 else:
  for c in STATE+[FORCING]:z[c]=(f[c].to_numpy(float)-scaling[c]["mean"])/scaling[c]["sd"]
 blocks=[B,z["PC1"][:,None],z["PC2"][:,None],z[FORCING][:,None]]
 names=[f"basin_year:{v}" for v in levels]+["z_PC1","z_PC2","z_forcing"]
 if interaction:
  blocks += [(z["PC1"]*z[FORCING])[:,None],(z["PC2"]*z[FORCING])[:,None]]
  names += ["z_PC1_x_forcing","z_PC2_x_forcing"]
 return np.column_stack(blocks),names,scaling,levels
def fit(X,y):
 b=np.linalg.lstsq(X,y,rcond=None)[0];res=y-X@b;sst=float(np.sum((y-y.mean())**2));r2=1-float(np.sum(res**2))/sst
 return b,res,r2
def pr2(X,X0,y):
 return float((fit(X,y)[2]-fit(X0,y)[2])/max(1-fit(X0,y)[2],1e-12))
def test(f,outcome,nperm,seed):
 X0,_,sc,lev=design(f,interaction=False);X,names,_,_=design(f,sc,True,lev);y=f[outcome].to_numpy(float)
 obs=pr2(X,X0,y);b0,res,_=fit(X0,y);fitted=X0@b0
 groups=[g.index.to_numpy() for _,g in f.reset_index(drop=True).groupby(["basin","year"],sort=True)]
 rng=np.random.default_rng(seed);null=np.empty(nperm)
 for k in range(nperm):
  rp=res.copy()
  for g in groups:rp[g]=rng.permutation(rp[g])
  null[k]=pr2(X,X0,fitted+rp)
 model=sm.OLS(y,X).fit(cov_type="cluster",cov_kwds={"groups":f.section_id.astype(str).to_numpy()});ci=model.conf_int();coef=[]
 for term in ["z_PC1_x_forcing","z_PC2_x_forcing"]:
  j=names.index(term);coef.append({"outcome":outcome,"term":term,"estimate":float(model.params[j]),"ci_low":float(ci[j,0]),"ci_high":float(ci[j,1]),"p_value":float(model.pvalues[j]),"uncertainty":"physical-section cluster-robust covariance"})
 return {"outcome":outcome,"n_section_years":len(f),"n_sections":f.section_id.nunique(),"n_basins":f.basin.nunique(),"interaction_partial_r2":obs,"within_basin_year_Freedman_Lane_p":plus_one(int((null>=obs).sum()),nperm),"permutations":nperm},coef
def pred_mats(train,test):
 common=sorted(set(train.basin)&set(test.basin));train=train[train.basin.isin(common)].reset_index(drop=True);test=test[test.basin.isin(common)].reset_index(drop=True)
 B=np.column_stack([(train.basin.astype(str)==v).to_numpy(float) for v in common]);Bt=np.column_stack([(test.basin.astype(str)==v).to_numpy(float) for v in common]);z={};zt={}
 for c in STATE+[FORCING]:z[c],m,s=std(train[c]);zt[c]=(test[c].to_numpy(float)-m)/s
 X0=np.column_stack([B,z["PC1"],z["PC2"],z[FORCING]]);X0t=np.column_stack([Bt,zt["PC1"],zt["PC2"],zt[FORCING]])
 X1=np.column_stack([X0,z["PC1"]*z[FORCING],z["PC2"]*z[FORCING]]);X1t=np.column_stack([X0t,zt["PC1"]*zt[FORCING],zt["PC2"]*zt[FORCING]])
 return train,test,X0,X0t,X1,X1t
def q2(train,test,outcome):
 train,test,X0,X0t,X1,X1t=pred_mats(train,test);y=train[outcome].to_numpy(float);yt=test[outcome].to_numpy(float)
 p0=X0t@np.linalg.lstsq(X0,y,rcond=None)[0];p1=X1t@np.linalg.lstsq(X1,y,rcond=None)[0];den=float(np.sum((yt-p0)**2))
 return float(1-np.sum((yt-p1)**2)/den),train,test
def heldout(f,outcome,sy,ty,nboot,seed):
 source=f[f.year.eq(sy)].copy();target=f[f.year.eq(ty)].copy();point,source,target=q2(source,target,outcome)
 sg=[g.index.to_numpy() for _,g in source.groupby("basin",sort=True)];tg=[g.index.to_numpy() for _,g in target.groupby("basin",sort=True)]
 rng=np.random.default_rng(seed);draw=np.empty(nboot)
 for k in range(nboot):
  si=np.concatenate([rng.choice(g,len(g),replace=True) for g in sg]);ti=np.concatenate([rng.choice(g,len(g),replace=True) for g in tg])
  try:draw[k]=q2(source.loc[si].reset_index(drop=True),target.loc[ti].reset_index(drop=True),outcome)[0]
  except Exception:draw[k]=np.nan
 draw=draw[np.isfinite(draw)]
 return {"outcome":outcome,"source_event_year":sy,"target_event_year":ty,"n_source_sections":source.section_id.nunique(),"n_target_sections":target.section_id.nunique(),"interaction_q2_increment_over_additive":point,"ci_low":float(np.quantile(draw,.025)),"ci_high":float(np.quantile(draw,.975)),"bootstrap_replicates":len(draw)}
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--section-year",type=Path,required=True);ap.add_argument("--output-dir",type=Path,required=True);ap.add_argument("--permutations",type=int,default=10000);ap.add_argument("--bootstraps",type=int,default=5000);ap.add_argument("--seed",type=int,default=20269701);a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
 d=pd.read_csv(a.section_year);required={"section_id","year","basin","PC1","PC2",FORCING,*OUTCOMES};missing=required-set(d.columns)
 if missing:raise ValueError(sorted(missing))
 tests=[];coefs=[];transfers=[]
 for i,o in enumerate(OUTCOMES):
  f=d.dropna(subset=[o,"PC1","PC2",FORCING]).reset_index(drop=True);t,c=test(f,o,a.permutations,a.seed+100*i);tests.append(t);coefs.extend(c)
  for j,(sy,ty) in enumerate([(2023,2024),(2024,2023)]):transfers.append(heldout(f,o,sy,ty,a.bootstraps,a.seed+1000+100*i+j))
 tests=pd.DataFrame(tests);tests["holm_p_two_outcomes"]=holm(tests.within_basin_year_Freedman_Lane_p);coefs=pd.DataFrame(coefs);transfers=pd.DataFrame(transfers)
 tests.to_csv(a.output_dir/"interaction_joint_tests.csv",index=False);coefs.to_csv(a.output_dir/"interaction_coefficients.csv",index=False);transfers.to_csv(a.output_dir/"interaction_heldout_q2.csv",index=False)
 decision={"decision":"NO_DETECTABLE_LINEAR_STATE_BY_FORCING_INTERACTION" if (tests.holm_p_two_outcomes>=.05).all() and ((transfers.ci_low<=0)&(transfers.ci_high>=0)).all() else "INTERACTION_REQUIRES_CONFIRMATION","forcing_variable":FORCING,"predictors":STATE,"outcomes":OUTCOMES,"primary_test":"joint incremental partial R2 of PC1-by-forcing and PC2-by-forcing","permutations":a.permutations,"bootstraps":a.bootstraps,"seed":a.seed,"interpretation":"Tests only bilinear state-by-forcing terms; nonlinear thresholds and untested forcing metrics remain open."}
 (a.output_dir/"decision.json").write_text(json.dumps(decision,indent=2));print(json.dumps(decision,indent=2))
if __name__=="__main__":main()
