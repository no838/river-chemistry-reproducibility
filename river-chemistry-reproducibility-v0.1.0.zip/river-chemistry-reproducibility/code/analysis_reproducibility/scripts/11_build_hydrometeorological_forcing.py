#!/usr/bin/env python3
"""Build basin-day pulse/control forcing from daily CHIRPS v2.0 and MERRA-2 inputs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def antecedent_precipitation(values: np.ndarray, decay: float) -> np.ndarray:
    output = np.full(len(values), np.nan, dtype=float)
    previous = np.nan
    for index, value in enumerate(values):
        if np.isfinite(value):
            previous = value + decay * (0.0 if not np.isfinite(previous) else previous)
            output[index] = previous
        else:
            previous = np.nan
    return output


def empirical_percentile(series: pd.Series) -> pd.Series:
    return series.rank(method="average", pct=True)


def build_forcing(table: pd.DataFrame, decay: float) -> pd.DataFrame:
    required = {"major_basin", "date_local", "precip_polygon_mm", "runoff_merra_mm"}
    missing = required - set(table.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    table = table.copy()
    table["date_local"] = pd.to_datetime(table.date_local)
    table = table.sort_values(["major_basin", "date_local"]).reset_index(drop=True)
    parts = []
    for basin, group in table.groupby("major_basin", sort=True):
        group = group.sort_values("date_local").copy()
        group["P3d_polygon_mm"] = group.precip_polygon_mm.rolling(3, min_periods=3).sum()
        group["P7d_polygon_mm"] = group.precip_polygon_mm.rolling(7, min_periods=7).sum()
        group["P14d_polygon_mm"] = group.precip_polygon_mm.rolling(14, min_periods=14).sum()
        group["API850_polygon"] = antecedent_precipitation(
            group.precip_polygon_mm.to_numpy(float), decay
        )
        parts.append(group)
    table = pd.concat(parts, ignore_index=True)
    table["month"] = table.date_local.dt.month
    for variable in ["P3d_polygon_mm", "P7d_polygon_mm", "API850_polygon", "runoff_merra_mm"]:
        table[variable + "_pct"] = table.groupby(
            ["major_basin", "month"], sort=False
        )[variable].transform(empirical_percentile)
    percentile_columns = [
        "P3d_polygon_mm_pct", "P7d_polygon_mm_pct",
        "API850_polygon_pct", "runoff_merra_mm_pct",
    ]
    table["forcing_score"] = table[percentile_columns].mean(axis=1, skipna=True)
    table["n_high75"] = table[percentile_columns].ge(0.75).sum(axis=1)
    table["pulse_primary"] = table.forcing_score.ge(0.85) & table.n_high75.ge(3)
    table["pulse_chirps"] = table[[
        "P3d_polygon_mm_pct", "P7d_polygon_mm_pct", "API850_polygon_pct"
    ]].max(axis=1).ge(0.85)
    table["pulse_runoff"] = table.runoff_merra_mm_pct.ge(0.85)
    table["control_pool"] = (
        table.forcing_score.between(0.35, 0.65)
        & table[percentile_columns].max(axis=1).lt(0.80)
    )
    return table.drop(columns="month")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True,
                        help="Daily basin table with CHIRPS precipitation and MERRA-2 runoff")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--api-decay", type=float, default=0.85)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    source = pd.read_csv(args.input)
    result = build_forcing(source, args.api_decay)
    result.to_csv(args.output, index=False, compression="gzip" if args.output.suffix == ".gz" else None)
    metadata = {
        "precipitation_product": "CHIRPS v2.0 daily precipitation",
        "runoff_product": "MERRA-2 tavg1_2d_lnd_Nx RUNOFF",
        "api_decay": args.api_decay,
        "percentile_domain": "major basin by calendar month over 2022-2024",
        "pulse_rule": "forcing score >= 0.85 and at least three component percentiles >= 0.75",
        "control_rule": "0.35 <= forcing score <= 0.65 and every component percentile < 0.80",
        "rows": len(result),
        "basins": int(result.major_basin.nunique()),
    }
    (args.output.parent / "forcing_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
