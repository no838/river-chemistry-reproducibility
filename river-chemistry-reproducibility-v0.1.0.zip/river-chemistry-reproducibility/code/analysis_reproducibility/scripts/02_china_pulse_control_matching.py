#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.optimize import linear_sum_assignment

def match_year(year,data,force,min_obs=40,min_sections=6,min_days=3):
 sup=data[data.year.eq(year)].copy();sup['date_local']=pd.to_datetime(sup.date_local)
 f=force[pd.to_datetime(force.date_local).dt.year.eq(year)].copy();f['date_local']=pd.to_datetime(f.date_local)
 f=f.merge(sup,left_on=['major_basin','date_local'],right_on=['basin','date_local'],how='inner');f=f[(f.n_obs>=min_obs)&(f.n_sections>=min_sections)].copy();f['month']=f.date_local.dt.month;rows=[]
 for basin,g0 in f.groupby('major_basin',sort=True):
  pulse_dates=g0.loc[g0.pulse_primary.astype(bool),'date_local'].sort_values().to_numpy();g=g0.copy()
  g['dist_to_pulse']=[min(abs((pd.Timestamp(d)-pd.Timestamp(p)).days) for p in pulse_dates) if len(pulse_dates) else 999 for d in g.date_local]
  for month,gm in g.groupby('month',sort=True):
   P=gm[gm.pulse_primary.astype(bool)].copy();C=gm[gm.control_pool.astype(bool)&g.loc[gm.index,'dist_to_pulse'].ge(min_days)].copy()
   if P.empty or C.empty:continue
   pn=P[['n_obs','n_sections']].to_numpy(float);cn=C[['n_obs','n_sections']].to_numpy(float);med_obs=max(float(np.median(gm.n_obs)),1);med_sec=max(float(np.median(gm.n_sections)),1)
   cost=np.abs(pn[:,None,0]-cn[None,:,0])/med_obs+np.abs(pn[:,None,1]-cn[None,:,1])/med_sec+0.02*np.abs(P.date_local.dt.day.to_numpy()[:,None]-C.date_local.dt.day.to_numpy()[None,:])
   ri,ci=linear_sum_assignment(cost)
   for ia,ib in zip(ri,ci):
    pr=P.iloc[ia];cr=C.iloc[ib];rows.append({'year':year,'basin':basin,'month':int(month),'pulse_date':pr.date_local.date().isoformat(),'control_date':cr.date_local.date().isoformat(),'pulse_score':pr.forcing_score,'control_score':cr.forcing_score,'pulse_n_obs':int(pr.n_obs),'control_n_obs':int(cr.n_obs),'pulse_n_sections':int(pr.n_sections),'control_n_sections':int(cr.n_sections),'match_cost':float(cost[ia,ib])})
 return pd.DataFrame(rows)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--forcing',type=Path,required=True);ap.add_argument('--daily-support',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--reference',type=Path);a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
 f=pd.read_csv(a.forcing);d=pd.read_csv(a.daily_support);out=pd.concat([match_year(y,d,f) for y in [2023,2024]],ignore_index=True).sort_values(['year','basin','month','pulse_date']).reset_index(drop=True);out.to_csv(a.output_dir/'matched_pulse_control_days.csv',index=False)
 qa={'rows':len(out),'by_year':out.groupby('year').size().astype(int).to_dict(),'parameters':{'min_daily_observations':40,'min_daily_sections':6,'control_min_days_from_pulse':3,'cost':'|nobs difference|/median nobs + |nsections difference|/median nsections + 0.02*|day-of-month difference|'}}
 if a.reference and a.reference.exists():
  r=pd.read_csv(a.reference);r['pulse_date']=pd.to_datetime(r.pulse_date).dt.date.astype(str);r['control_date']=pd.to_datetime(r.control_date).dt.date.astype(str);keys=['year','basin','pulse_date','control_date'];m=out.merge(r,on=keys,how='outer',indicator=True,suffixes=('_new','_ref'));qa['reference_exact_pair_rows']=int((m._merge=='both').sum());qa['reference_rows']=len(r);qa['new_rows']=len(out);qa['pair_set_equal']=bool((m._merge=='both').all());qa['max_cost_difference']=float(np.nanmax(np.abs(m.loc[m._merge.eq('both'),'match_cost_new']-m.loc[m._merge.eq('both'),'match_cost_ref']))) if (m._merge=='both').any() else None
 (a.output_dir/'matching_QA.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(qa,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
