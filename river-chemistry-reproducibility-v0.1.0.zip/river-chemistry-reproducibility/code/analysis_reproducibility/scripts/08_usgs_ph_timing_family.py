#!/usr/bin/env python3
"""Recompute the exploratory pH representation/timing family on one fixed event set."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import norm,rankdata
RELS=np.arange(-24,49,4);PRE=[-24,-20,-16];SEED=20260722;B=50000;N_SHIFT=200000
REPS=['raw pH differences','baseline-corrected pH','rank-normal pH','hydrogen-ion timing']

def read_ph(cache,site,year):
 p=next((cache/f'year={year}/site={site}').glob('param=00400*/observations.csv.gz'))
 d=pd.read_csv(p,usecols=lambda c:c in {'time','value','statistic_id'});d.time=pd.to_datetime(d.time,utc=True,errors='coerce');d.value=pd.to_numeric(d.value,errors='coerce');d.statistic_id=pd.to_numeric(d.statistic_id,errors='coerce');d=d[d.statistic_id.eq(11)&d.value.between(0,14)].dropna(subset=['time','value']);return d.groupby('time',as_index=False).value.median()
def res4(d):
 s=d.set_index('time').value.sort_index();m=s.resample('4h',origin='start_day').median();n=s.resample('4h',origin='start_day').count();m[n<2]=np.nan;return m
def normal_scores(s):
 o=pd.Series(np.nan,index=s.index,dtype=float);ok=s.notna();n=int(ok.sum());o.loc[ok]=norm.ppf((rankdata(s[ok].to_numpy(float),method='average')-.5)/n);return o
def scale(s):
 d=s.diff();gap=s.index.to_series().diff().dt.total_seconds()/3600;d=d.where(gap.eq(4));q=d.quantile([.25,.75]);v=float(q.iloc[1]-q.iloc[0]);return v if np.isfinite(v) and v>0 else np.nan
def trajectory(s,p,c,sc):
 e=np.array([s.get(p+pd.Timedelta(hours=int(h)),np.nan) for h in RELS]);z=np.array([s.get(c+pd.Timedelta(hours=int(h)),np.nan) for h in RELS]);d=(e-z)/sc;return d-np.mean(d[[np.where(RELS==h)[0][0] for h in PRE]])
def signflip(x):
 x=np.asarray(x,float);obs=x.mean();return sum(np.mean(x*np.array([1 if bits>>j&1 else -1 for j in range(len(x))]))>=obs-1e-15 for bits in range(2**len(x)))/2**len(x)
def ci(x,seed):
 x=np.asarray(x,float);rr=np.random.default_rng(seed);z=rr.choice(x,(B,len(x)),replace=True).mean(1);return np.quantile(z,[.025,.975])
def holm(p):
 p=np.asarray(p,float);o=np.argsort(p);out=np.empty(len(p));run=0
 for k,j in enumerate(o):run=max(run,(len(p)-k)*p[j]);out[j]=min(1,run)
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--events',type=Path,required=True);ap.add_argument('--cache',type=Path,required=True);ap.add_argument('--template',type=Path,required=True);ap.add_argument('--formal-sites',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);a=ap.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
 formal=pd.read_csv(a.formal_sites).site.astype(str).tolist();ev=pd.read_csv(a.events);ev=ev[ev.site.isin(formal)&ev.year.isin([2022,2023,2024])].copy();ev.peak_time=pd.to_datetime(ev.peak_time,utc=True);ev.control_time=pd.to_datetime(ev.control_time,utc=True)
 template=pd.read_csv(a.template).set_index('rel_h').reindex(RELS).d_pH.to_numpy(float);template/=np.linalg.norm(template);arr={};scaleqa=[]
 for (site,year),g in ev.groupby(['site','year']):
  s=res4(read_ph(a.cache,site,int(year)));sr=normal_scores(s);hp=10.0**(-s);sc={'baseline-corrected pH':scale(s),'rank-normal pH':scale(sr),'hydrogen-ion timing':scale(hp)}
  for _,r in g.iterrows():
   arr[(r.event_id,'raw pH differences')]=np.array([r.get(f'pH_{h}',np.nan) for h in RELS],float);arr[(r.event_id,'baseline-corrected pH')]=trajectory(s,r.peak_time,r.control_time,sc['baseline-corrected pH']);arr[(r.event_id,'rank-normal pH')]=trajectory(sr,r.peak_time,r.control_time,sc['rank-normal pH']);arr[(r.event_id,'hydrogen-ion timing')]=trajectory(hp,r.peak_time,r.control_time,sc['hydrogen-ion timing'])
  scaleqa.append({'site':site,'year':year,'events':len(g),**{f'scale_{k}':v for k,v in sc.items()}})
 common={eid for eid in ev.event_id if all(np.isfinite(arr[(eid,r)]).all() for r in REPS)};ev=ev[ev.event_id.isin(common)]
 syrows=[];tr={};eventrows=[]
 for rep in REPS:
  direction=-template if rep=='hydrogen-ion timing' else template
  for _,r in ev.iterrows():
   x=arr[(r.event_id,rep)];eventrows.append({'site':r.site,'year':r.year,'event_id':r.event_id,'representation':rep,'projection':x@direction,'reverse_projection':x@direction[::-1],'forward_minus_reverse':x@direction-x@direction[::-1]})
  for (site,year),g in ev.groupby(['site','year']):
   x=np.median(np.vstack([arr[(e,rep)] for e in g.event_id]),axis=0);tr[(site,int(year),rep)]=x;syrows.append({'site':site,'year':year,'representation':rep,'n_events':len(g),'projection':x@direction,'reverse_projection':x@direction[::-1],'forward_minus_reverse':x@direction-x@direction[::-1]})
 sy=pd.DataFrame(syrows);results=[];shiftrows=[]
 for ir,rep in enumerate(REPS):
  g=sy[sy.representation.eq(rep)];sites=sorted(g.site.unique());site=[]
  for s in sites:
   q=g[g.site.eq(s)];site.append({'site':s,'projection':np.median(q.projection),'fmr':np.median(q.forward_minus_reverse),'events':q.n_events.sum(),'site_years':len(q)})
  site=pd.DataFrame(site);pv=site.projection.to_numpy();fv=site.fmr.to_numpy();pc=ci(pv,SEED+10*ir);fc=ci(fv,SEED+10*ir+1);direction=-template if rep=='hydrogen-ion timing' else template
  keys=[(r.site,int(r.year)) for _,r in g.iterrows()];sh=np.array([[np.roll(tr[(s,y,rep)],k)@direction for k in range(1,len(RELS))] for s,y in keys]);siteix=[np.where(g.site.to_numpy()==s)[0] for s in sites];rr=np.random.default_rng(SEED+100+ir);choice=rr.integers(0,len(RELS)-1,size=(N_SHIFT,len(g)),dtype=np.int8);sel=sh[np.arange(len(g))[None,:],choice];ps=np.column_stack([np.median(sel[:,ix],axis=1) for ix in siteix]);null=ps.mean(1);obs=pv.mean();sp=(1+np.sum(null>=obs))/(N_SHIFT+1);raw=[signflip(pv),signflip(fv),sp];adj=holm(raw)
  results.append({'representation':rep,'sites':len(site),'site_years':len(g),'common_events':len(common),'mean_projection':pv.mean(),'projection_ci_low':pc[0],'projection_ci_high':pc[1],'projection_positive_sites':int((pv>0).sum()),'projection_raw_p':raw[0],'projection_holm_p':adj[0],'mean_forward_minus_reverse':fv.mean(),'fmr_ci_low':fc[0],'fmr_ci_high':fc[1],'fmr_positive_sites':int((fv>0).sum()),'fmr_raw_p':raw[1],'fmr_holm_p':adj[1],'shift_null_q95':np.quantile(null,.95),'shift_raw_p':raw[2],'shift_holm_p':adj[2],'shift_permutations':N_SHIFT})
  for s,ix,o in zip(sites,siteix,pv):shiftrows.append({'representation':rep,'site':s,'observed_projection':o,'site_shift_null_median':np.median(sh[ix])})
 pd.DataFrame(eventrows).to_csv(a.output_dir/'event_projections.csv.gz',index=False,compression='gzip');sy.to_csv(a.output_dir/'site_year_projections.csv',index=False);pd.DataFrame(results).to_csv(a.output_dir/'complete_family.csv',index=False);pd.DataFrame(shiftrows).to_csv(a.output_dir/'shift_site_metrics.csv',index=False);pd.DataFrame(scaleqa).to_csv(a.output_dir/'scaling_QA.csv',index=False);meta={'formal_events':len(pd.read_csv(a.events).query('year in [2022,2023,2024]')),'common_events':len(common),'site_years':sy[['site','year']].drop_duplicates().shape[0],'shift_permutations':N_SHIFT,'seed':SEED};(a.output_dir/'analysis_metadata.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
