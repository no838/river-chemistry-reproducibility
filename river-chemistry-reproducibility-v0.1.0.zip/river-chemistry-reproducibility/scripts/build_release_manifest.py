#!/usr/bin/env python3
"""Build a relative-path manifest for the public release candidate."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def role(rel: str) -> str:
    if rel.startswith("code/") or rel.startswith("scripts/"):
        return "code"
    if rel.startswith("data/"):
        return "derived_figure_ready_data"
    if rel.startswith("docs/"):
        return "scope_documentation"
    if rel in {"README.md", "environment.yml", ".gitignore"}:
        return "release_metadata"
    if rel.endswith(".md") and "LICENSE" in rel:
        return "license_pending"
    return "release_metadata"


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    excluded_prefixes = ("QA/", ".git/")
    excluded_names = {"MANIFEST.csv", "PUBLIC_RELEASE_AUDIT_REPORT.md"}
    rows = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if rel.startswith(excluded_prefixes) or path.name in excluded_names:
            continue
        rows.append({
            "path": rel,
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
            "role": role(rel),
            "raw_data_included": "no",
        })
    rows.sort(key=lambda row: row["path"])
    with (root / "MANIFEST.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} manifest rows")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
