#!/usr/bin/env python3
"""Build a deterministic SHA-256 manifest for release files."""

from __future__ import annotations

import hashlib
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    excluded = {"SHA256SUMS.txt", "MANIFEST.csv", "PUBLIC_RELEASE_AUDIT_REPORT.md"}
    files = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if rel.startswith("QA/") or rel in excluded or rel.startswith(".git/"):
            continue
        files.append((rel, sha256(path)))
    files.sort()
    lines = ["# SHA-256 checksums for the minimal public release", ""]
    lines.extend(f"{digest}  {rel}" for rel, digest in files)
    (root / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {len(files)} checksums")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
