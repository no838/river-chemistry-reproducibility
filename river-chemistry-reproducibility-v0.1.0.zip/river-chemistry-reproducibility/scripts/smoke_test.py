#!/usr/bin/env python3
"""Dependency-light integrity check for the minimal public release."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


REQUIRED_FILES = [
    "README.md",
    "docs/DATA_SCOPE.md",
    "code/analysis_reproducibility/environment.yml",
    "code/analysis_reproducibility/software_environment.json",
    "code/analysis_reproducibility/config/analysis_config.json",
    "code/analysis_reproducibility/config/seeds.json",
    "data/figure_ready/figure1/Figure_1c_transition_matrices.csv",
    "data/figure_ready/figure2/Figure_2b_state_centroids.csv",
    "data/figure_ready/figure3/Figure_3a_basin_event_support.csv",
    "data/figure_ready/figure4/Figure_4_primary_three_test_family.csv",
]


def check_csv(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader, [])
        first_row = next(reader, [])
    return {
        "header_columns": len(header),
        "first_row_columns": len(first_row),
        "header_nonempty": bool(header and all(cell.strip() for cell in header)),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path("."))
    args = parser.parse_args()
    root = args.root.resolve()
    result: dict[str, object] = {"root": ".", "required_files": {}, "ok": True}

    for rel in REQUIRED_FILES:
        path = root / rel
        record: dict[str, object] = {"exists": path.is_file()}
        if path.is_file() and path.suffix.lower() == ".csv":
            record.update(check_csv(path))
            record["ok"] = bool(record["header_nonempty"])
        else:
            record["ok"] = path.is_file()
        result["required_files"][rel] = record
        result["ok"] = bool(result["ok"]) and bool(record["ok"])

    out = root / "QA" / "smoke_test.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"ok": result["ok"], "checked": len(REQUIRED_FILES)}, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
